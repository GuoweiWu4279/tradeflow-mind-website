// StrategyProfile.cs
//
// Persistent configuration describing the trader's strategy parameters.
// Used by PsiEngine as the prior baseline before sufficient historical data
// has accumulated (cold-start problem).
//
// Serialised to XML so the file is human-readable and editable outside the app.
// No NinjaTrader API dependencies — pure .NET, independently unit-testable.

using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Serialization;

namespace NinjaTrader.NinjaScript.AddOns
{
    /// <summary>
    /// Overall PSI engine sensitivity preset.
    /// Drives the default values in <see cref="PsiEngineConfig"/> via the
    /// <see cref="PsiEngineConfig.FromProfile"/> factory method.
    /// </summary>
    public enum PsiSensitivity
    {
        /// <summary>Stricter monitoring: lower thresholds, faster drops, slower recovery.</summary>
        Conservative = 0,
        /// <summary>Default tuning (original calibrated values).</summary>
        Balanced     = 1,
        /// <summary>More lenient: higher thresholds, requires more extreme behaviour to trigger.</summary>
        Aggressive   = 2
    }

    [XmlRoot("StrategyProfile")]
    public sealed class StrategyProfile
    {
        // =====================================================================
        // File paths
        // =====================================================================

        private static string DataDir = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
            "NinjaTrader 8", "bin", "Custom", "AddOns", "TradeMonitorData");

        /// <summary>
        /// Override the data directory.  Call from TradeMonitor.OnStateChange(Configure)
        /// using NinjaTrader.Core.Globals.UserDataDir so the path is correct even when
        /// the user has redirected their Documents folder to OneDrive.
        /// </summary>
        internal static void SetDataDir(string path)
        {
            if (!string.IsNullOrEmpty(path)) DataDir = path;
        }

        public static string ProfilePath => Path.Combine(DataDir, "profile.xml");

        // =====================================================================
        // Trading session window
        // =====================================================================
        // Stored as integers rather than TimeSpan because XmlSerializer requires
        // extra ceremony to handle TimeSpan correctly.  Computed properties
        // below expose clean TimeSpan values to the rest of the code.

        [XmlElement] public int SessionStartHour   { get; set; } = 9;
        [XmlElement] public int SessionStartMinute { get; set; } = 30;
        [XmlElement] public int SessionEndHour     { get; set; } = 12;
        [XmlElement] public int SessionEndMinute   { get; set; } = 0;

        [XmlIgnore]
        public TimeSpan SessionStart =>
            new TimeSpan(SessionStartHour, SessionStartMinute, 0);

        [XmlIgnore]
        public TimeSpan SessionEnd =>
            new TimeSpan(SessionEndHour, SessionEndMinute, 0);

        // =====================================================================
        // Stop-loss / take-profit (in ticks)
        // =====================================================================

        /// <summary>Lower bound of normal stop-loss range.</summary>
        [XmlElement] public int SlTicksMin { get; set; } = 8;

        /// <summary>Upper bound of normal stop-loss range.
        /// Stops wider than 1.3× this value trigger the D2 SL-manipulation signal.</summary>
        [XmlElement] public int SlTicksMax { get; set; } = 20;

        /// <summary>Lower bound of normal take-profit range.</summary>
        [XmlElement] public int TpTicksMin { get; set; } = 10;

        /// <summary>Upper bound of normal take-profit range.
        /// Exits at less than 30 % of this after a loss trigger D4 early-exit signal.</summary>
        [XmlElement] public int TpTicksMax { get; set; } = 40;

        // =====================================================================
        // Position size (contracts / shares / lots)
        // =====================================================================

        [XmlElement] public double SizeMin { get; set; } = 1.0;

        /// <summary>Positions above SizeMax × 1.5 trigger D3 size-outlier signal.</summary>
        [XmlElement] public double SizeMax { get; set; } = 2.0;

        // =====================================================================
        // Trade frequency
        // =====================================================================

        [XmlElement] public int TradesPerSessionMin { get; set; } = 3;
        [XmlElement] public int TradesPerSessionMax { get; set; } = 15;

        // =====================================================================
        // Timing thresholds
        // =====================================================================

        /// <summary>
        /// Seconds after a significant loss within which a new entry is classified
        /// as a potential revenge re-entry (D1).  Default 3 minutes.
        /// Scalpers may set this to as low as 5–30 seconds.
        /// </summary>
        [XmlElement] public int MaxReentrySeconds { get; set; } = 180;

        /// <summary>
        /// Multiplier applied to the D1 (Revenge Entry) score when the new entry
        /// is in the OPPOSITE direction to the just-closed position (a "flip").
        ///
        /// 0.0 = direction-flip trades never contribute to D1 (pure opportunity).
        /// 0.25 = default: flips still register weakly — useful for catching
        ///        over-leveraged flips after a big loss.
        /// 1.0 = treat flips identically to same-direction re-entries.
        ///
        /// Same-direction re-entries after a big loss always use the full score.
        /// </summary>
        [XmlElement] public double ReversalPenaltyFactor { get; set; } = 0.25;

        /// <summary>
        /// Expected maximum hold time in minutes for a losing trade.
        /// Used as cold-start fallback for the D5 position-hold monitor
        /// before 20+ historical losing trades are available.
        /// p90_cold_start = MaxHoldMinutes × 60 × 1.2
        /// </summary>
        [XmlElement] public int MaxHoldMinutes { get; set; } = 30;

        /// <summary>
        /// When true the trader intentionally operates without a stop-loss order
        /// (e.g. purely discretionary exits, mental stops, or bracket orders placed
        /// BEFORE entry so they appear before the fill).
        /// Setting this flag suppresses the naked-position detection entirely —
        /// <see cref="NoStopGraceSeconds"/> has no effect when this is true.
        /// </summary>
        [XmlElement] public bool NoStopLossTrader { get; set; } = false;

        /// <summary>
        /// Seconds after a position opens before the "no stop-loss" check fires.
        /// Allows time for ATM or bracket orders to be placed automatically after entry.
        /// Typical ATM strategy creates its stop within 1–2 s; 20 s is generous.
        /// Set to 0 to disable the naked-position check entirely (e.g. if you always
        /// use manual stops placed before entry, not after).
        /// Ignored when <see cref="NoStopLossTrader"/> is true.
        /// </summary>
        [XmlElement] public int NoStopGraceSeconds { get; set; } = 20;

        // =====================================================================
        // PSI sensitivity  (drives PsiEngineConfig preset selection)
        // =====================================================================

        /// <summary>
        /// Overall sensitivity preset for the PSI engine.
        /// Conservative = D-scores fire earlier, PSI drops faster, recovers slower.
        /// Balanced     = Default tuning (original hard-coded values).
        /// Aggressive   = D-scores require more extreme behaviour, more lenient.
        /// </summary>
        [XmlElement] public PsiSensitivity Sensitivity { get; set; } = PsiSensitivity.Balanced;

        /// <summary>
        /// PSI points deducted for holding a naked position (no stop-loss).
        /// Null = use the preset default.  Overrides cfg.NakedPositionDeduction.
        /// Range: 0–50.
        /// </summary>
        [XmlElement] public double NakedPositionPenalty { get; set; } = -1;

        /// <summary>
        /// PSI points deducted for trading outside the session window.
        /// Null = use the preset default.  Overrides cfg.SessionWindowDeduction.
        /// Range: 0–50.
        /// </summary>
        [XmlElement] public double SessionWindowPenalty { get; set; } = -1;

        /// <summary>
        /// Multiplier on the EWMA recovery speed (default 1.0 = no change).
        /// Less than 1.0 = slower recovery; greater than 1.0 = faster recovery.
        /// Range: 0.25–4.0.
        /// </summary>
        [XmlElement] public double RecoverySpeedMultiplier { get; set; } = -1;

        /// <summary>
        /// Probability of flagging normal behaviour as abnormal.
        /// Controls the z-threshold for all D-score mappings.
        /// -1 = use the preset default.  Valid range: 0.01–0.10.
        /// Lower values = more lenient; higher values = more sensitive.
        /// </summary>
        [XmlElement] public double FalsePositiveRate { get; set; } = -1;

        // =====================================================================
        // Dimension weights  (must sum to 1.0; NormaliseWeights auto-corrects)
        // =====================================================================

        [XmlElement] public double WeightRevengeEntry     { get; set; } = 0.18;
        [XmlElement] public double WeightStopManipulation { get; set; } = 0.23;
        [XmlElement] public double WeightSizeOutlier      { get; set; } = 0.16;
        [XmlElement] public double WeightHoldTimeCollapse { get; set; } = 0.11;
        [XmlElement] public double WeightPositionHold     { get; set; } = 0.14;
        [XmlElement] public double WeightRuleCompliance   { get; set; } = 0.08;
        /// <summary>D7 — Overtrading (session-pace acceleration).</summary>
        [XmlElement] public double WeightOvertrading      { get; set; } = 0.10;

        // =====================================================================
        // Account selection
        // =====================================================================

        /// <summary>
        /// Account names to include in PSI monitoring.
        /// Empty list = monitor ALL accounts (including prop-firm sim accounts).
        /// Populated from the setup UI at first run.
        /// </summary>
        [XmlArray("MonitoredAccounts")]
        [XmlArrayItem("Account")]
        public List<string> MonitoredAccountNames { get; set; } = new List<string>();

        // =====================================================================
        // Test Mode  (time-limited baseline recording pause)
        // =====================================================================

        /// <summary>
        /// When true, baseline recording is suspended regardless of account type.
        /// PSI still computes live but no stats are written to TradeBaseline.
        /// Automatically expires after <see cref="TestModeMinutes"/> minutes
        /// to prevent the user from accidentally leaving it on.
        /// </summary>
        [XmlElement] public bool TestModeEnabled { get; set; } = false;

        /// <summary>Duration in minutes before TestMode auto-expires (default 60).</summary>
        [XmlElement] public int TestModeMinutes { get; set; } = 60;

        /// <summary>
        /// UTC tick when TestMode was activated.  Used for auto-expire calculation.
        /// Not meaningful when <see cref="TestModeEnabled"/> is false.
        /// </summary>
        [XmlElement] public long TestModeActivatedUtcTicks { get; set; } = 0;

        /// <summary>
        /// Returns true if TestMode is currently active (enabled AND not expired).
        /// </summary>
        [XmlIgnore]
        public bool IsTestModeActive
        {
            get
            {
                if (!TestModeEnabled) return false;
                if (TestModeActivatedUtcTicks <= 0) return false;
                var elapsed = DateTime.UtcNow - new DateTime(TestModeActivatedUtcTicks, DateTimeKind.Utc);
                if (elapsed.TotalMinutes > TestModeMinutes)
                {
                    TestModeEnabled = false;
                    return false;
                }
                return true;
            }
        }

        /// <summary>Minutes remaining before TestMode expires; 0 when inactive.</summary>
        [XmlIgnore]
        public int TestModeRemainingMinutes
        {
            get
            {
                if (!IsTestModeActive) return 0;
                var elapsed = DateTime.UtcNow - new DateTime(TestModeActivatedUtcTicks, DateTimeKind.Utc);
                return Math.Max(0, TestModeMinutes - (int)elapsed.TotalMinutes);
            }
        }

        /// <summary>Activate TestMode with the configured duration.</summary>
        public void ActivateTestMode()
        {
            TestModeEnabled            = true;
            TestModeActivatedUtcTicks = DateTime.UtcNow.Ticks;
        }

        /// <summary>Deactivate TestMode immediately.</summary>
        public void DeactivateTestMode()
        {
            TestModeEnabled = false;
        }

        // =====================================================================
        // Computed properties (derived, not serialised)
        // =====================================================================

        /// <summary>
        /// Expected trades per hour during the session window.
        /// Used as the λ (Poisson rate) parameter for the CUSUM / Revenge-Entry
        /// baseline before historical data is available.
        /// </summary>
        [XmlIgnore]
        public double LambdaVelocity
        {
            get
            {
                double hours = (SessionEnd - SessionStart).TotalHours;
                if (hours <= 0) return 5.0;
                double mid = (TradesPerSessionMin + TradesPerSessionMax) / 2.0;
                return mid / hours;
            }
        }

        /// <summary>
        /// Cold-start p90 for losing-trade hold time (seconds).
        /// Replaced by actual historical p90 once ≥ 20 losing trades are recorded.
        /// </summary>
        [XmlIgnore]
        public double ColdStartP90LossHoldSeconds =>
            MaxHoldMinutes * 60.0 * 1.2;

        /// <summary>
        /// Midpoint of the normal size range; used as the profile prior for μ_size.
        /// </summary>
        [XmlIgnore]
        public double SizeMidpoint => (SizeMin + SizeMax) / 2.0;

        /// <summary>Midpoint of the SL tick range.</summary>
        [XmlIgnore]
        public double SlTicksMidpoint => (SlTicksMin + SlTicksMax) / 2.0;

        /// <summary>Midpoint of the TP tick range.</summary>
        [XmlIgnore]
        public double TpTicksMidpoint => (TpTicksMin + TpTicksMax) / 2.0;

        // =====================================================================
        // Persistence
        // =====================================================================

        /// <summary>
        /// Loads from the standard file path.
        /// Returns a new default profile if the file does not exist or cannot be
        /// parsed.  Never throws.
        /// </summary>
        /// <param name="onError">
        /// Optional callback invoked with a human-readable message when an I/O or
        /// parse error occurs.  The caller (TradeMonitor) should forward this to
        /// NT8's Log() so the user sees the warning without the app crashing.
        /// </param>
        public static StrategyProfile LoadFromFile(Action<string> onError = null)
        {
            if (!File.Exists(ProfilePath))
                return new StrategyProfile();

            try
            {
                var xs = new XmlSerializer(typeof(StrategyProfile));
                using (var fs = new FileStream(ProfilePath, FileMode.Open,
                                               FileAccess.Read, FileShare.Read))
                {
                    var profile = (StrategyProfile)xs.Deserialize(fs);
                    profile.NormaliseWeights();
                    return profile;
                }
            }
            catch (Exception ex)
            {
                try { File.Copy(ProfilePath, ProfilePath + ".corrupt." + DateTime.Now.Ticks, overwrite: true); }
                catch { /* backup is best-effort */ }
                onError?.Invoke(
                    $"[TradeMonitor] StrategyProfile 加载失败，已使用默认参数。原因: {ex.Message}");
                return new StrategyProfile();
            }
        }

        /// <summary>
        /// Saves to the standard file path, creating the directory if needed.
        /// Never throws — a persistence failure must not interrupt live monitoring.
        /// </summary>
        /// <param name="onError">
        /// Optional callback invoked with a warning message on failure.
        /// Inject NT8's Log() from TradeMonitor so errors are surfaced to the user.
        /// </param>
        public void SaveToFile(Action<string> onError = null)
        {
            try
            {
                if (!Directory.Exists(DataDir))
                    Directory.CreateDirectory(DataDir);

                NormaliseWeights();

                var xs = new XmlSerializer(typeof(StrategyProfile));
                using (var fs = new FileStream(ProfilePath, FileMode.Create,
                                               FileAccess.Write, FileShare.None))
                    xs.Serialize(fs, this);
            }
            catch (Exception ex)
            {
                onError?.Invoke(
                    $"[TradeMonitor] StrategyProfile 保存失败，本次配置可能不会持久化。原因: {ex.Message}");
            }
        }

        // =====================================================================
        // Validation
        // =====================================================================

        /// <summary>
        /// Validates all fields and auto-corrects minor issues (e.g. weight
        /// normalisation).  Returns a list of human-readable error strings;
        /// empty list means the profile is valid and ready to use.
        /// </summary>
        public List<string> Validate()
        {
            var errors = new List<string>();

            // Session window
            if (SessionStartHour   < 0 || SessionStartHour   > 23 ||
                SessionStartMinute < 0 || SessionStartMinute > 59 ||
                SessionEndHour     < 0 || SessionEndHour     > 23 ||
                SessionEndMinute   < 0 || SessionEndMinute   > 59)
                errors.Add("交易时段中存在无效的小时或分钟值（范围：小时 0-23，分钟 0-59）。");

            if (SessionStart >= SessionEnd)
                errors.Add("交易开始时间必须早于结束时间。");

            // SL / TP ticks
            if (SlTicksMin <= 0 || SlTicksMax <= 0)
                errors.Add("止损 tick 数必须大于 0。");
            else if (SlTicksMin > SlTicksMax)
                errors.Add("止损最小 tick 不能大于最大 tick。");

            if (TpTicksMin <= 0 || TpTicksMax <= 0)
                errors.Add("止盈 tick 数必须大于 0。");
            else if (TpTicksMin > TpTicksMax)
                errors.Add("止盈最小 tick 不能大于最大 tick。");

            // Size
            if (SizeMin <= 0 || SizeMax <= 0)
                errors.Add("正常手数必须大于 0。");
            else if (SizeMin > SizeMax)
                errors.Add("最小手数不能大于最大手数。");

            // Frequency
            if (TradesPerSessionMin <= 0)
                errors.Add("每 Session 最少交易笔数必须大于 0。");
            else if (TradesPerSessionMin > TradesPerSessionMax)
                errors.Add("每 Session 最小笔数不能大于最大笔数。");

            // Timing
            if (MaxReentrySeconds < 0)
                errors.Add("再入场检测窗口不能为负数。");
            if (MaxHoldMinutes <= 0)
                errors.Add("最大持仓时间必须大于 0 分钟。");
            if (NoStopGraceSeconds < 0)
                errors.Add("无止损宽限期不能为负数（设为 0 可禁用该检测）。");

            // Weights — auto-corrected, no error message needed
            NormaliseWeights();

            return errors;
        }

        // =====================================================================
        // Helpers
        // =====================================================================

        /// <summary>
        /// Returns true if the given account name should contribute to PSI.
        /// Empty MonitoredAccountNames means monitor everything.
        /// </summary>
        public bool ShouldMonitor(string accountName)
        {
            if (string.IsNullOrEmpty(accountName))       return false;
            if (MonitoredAccountNames == null ||
                MonitoredAccountNames.Count == 0)        return true;
            return MonitoredAccountNames.Contains(accountName);
        }

        // =====================================================================
        // Private helpers
        // =====================================================================

        /// <summary>
        /// Clamps all weights to [0, ∞) then re-scales so they sum to 1.0.
        /// If every weight is zero or negative, resets to built-in defaults.
        /// </summary>
        private void NormaliseWeights()
        {
            // 1. Clamp to non-negative (guards against hand-edited XML)
            WeightRevengeEntry     = Math.Max(0, WeightRevengeEntry);
            WeightStopManipulation = Math.Max(0, WeightStopManipulation);
            WeightSizeOutlier      = Math.Max(0, WeightSizeOutlier);
            WeightHoldTimeCollapse = Math.Max(0, WeightHoldTimeCollapse);
            WeightPositionHold     = Math.Max(0, WeightPositionHold);
            WeightRuleCompliance   = Math.Max(0, WeightRuleCompliance);
            WeightOvertrading      = Math.Max(0, WeightOvertrading);

            double total = WeightRevengeEntry + WeightStopManipulation +
                           WeightSizeOutlier  + WeightHoldTimeCollapse +
                           WeightPositionHold + WeightRuleCompliance   +
                           WeightOvertrading;

            // 2. If all zero, reset to defaults
            if (total <= 0)
            {
                WeightRevengeEntry     = 0.18;
                WeightStopManipulation = 0.23;
                WeightSizeOutlier      = 0.16;
                WeightHoldTimeCollapse = 0.11;
                WeightPositionHold     = 0.14;
                WeightRuleCompliance   = 0.08;
                WeightOvertrading      = 0.10;
                return;
            }

            // 3. Already normalised (within floating-point tolerance)
            if (Math.Abs(total - 1.0) < 0.001) return;

            // 4. Re-scale
            WeightRevengeEntry     /= total;
            WeightStopManipulation /= total;
            WeightSizeOutlier      /= total;
            WeightHoldTimeCollapse /= total;
            WeightPositionHold     /= total;
            WeightRuleCompliance   /= total;
            WeightOvertrading      /= total;
        }
    }
}
