// TradeBaseline.cs
//
// Accumulates long-term trading statistics using online algorithms (O(1) per
// update, no unbounded memory growth) and provides the blended baseline values
// consumed by PsiEngine.
//
// Two classes are co-located here because both are purely statistical data
// holders with no NinjaTrader API dependencies:
//
//   WelfordStat       — online mean + variance accumulator (Welford's algorithm)
//   PositionSnapshot  — immutable snapshot of an open position for D5 polling
//   TradeBaseline     — root statistics container with persistence

using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Serialization;

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================================
    // WelfordStat
    // =========================================================================

    /// <summary>
    /// Online mean and variance accumulator using Welford's numerically-stable
    /// algorithm.  O(1) per update, no array storage required.
    /// Serialised as part of TradeBaseline.
    /// </summary>
    public sealed class WelfordStat
    {
        /// <summary>Number of samples seen so far.</summary>
        [XmlElement] public int    N    { get; set; } = 0;

        /// <summary>Running mean.</summary>
        [XmlElement] public double Mean { get; set; } = 0.0;

        /// <summary>Running sum of squared deviations (internal Welford accumulator).</summary>
        [XmlElement] public double M2   { get; set; } = 0.0;

        /// <summary>Sample variance (undefined / returns 0 when N &lt; 2).</summary>
        [XmlIgnore] public double Variance => N >= 2 ? M2 / (N - 1) : 0.0;

        /// <summary>Sample standard deviation.</summary>
        [XmlIgnore] public double StdDev => Math.Sqrt(Variance);

        /// <summary>True once at least <paramref name="minN"/> samples have arrived.</summary>
        public bool HasEnoughData(int minN = 5) => N >= minN;

        /// <summary>Incorporate one new observation.</summary>
        public void Update(double x)
        {
            N++;
            double delta  = x - Mean;
            Mean         += delta / N;
            double delta2 = x - Mean;   // note: uses the updated mean
            M2           += delta * delta2;
        }
    }

    // =========================================================================
    // PositionSnapshot
    // =========================================================================

    /// <summary>
    /// Immutable snapshot of a single open position captured by the 30-second
    /// timer tick.  Passed to PsiEngine.PollPositions() for D5 (扛单) scoring.
    /// </summary>
    public sealed class PositionSnapshot
    {
        /// <summary>Unique key — typically Instrument.MasterInstrument.Name + account.</summary>
        public string   Key            { get; set; }

        /// <summary>Current unrealised PnL in account currency (negative = loss).</summary>
        public double   UnrealizedPnl  { get; set; }

        /// <summary>
        /// Maximum adverse excursion (MAE) — the lowest unrealised PnL seen while
        /// this position was open.  Initialised at 0 and updated downward by
        /// TradeMonitor on every timer tick.  Always ≤ 0.
        /// D5 uses this so that a position which was deep underwater but has
        /// since recovered to breakeven/profit still reflects its worst-case
        /// psychological stress, not the current comforting PnL.
        /// </summary>
        public double   MinUnrealizedPnl { get; set; }

        /// <summary>Wall-clock time when this position was opened.</summary>
        public DateTime EntryTime      { get; set; }

        /// <summary>Seconds elapsed since entry (computed at snapshot time).</summary>
        public double HoldSeconds { get; set; }

        /// <summary>
        /// True when the platform reports at least one Working Stop (StopMarket or
        /// StopLimit) order covering this position's direction.  False means the
        /// position is currently "naked" — no stop-loss protection.
        /// Always true for positions in profit (D5/naked check only penalises
        /// unprotected LOSING exposure, but the flag is position-level, not P&L-level,
        /// so callers must pass the real value regardless of P&L).
        /// </summary>
        public bool HasStopOrder { get; set; } = true;

        /// <summary>
        /// Net open quantity (contracts / lots) for this position.
        /// Used by PsiEngine.PollPositions to compute total live exposure for the
        /// real-time D3 oversize alarm.
        /// </summary>
        public double Quantity { get; set; }

        /// <param name="platformNow">
        /// Current platform time (pass NinjaTrader.Core.Globals.Now from the caller so
        /// that Playback/Simulation mode uses the replay clock, not the wall clock).
        /// Defaults to DateTime.Now when called from unit tests or contexts without NT8.
        /// </param>
        /// <param name="hasStopOrder">
        /// Whether a covering stop-loss order is currently working for this position.
        /// Pass false when <see cref="BuildPositionSnapshots"/> finds no Working stop.
        /// </param>
        /// <param name="quantity">
        /// Net open quantity for this position.  Used for live D3 exposure monitoring.
        /// </param>
        public static PositionSnapshot Create(string key, double pnl, DateTime entryTime,
                                              DateTime platformNow = default,
                                              bool hasStopOrder = true,
                                              double quantity = 0.0,
                                              double minPnl = 0.0)
        {
            DateTime now = platformNow == default ? DateTime.Now : platformNow;
            return new PositionSnapshot
            {
                Key              = key,
                UnrealizedPnl    = pnl,
                MinUnrealizedPnl = Math.Min(minPnl, 0.0), // always ≤ 0
                EntryTime        = entryTime,
                HoldSeconds      = Math.Max(0, (now - entryTime).TotalSeconds),
                HasStopOrder     = hasStopOrder,
                Quantity         = quantity,
            };
        }
    }

    // =========================================================================
    // TradeBaseline
    // =========================================================================

    /// <summary>
    /// Root statistics container.  Exposes:
    /// <list type="bullet">
    ///   <item>Long-term Welford stats (persisted across restarts)</item>
    ///   <item>Session-level accumulators (reset each StartNewSession)</item>
    ///   <item>Percentile cache for D5 (p50/p90 of losing hold times)</item>
    ///   <item>Blend helper: transitions from profile prior to observed history</item>
    /// </list>
    /// All public methods are thread-safe (single internal lock).
    /// </summary>
    [XmlRoot("TradeBaseline")]
    public sealed class TradeBaseline
    {
        // -----------------------------------------------------------------
        // File path
        // -----------------------------------------------------------------

        private static string DataDir = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
            "NinjaTrader 8", "bin", "Custom", "AddOns", "TradeMonitorData");

        /// <inheritdoc cref="StrategyProfile.SetDataDir"/>
        internal static void SetDataDir(string path)
        {
            if (!string.IsNullOrEmpty(path)) DataDir = path;
        }

        public static string BaselinePath => Path.Combine(DataDir, "baseline.xml");

        // -----------------------------------------------------------------
        // Thread-safety
        // -----------------------------------------------------------------

        private readonly object _sync = new object();

        // -----------------------------------------------------------------
        // Long-term statistics  (persisted)
        // -----------------------------------------------------------------

        /// <summary>Absolute value of losing trades (account currency).</summary>
        [XmlElement] public WelfordStat MuLoss     { get; set; } = new WelfordStat();

        /// <summary>Position size in contracts/shares/lots.</summary>
        [XmlElement] public WelfordStat MuSize     { get; set; } = new WelfordStat();

        /// <summary>Winning-trade hold time in seconds.</summary>
        [XmlElement] public WelfordStat WinHold    { get; set; } = new WelfordStat();

        /// <summary>Losing-trade hold time in seconds.</summary>
        [XmlElement] public WelfordStat LossHold   { get; set; } = new WelfordStat();

        /// <summary>Realised Risk:Reward ratio per completed round-trip.</summary>
        [XmlElement] public WelfordStat RiskReward { get; set; } = new WelfordStat();

        /// <summary>
        /// Rolling window of up to 500 losing-trade hold times (seconds).
        /// Used to compute p50 and p90 for D5 (position-hold monitor).
        /// Capped to keep the XML file small.
        /// </summary>
        [XmlArray("LossHoldSamples")]
        [XmlArrayItem("s")]
        public List<double> LossHoldTimeSamples { get; set; } = new List<double>();

        /// <summary>Number of complete trading sessions recorded so far.
        /// Drives the profile-to-history blend weight.</summary>
        [XmlElement] public int    SessionCount        { get; set; } = 0;

        // Ring-write index for LossHoldTimeSamples — NOT persisted.
        // Allows O(1) overwrite of the oldest slot once the cap is reached,
        // instead of O(n) RemoveAt(0) which shifts all 500 elements on each loss.
        [XmlIgnore] private int _lossHoldWriteIdx = 0;

        /// <summary>PSI value at the end of the previous session.
        /// Used by PsiEngine.StartNewSession() to determine the opening PSI.</summary>
        [XmlElement] public double LastSessionFinalPsi { get; set; } = 100.0;

        // -----------------------------------------------------------------
        // Violation frequency counters  (persisted for rarity-scaled deductions)
        //
        // Scientific basis: information-theoretic surprise.  Shannon (1948):
        //   info(event) = -log2(P(event)).
        // A violation that has NEVER been observed (freq→0) carries maximal
        // information and warrants the full penalty.  A habitual violation
        // (freq→0.5) carries only 1 bit and warrants a reduced penalty.
        // -----------------------------------------------------------------

        /// <summary>Total 30-second poll cycles across all sessions.</summary>
        [XmlElement] public int TotalPositionPolls    { get; set; } = 0;

        /// <summary>How many poll cycles detected a naked (no stop-loss) position.</summary>
        [XmlElement] public int NakedPositionCount    { get; set; } = 0;

        /// <summary>Total trade execution events across all sessions.</summary>
        [XmlElement] public int TotalTradeEvents      { get; set; } = 0;

        /// <summary>How many trade events occurred outside the declared session window.</summary>
        [XmlElement] public int SessionWindowViolCount { get; set; } = 0;

        // -----------------------------------------------------------------
        // Session-level accumulators  (NOT persisted — reset each session)
        // -----------------------------------------------------------------

        private int    _sessionTradeCount  = 0;
        private int    _sessionWinCount    = 0;
        private int    _sessionLossCount   = 0;
        private double _sessionSumWinHold  = 0.0;
        private double _sessionSumLossHold = 0.0;

        // -----------------------------------------------------------------
        // Percentile cache  (invalidated whenever a new sample arrives)
        // -----------------------------------------------------------------

        private bool   _pctCacheDirty = true;   // true after deserialization, correct
        private double _cachedP50     = 0.0;
        private double _cachedP90     = 0.0;

        // -----------------------------------------------------------------
        // Session-level computed properties
        // -----------------------------------------------------------------

        [XmlIgnore] public int SessionTradeCount => _sessionTradeCount;
        [XmlIgnore] public int SessionWinCount   => _sessionWinCount;
        [XmlIgnore] public int SessionLossCount  => _sessionLossCount;

        /// <summary>
        /// Average winning-trade hold time (seconds) for the current session.
        /// Falls back to the long-term mean when no session wins exist yet.
        /// </summary>
        [XmlIgnore]
        public double SessionAvgWinHold
        {
            get
            {
                lock (_sync)
                {
                    if (_sessionWinCount > 0)
                        return _sessionSumWinHold / _sessionWinCount;
                    return WinHold.N > 0 ? WinHold.Mean : 60.0;   // cold-start fallback
                }
            }
        }

        /// <summary>
        /// Average losing-trade hold time (seconds) for the current session.
        /// Falls back to the long-term mean when no session losses exist yet.
        /// </summary>
        [XmlIgnore]
        public double SessionAvgLossHold
        {
            get
            {
                lock (_sync)
                {
                    if (_sessionLossCount > 0)
                        return _sessionSumLossHold / _sessionLossCount;
                    return LossHold.N > 0 ? LossHold.Mean : 120.0; // cold-start fallback
                }
            }
        }

        // -----------------------------------------------------------------
        // Effective baseline values (blend of profile prior + history)
        // -----------------------------------------------------------------

        /// <summary>
        /// Effective average loss amount (account currency).
        /// Cold-start fallback is $100 until 5 losses are recorded.
        /// After that, blends profile default with observed mean.
        /// </summary>
        public double GetEffectiveMuLoss()
        {
            lock (_sync)
            {
                // $100 cold-start default — acceptable error margin for D1/D5 until
                // real data arrives.  Replaced within the first 5 losing trades.
                if (!MuLoss.HasEnoughData(5))
                    return 100.0;

                return MuLoss.Mean;
            }
        }

        /// <summary>
        /// Effective mean position size.
        /// </summary>
        public double GetEffectiveMuSize(StrategyProfile profile)
        {
            lock (_sync)
            {
                double prior = profile.SizeMidpoint;
                if (!MuSize.HasEnoughData(5)) return prior;
                double w = Math.Exp(-SessionCount / 30.0);
                return w * prior + (1.0 - w) * MuSize.Mean;
            }
        }

        /// <summary>
        /// Effective loss standard deviation.  Used as the denominator in z-score
        /// calculations: z = (|pnl| − muLoss) / sigmaLoss.
        /// Cold-start fallback: CV = 0.5 (midpoint of the empirical 0.3–0.8 range
        /// observed in intraday futures loss distributions).
        /// </summary>
        public double GetEffectiveSigmaLoss()
        {
            lock (_sync)
            {
                if (!MuLoss.HasEnoughData(10))
                    return Math.Max(1.0, GetEffectiveMuLoss() * 0.5);
                return Math.Max(1.0, MuLoss.StdDev);
            }
        }

        /// <summary>
        /// Effective size standard deviation (floored at 0.1 to prevent division by zero).
        /// </summary>
        public double GetEffectiveSigmaSize(StrategyProfile profile)
        {
            lock (_sync)
            {
                // Profile-based sigma estimate: (max−min)/4 covers ~95% of a normal range
                double profileSigma = Math.Max(0.1, (profile.SizeMax - profile.SizeMin) / 4.0);
                if (!MuSize.HasEnoughData(10)) return profileSigma;
                return Math.Max(0.1, MuSize.StdDev);
            }
        }

        /// <summary>
        /// Effective mean winning-trade hold time (seconds).
        /// </summary>
        public double GetEffectiveMuWinHold(StrategyProfile profile)
        {
            lock (_sync)
            {
                // Prior: 25 % of the max-hold cap.  This mirrors the loss-hold prior
                // (50 % of max) and produces instrument-agnostic, style-neutral values:
                //   MaxHold 2 min (scalper)  → prior ≈ 30 s
                //   MaxHold 5 min (intraday) → prior ≈ 75 s
                //   MaxHold 30 min (swing)   → prior ≈ 450 s
                // The old "TpTicksMidpoint × 3 s" heuristic over-estimated for fast
                // instruments (MNQ, NQ) where large tick TPs still close in < 30 s.
                double profilePrior = profile.MaxHoldMinutes * 60.0 * 0.25;
                if (!WinHold.HasEnoughData(5)) return profilePrior;
                double w = Math.Exp(-SessionCount / 30.0);
                return w * profilePrior + (1.0 - w) * WinHold.Mean;
            }
        }

        /// <summary>
        /// Effective mean losing-trade hold time (seconds).
        /// </summary>
        public double GetEffectiveMuLossHold(StrategyProfile profile)
        {
            lock (_sync)
            {
                double profilePrior = profile.MaxHoldMinutes * 60.0 * 0.5; // 50 % of max
                if (!LossHold.HasEnoughData(5)) return profilePrior;
                double w = Math.Exp(-SessionCount / 30.0);
                return w * profilePrior + (1.0 - w) * LossHold.Mean;
            }
        }

        // -----------------------------------------------------------------
        // Percentile queries for D5 (position-hold monitor)
        // -----------------------------------------------------------------

        /// <summary>
        /// Median (p50) losing-trade hold time in seconds.
        /// Returns Profile cold-start estimate when fewer than 20 samples exist.
        /// </summary>
        public double GetP50LossHold(StrategyProfile profile)
        {
            lock (_sync)
            {
                if (LossHoldTimeSamples.Count < 20)
                    return profile.ColdStartP90LossHoldSeconds * 0.55; // p50 ≈ 55% of p90
                EnsurePercentileCache();
                return _cachedP50;
            }
        }

        /// <summary>
        /// 90th-percentile losing-trade hold time in seconds.
        /// Returns Profile cold-start estimate when fewer than 20 samples exist.
        /// </summary>
        public double GetP90LossHold(StrategyProfile profile)
        {
            lock (_sync)
            {
                if (LossHoldTimeSamples.Count < 20)
                    return profile.ColdStartP90LossHoldSeconds;
                EnsurePercentileCache();
                return _cachedP90;
            }
        }

        // -----------------------------------------------------------------
        // Violation frequency queries
        // -----------------------------------------------------------------

        /// <summary>
        /// Fraction of poll cycles where a naked position was observed.
        /// Returns 0.0 during cold-start (fewer than 100 polls) to assume
        /// violations are rare and apply full penalty.
        /// </summary>
        public double GetNakedFrequency()
        {
            lock (_sync)
            {
                if (TotalPositionPolls < 100) return 0.0;
                return (double)NakedPositionCount / TotalPositionPolls;
            }
        }

        /// <summary>
        /// Fraction of trade events that occurred outside the declared session window.
        /// Returns 0.0 during cold-start (fewer than 20 events).
        /// </summary>
        public double GetWindowViolationFrequency()
        {
            lock (_sync)
            {
                if (TotalTradeEvents < 20) return 0.0;
                return (double)SessionWindowViolCount / TotalTradeEvents;
            }
        }

        // -----------------------------------------------------------------
        // Update from execution
        // -----------------------------------------------------------------

        /// <summary>
        /// Call on every confirmed fill.  Updates both long-term Welford stats
        /// and the session-level accumulators.  Thread-safe.
        /// </summary>
        /// <param name="pnl">Gross PnL of the completed trade (negative = loss).</param>
        /// <param name="size">Fill quantity in contracts/shares.</param>
        /// <param name="holdSeconds">Time from entry to exit in seconds.</param>
        /// <param name="isWin">True if pnl &gt; 0.</param>
        public void UpdateOnExecution(double pnl, double size, double holdSeconds, bool isWin)
        {
            lock (_sync)
            {
                _sessionTradeCount++;

                // Size — always tracked regardless of outcome
                if (size > 0) MuSize.Update(size);

                if (isWin)
                {
                    _sessionWinCount++;
                    _sessionSumWinHold += holdSeconds;
                    WinHold.Update(Math.Max(0, holdSeconds));

                    // Risk:Reward update — we track |pnl_win| / μ_loss (running average loss)
                    if (MuLoss.N > 0 && MuLoss.Mean > 0)
                        RiskReward.Update(Math.Abs(pnl) / MuLoss.Mean);
                }
                else
                {
                    double absLoss = Math.Abs(pnl);

                    if (absLoss > 0) MuLoss.Update(absLoss);

                    _sessionLossCount++;
                    _sessionSumLossHold += holdSeconds;
                    LossHold.Update(Math.Max(0, holdSeconds));

                    // Add to percentile sample window (capped at 500)
                    if (LossHoldTimeSamples.Count >= 500)
                    {
                        // O(1) ring overwrite — percentile calc sorts the list anyway,
                        // so insertion order is irrelevant.
                        LossHoldTimeSamples[_lossHoldWriteIdx % 500] = holdSeconds;
                        _lossHoldWriteIdx++;
                    }
                    else
                    {
                        LossHoldTimeSamples.Add(holdSeconds);
                    }
                    _pctCacheDirty = true;
                }
            }
        }

        // -----------------------------------------------------------------
        // Session lifecycle
        // -----------------------------------------------------------------

        /// <summary>
        /// Call at the start of every trading session (e.g. when NT8 transitions
        /// to connected/live).  Records the previous session's final PSI, increments
        /// the session counter (which shifts blend weights toward history), resets
        /// intra-session accumulators, and auto-saves.
        /// </summary>
        public void StartNewSession(double previousSessionFinalPsi,
                                   Action<string> onError = null)
        {
            lock (_sync)
            {
                LastSessionFinalPsi = previousSessionFinalPsi;
                SessionCount++;

                _sessionTradeCount  = 0;
                _sessionWinCount    = 0;
                _sessionLossCount   = 0;
                _sessionSumWinHold  = 0.0;
                _sessionSumLossHold = 0.0;
            }

            // Persist outside the lock to avoid holding it during I/O
            SaveToFile(onError);
        }

        // -----------------------------------------------------------------
        // Persistence
        // -----------------------------------------------------------------

        /// <summary>
        /// Loads the baseline from disk.  Returns a fresh default instance
        /// (and never throws) if the file is absent or corrupted.
        /// </summary>
        /// <param name="onError">
        /// Optional callback invoked with a warning message on failure.
        /// Inject NT8's Log() from TradeMonitor so the user is informed.
        /// </param>
        public static TradeBaseline LoadFromFile(Action<string> onError = null)
        {
            if (!File.Exists(BaselinePath))
                return new TradeBaseline();

            try
            {
                var xs = new XmlSerializer(typeof(TradeBaseline));
                using (var fs = new FileStream(BaselinePath, FileMode.Open,
                                               FileAccess.Read, FileShare.Read))
                    return (TradeBaseline)xs.Deserialize(fs);
            }
            catch (Exception ex)
            {
                try { File.Copy(BaselinePath, BaselinePath + ".corrupt." + DateTime.Now.Ticks, overwrite: true); }
                catch { /* backup is best-effort */ }
                onError?.Invoke(
                    $"[TradeMonitor] TradeBaseline 加载失败，历史基线已重置。原因: {ex.Message}");
                return new TradeBaseline();
            }
        }

        /// <summary>
        /// Saves to disk.  Never throws — persistence failure must not interrupt
        /// the live monitoring engine.
        /// </summary>
        /// <param name="onError">
        /// Optional callback invoked with a warning message on failure.
        /// </param>
        public void SaveToFile(Action<string> onError = null)
        {
            try
            {
                if (!Directory.Exists(DataDir))
                    Directory.CreateDirectory(DataDir);

                string tempPath = BaselinePath + ".tmp";
                try
                {
                    if (File.Exists(tempPath))
                        File.Delete(tempPath);
                }
                catch { /* stale temp from interrupted save */ }
                var xs = new XmlSerializer(typeof(TradeBaseline));
                using (var fs = new FileStream(tempPath, FileMode.Create,
                                               FileAccess.Write, FileShare.None))
                    xs.Serialize(fs, this);

                if (File.Exists(BaselinePath))
                    File.Delete(BaselinePath);
                File.Move(tempPath, BaselinePath);
            }
            catch (Exception ex)
            {
                onError?.Invoke(
                    $"[TradeMonitor] TradeBaseline 保存失败，本次数据可能不会持久化。原因: {ex.Message}");
            }
        }

        // -----------------------------------------------------------------
        // Private helpers
        // -----------------------------------------------------------------

        /// <summary>
        /// Sorts the loss-hold sample list and updates the p50/p90 cache.
        /// Called only from within the lock; callers must hold _sync.
        /// </summary>
        private void EnsurePercentileCache()
        {
            if (!_pctCacheDirty) return;

            var sorted = new List<double>(LossHoldTimeSamples);
            sorted.Sort();
            int n = sorted.Count;

            if (n == 0)
            {
                _cachedP50 = 0;
                _cachedP90 = 0;
            }
            else
            {
                // Clamp indices to valid range
                int i50 = Math.Min((int)(n * 0.50), n - 1);
                int i90 = Math.Min((int)(n * 0.90), n - 1);
                _cachedP50 = sorted[i50];
                _cachedP90 = sorted[i90];
            }

            _pctCacheDirty = false;
        }
    }
}
