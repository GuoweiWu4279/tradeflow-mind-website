// LicenseManager.cs
//
// Manages the trial countdown and Lemon Squeezy license key activation for
// TradeMonitor PSI.
//
// Two-layer protection:
//   Trial   — Machine-bound 7-day encrypted countdown (no internet required,
//             no credit card).  trial.dat is AES-encrypted with a key derived
//             from the Windows MachineGuid so copying the file to another
//             machine resets the trial.
//   License — Lemon Squeezy license key validated against their hosted API.
//             Result is cached in encrypted license.dat for a 7-day offline
//             grace period so prop-firm firewalls don't lock users out.
//
// No NinjaTrader API dependencies — independently unit-testable.

using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Win32;

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================================
    // LicenseStatus
    // =========================================================================

    public enum LicenseStatus
    {
        /// <summary>First install, trial period has not expired.</summary>
        Trial_Active,

        /// <summary>Trial period has expired. No valid license key entered.</summary>
        Trial_Expired,

        /// <summary>Valid license key, subscription active.</summary>
        Licensed,

        /// <summary>
        /// License was valid at last check but server is unreachable.
        /// Full functionality preserved for up to <see cref="LicenseManager.GraceDays"/> days.
        /// </summary>
        Offline_Grace,

        /// <summary>Subscription has expired or been cancelled.</summary>
        Expired,

        /// <summary>License key is invalid, revoked, or entered incorrectly.</summary>
        Invalid,
    }

    // =========================================================================
    // LicenseManager
    // =========================================================================

    public sealed class LicenseManager
    {
        // =====================================================================
        // Public constants (visible to UI layer)
        // =====================================================================

        public const int TrialDays = 7;
        public const int GraceDays = 7;

        // ── Update this URL to your actual Lemon Squeezy storefront ──────────
        public const string StoreUrl = "https://psitrademonitor.lemonsqueezy.com";

        // ── Host a small JSON file at this URL to enable in-app update checks ─
        // Format: { "version": "1.0.1", "notes": "Bug fix description", "download": "https://..." }
        // Update the file on your server whenever you release a new version.
        public const string VersionCheckUrl = "https://psitrademonitor.com/version.json";

        // =====================================================================
        // Internal constants
        // =====================================================================

        private const int    ApiTimeoutSec  = 10;
        private const string ActivateUrl    = "https://api.lemonsqueezy.com/v1/licenses/activate";
        private const string ValidateUrl    = "https://api.lemonsqueezy.com/v1/licenses/validate";
        private const string DeactivateUrl  = "https://api.lemonsqueezy.com/v1/licenses/deactivate";

        private const string TrialFile      = "trial.dat";
        private const string LicenseFile    = "license.dat";

        // Salt strings for AES key derivation.
        // Security comes from binding the key to the MachineId, not from these strings.
        private const string TrialSalt      = "tm-trial-v1";
        private const string LicenseSalt    = "tm-license-v1";

        // =====================================================================
        // Data directory — injected by TradeMonitor (same as other data files)
        // =====================================================================

        private static string _dataDir;

        internal static void SetDataDir(string path)
        {
            if (!string.IsNullOrEmpty(path)) _dataDir = path;
        }

        // =====================================================================
        // Machine ID — injected from TradeMonitor using NT8's own fingerprint API
        // (NinjaTrader.Core.Globals.GenerateLicenseCode).  Falls back to Windows
        // MachineGuid if the NT8 API is unavailable (unit tests, edge cases).
        //
        // Using NT8's fingerprint instead of raw Windows MachineGuid means:
        //   • Reinstalling Windows does NOT invalidate the user's activation.
        //   • The license is bound to the NT8 installation, which is the correct
        //     semantic unit for an NT8 AddOn product.
        //   • Consistent with how other commercial NT8 vendors (e.g. Replikanto)
        //     identify machines.
        // =====================================================================

        private static string _injectedMachineId;

        /// <summary>
        /// Call once from TradeMonitor.OnStateChange(Configure) with the result of
        /// NinjaTrader.Core.Globals.GenerateLicenseCode() so the license is bound
        /// to the NT8 installation rather than the underlying Windows OS.
        /// </summary>
        internal static void SetMachineId(string ntLicenseCode)
        {
            if (!string.IsNullOrEmpty(ntLicenseCode))
                _injectedMachineId = ntLicenseCode;
        }

        private static string TrialPath   => Path.Combine(_dataDir ?? "", TrialFile);
        private static string LicensePath => Path.Combine(_dataDir ?? "", LicenseFile);

        // =====================================================================
        // Runtime state
        // =====================================================================

        private LicenseStatus _status             = LicenseStatus.Trial_Active;
        private string        _key                = null;
        private string        _instanceId         = null;
        private int           _trialDaysRemaining = TrialDays;

        private readonly object _sync = new object();

        // One HttpClient per AppDomain is the correct pattern.
        private static readonly HttpClient _http = new HttpClient
        {
            Timeout = TimeSpan.FromSeconds(ApiTimeoutSec)
        };

        // =====================================================================
        // Public properties
        // =====================================================================

        public LicenseStatus Status
        {
            get { lock (_sync) { return _status; } }
        }

        /// <summary>Days remaining in the trial; 0 when trial has expired or license is active.</summary>
        public int TrialDaysRemaining
        {
            get { lock (_sync) { return _trialDaysRemaining; } }
        }

        /// <summary>The currently stored license key, or null if none has been entered.</summary>
        public string LicenseKey
        {
            get { lock (_sync) { return _key; } }
        }

        /// <summary>True when the plugin should function normally.</summary>
        public bool IsFunctional =>
            Status == LicenseStatus.Trial_Active  ||
            Status == LicenseStatus.Licensed      ||
            Status == LicenseStatus.Offline_Grace;

        // =====================================================================
        // Initialise — call once from TradeMonitor.OnStateChange(Configure)
        // Runs async so NT8 startup is never blocked.
        // =====================================================================

        public async Task InitialiseAsync()
        {
            try
            {
                // ── Step 1: Is there a saved license key? ─────────────────────
                var cached = LoadLicenseCache();
                if (cached != null)
                {
                    lock (_sync) { _key = cached.Key; _instanceId = cached.InstanceId; }

                    var online = await ValidateOnlineAsync(cached.Key, cached.InstanceId);
                    if (online.HasValue)
                    {
                        SaveLicenseCache(cached.Key, cached.InstanceId, online.Value);
                        lock (_sync) { _status = online.Value; }
                    }
                    else
                    {
                        // Server unreachable — honour cached result within grace period.
                        var age = DateTime.UtcNow - cached.ValidatedAt;
                        lock (_sync)
                        {
                            _status = age.TotalDays <= GraceDays && cached.WasLicensed
                                ? LicenseStatus.Offline_Grace
                                : (age.TotalDays <= GraceDays ? cached.CachedStatus : LicenseStatus.Expired);
                        }
                    }
                    return;
                }

                // ── Step 2: No license key — fall back to trial countdown ─────
                var trial   = LoadOrCreateTrial();
                var elapsed = DateTime.UtcNow - trial.StartUtc;
                int remaining = Math.Max(0, TrialDays - (int)elapsed.TotalDays);

                lock (_sync)
                {
                    _trialDaysRemaining = remaining;
                    _status = remaining > 0
                        ? LicenseStatus.Trial_Active
                        : LicenseStatus.Trial_Expired;
                }
            }
            catch
            {
                // Fail open — a broken licence check must never crash NT8.
                lock (_sync) { _status = LicenseStatus.Trial_Active; }
            }
        }

        // =====================================================================
        // Activate — called when user clicks Activate in the License tab
        // Returns (true, null) on success; (false, errorMessage) on failure.
        // =====================================================================

        public async Task<(bool Success, string ErrorMessage)> ActivateAsync(string rawKey)
        {
            string key = rawKey?.Trim().ToUpperInvariant() ?? "";
            if (string.IsNullOrEmpty(key))
                return (false, "请输入 License Key。");

            try
            {
                string machineId = GetMachineId();

                var content = new FormUrlEncodedContent(new[]
                {
                    new KeyValuePair<string, string>("license_key",   key),
                    new KeyValuePair<string, string>("instance_name", machineId),
                });

                var resp = await _http.PostAsync(ActivateUrl, content);
                string body = await resp.Content.ReadAsStringAsync();

                if (resp.IsSuccessStatusCode && body.Contains("\"activated\":true"))
                {
                    string instanceId = ExtractJsonString(body, "id", withinObject: "instance");
                    SaveLicenseCache(key, instanceId, LicenseStatus.Licensed);
                    lock (_sync)
                    {
                        _key        = key;
                        _instanceId = instanceId;
                        _status     = LicenseStatus.Licensed;
                    }
                    return (true, null);
                }

                // Key already activated for this machine (reinstall case) — validate instead.
                if (body.Contains("already been activated") || body.Contains("instance_name"))
                {
                    var revalidated = await ValidateOnlineAsync(key, null);
                    if (revalidated == LicenseStatus.Licensed)
                    {
                        string instanceId = ExtractJsonString(body, "id", withinObject: "instance");
                        SaveLicenseCache(key, instanceId, LicenseStatus.Licensed);
                        lock (_sync)
                        {
                            _key        = key;
                            _instanceId = instanceId;
                            _status     = LicenseStatus.Licensed;
                        }
                        return (true, null);
                    }
                }

                string errMsg = ExtractJsonString(body, "error");
                return (false, string.IsNullOrEmpty(errMsg)
                    ? "激活失败，请检查 License Key 是否正确。"
                    : errMsg);
            }
            catch (TaskCanceledException)
            {
                return (false, "连接超时，请检查网络后重试。");
            }
            catch (Exception ex)
            {
                return (false, $"激活出错: {ex.Message}");
            }
        }

        // =====================================================================
        // Deactivate — frees this machine's activation slot so the key can be
        // used on a different computer.
        // =====================================================================

        public async Task<(bool Success, string ErrorMessage)> DeactivateAsync()
        {
            string key;
            string instanceId;
            lock (_sync)
            {
                key        = _key;
                instanceId = _instanceId;
            }

            if (string.IsNullOrEmpty(key))
                return (false, "没有已激活的 License Key。");

            try
            {
                var pairs = new List<KeyValuePair<string, string>>
                {
                    new KeyValuePair<string, string>("license_key", key),
                };
                if (!string.IsNullOrEmpty(instanceId))
                    pairs.Add(new KeyValuePair<string, string>("instance_id", instanceId));

                var resp = await _http.PostAsync(DeactivateUrl, new FormUrlEncodedContent(pairs));
                string body = await resp.Content.ReadAsStringAsync();

                if (resp.IsSuccessStatusCode && body.Contains("\"deactivated\":true"))
                {
                    // Remove local cache so the key can be re-activated elsewhere.
                    try { if (File.Exists(LicensePath)) File.Delete(LicensePath); } catch { }

                    lock (_sync)
                    {
                        _key        = null;
                        _instanceId = null;
                        _status     = LicenseStatus.Trial_Expired;
                    }
                    return (true, null);
                }

                string err = ExtractJsonString(body, "error");
                return (false, string.IsNullOrEmpty(err) ? "注销失败，请稍后重试。" : err);
            }
            catch (TaskCanceledException)
            {
                return (false, "连接超时，请检查网络后重试。");
            }
            catch (Exception ex)
            {
                return (false, $"注销出错: {ex.Message}");
            }
        }

        // =====================================================================
        // Machine ID — stable per NT8 installation (preferred) or Windows OS
        // (fallback).  Used as instance_name in Lemon Squeezy so reinstalling
        // on the same machine / same NT8 install reuses the activation slot.
        // =====================================================================

        public static string GetMachineId()
        {
            // Use the NT8-injected fingerprint when available (set at startup
            // from NinjaTrader.Core.Globals.GenerateLicenseCode).
            if (!string.IsNullOrEmpty(_injectedMachineId))
            {
                using (var sha = SHA256.Create())
                {
                    byte[] hash = sha.ComputeHash(
                        Encoding.UTF8.GetBytes(_injectedMachineId + "tm-mid-v1"));
                    return Convert.ToBase64String(hash)
                        .Substring(0, 20)
                        .Replace('+', 'A')
                        .Replace('/', 'B')
                        .Replace('=', 'C');
                }
            }

            // Fallback: Windows MachineGuid (used in unit tests and if NT8 API
            // is unavailable for any reason).
            try
            {
                string guid = Registry.GetValue(
                    @"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Cryptography",
                    "MachineGuid", null) as string
                    ?? Environment.MachineName;

                using (var sha = SHA256.Create())
                {
                    byte[] hash = sha.ComputeHash(Encoding.UTF8.GetBytes(guid + "tm-mid-v1"));
                    return Convert.ToBase64String(hash)
                        .Substring(0, 20)
                        .Replace('+', 'A')
                        .Replace('/', 'B')
                        .Replace('=', 'C');
                }
            }
            catch
            {
                return "UNKNOWN-MACHINE";
            }
        }

        // =====================================================================
        // Online validation (returns null if server is unreachable)
        // =====================================================================

        private async Task<LicenseStatus?> ValidateOnlineAsync(string key, string instanceId)
        {
            try
            {
                var pairs = new List<KeyValuePair<string, string>>
                {
                    new KeyValuePair<string, string>("license_key", key),
                };
                if (!string.IsNullOrEmpty(instanceId))
                    pairs.Add(new KeyValuePair<string, string>("instance_id", instanceId));

                var resp = await _http.PostAsync(ValidateUrl, new FormUrlEncodedContent(pairs));
                string body = await resp.Content.ReadAsStringAsync();

                if (!resp.IsSuccessStatusCode || body.Contains("\"valid\":false"))
                {
                    string lsStatus = ExtractJsonString(body, "status");
                    if (lsStatus == "expired")  return LicenseStatus.Expired;
                    if (lsStatus == "disabled") return LicenseStatus.Invalid;
                    return LicenseStatus.Invalid;
                }

                string activeStatus = ExtractJsonString(body, "status");
                if (activeStatus == "active")  return LicenseStatus.Licensed;
                if (activeStatus == "expired") return LicenseStatus.Expired;
                return LicenseStatus.Invalid;
            }
            catch
            {
                return null; // treat as offline
            }
        }

        // =====================================================================
        // Trial persistence
        // =====================================================================

        private sealed class TrialData { public DateTime StartUtc; }

        private TrialData LoadOrCreateTrial()
        {
            if (string.IsNullOrEmpty(_dataDir))
                return new TrialData { StartUtc = DateTime.UtcNow };

            Directory.CreateDirectory(_dataDir);

            if (File.Exists(TrialPath))
            {
                try
                {
                    string json = AesDecrypt(File.ReadAllBytes(TrialPath),
                                             DeriveBytesFromMachine(TrialSalt));
                    long   ticks = long.Parse(ExtractJsonString(json, "t"));
                    string mid   = ExtractJsonString(json, "m");

                    // Reject copied trial.dat from another machine.
                    if (mid == GetMachineId())
                        return new TrialData { StartUtc = new DateTime(ticks, DateTimeKind.Utc) };
                }
                catch { /* corrupt — fall through to create fresh */ }
            }

            return CreateFreshTrial();
        }

        private TrialData CreateFreshTrial()
        {
            var data = new TrialData { StartUtc = DateTime.UtcNow };
            try
            {
                string json  = $"{{\"t\":{data.StartUtc.Ticks},\"m\":\"{GetMachineId()}\"}}";
                File.WriteAllBytes(TrialPath, AesEncrypt(json, DeriveBytesFromMachine(TrialSalt)));
            }
            catch { }
            return data;
        }

        // =====================================================================
        // License cache persistence
        // =====================================================================

        private sealed class LicenseCache
        {
            public string        Key;
            public string        InstanceId;
            public DateTime      ValidatedAt;
            public LicenseStatus CachedStatus;
            public bool          WasLicensed =>
                CachedStatus == LicenseStatus.Licensed ||
                CachedStatus == LicenseStatus.Offline_Grace;
        }

        private LicenseCache LoadLicenseCache()
        {
            if (string.IsNullOrEmpty(_dataDir) || !File.Exists(LicensePath))
                return null;
            try
            {
                string json   = AesDecrypt(File.ReadAllBytes(LicensePath),
                                           DeriveBytesFromMachine(LicenseSalt));
                string k      = ExtractJsonString(json, "k");
                string iid    = ExtractJsonString(json, "i");
                long   ticks  = long.Parse(ExtractJsonString(json, "t"));
                int    status = int.Parse(ExtractJsonString(json, "s"));

                if (string.IsNullOrEmpty(k)) return null;

                return new LicenseCache
                {
                    Key          = k,
                    InstanceId   = iid,
                    ValidatedAt  = new DateTime(ticks, DateTimeKind.Utc),
                    CachedStatus = (LicenseStatus)status,
                };
            }
            catch { return null; }
        }

        private void SaveLicenseCache(string key, string instanceId, LicenseStatus status)
        {
            if (string.IsNullOrEmpty(_dataDir)) return;
            try
            {
                Directory.CreateDirectory(_dataDir);
                string json = $"{{\"k\":\"{key}\",\"i\":\"{instanceId ?? ""}\",\"t\":{DateTime.UtcNow.Ticks},\"s\":{(int)status}}}";
                File.WriteAllBytes(LicensePath, AesEncrypt(json, DeriveBytesFromMachine(LicenseSalt)));
            }
            catch { }
        }

        // =====================================================================
        // AES-256-CBC helpers
        // =====================================================================

        private static byte[] DeriveBytesFromMachine(string salt)
        {
            using (var sha = SHA256.Create())
                return sha.ComputeHash(Encoding.UTF8.GetBytes(GetMachineId() + salt));
        }

        private static byte[] AesEncrypt(string plaintext, byte[] key)
        {
            using (var aes = Aes.Create())
            {
                aes.Key  = key;
                aes.Mode = CipherMode.CBC;
                aes.GenerateIV();
                using (var enc = aes.CreateEncryptor())
                {
                    byte[] data   = Encoding.UTF8.GetBytes(plaintext);
                    byte[] cipher = enc.TransformFinalBlock(data, 0, data.Length);
                    byte[] result = new byte[16 + cipher.Length];
                    Buffer.BlockCopy(aes.IV, 0, result, 0,  16);
                    Buffer.BlockCopy(cipher, 0, result, 16, cipher.Length);
                    return result;
                }
            }
        }

        private static string AesDecrypt(byte[] combined, byte[] key)
        {
            byte[] iv     = new byte[16];
            byte[] cipher = new byte[combined.Length - 16];
            Buffer.BlockCopy(combined, 0,  iv,     0, 16);
            Buffer.BlockCopy(combined, 16, cipher, 0, cipher.Length);
            using (var aes = Aes.Create())
            {
                aes.Key  = key;
                aes.IV   = iv;
                aes.Mode = CipherMode.CBC;
                using (var dec = aes.CreateDecryptor())
                {
                    byte[] plain = dec.TransformFinalBlock(cipher, 0, cipher.Length);
                    return Encoding.UTF8.GetString(plain);
                }
            }
        }

        // =====================================================================
        // Minimal JSON field extractor
        // Avoids Newtonsoft.Json dependency for portability.
        // =====================================================================

        private static string ExtractJsonString(string json, string field,
                                                string withinObject = null)
        {
            try
            {
                string search = json;

                if (!string.IsNullOrEmpty(withinObject))
                {
                    int objStart = json.IndexOf($"\"{withinObject}\"", StringComparison.Ordinal);
                    if (objStart < 0) return "";
                    int braceOpen = json.IndexOf('{', objStart);
                    if (braceOpen < 0) return "";
                    int depth = 0, braceClose = braceOpen;
                    for (int i = braceOpen; i < json.Length; i++)
                    {
                        if      (json[i] == '{') depth++;
                        else if (json[i] == '}') { depth--; if (depth == 0) { braceClose = i; break; } }
                    }
                    search = json.Substring(braceOpen, braceClose - braceOpen + 1);
                }

                string pattern = $"\"{field}\":";
                int pos = search.IndexOf(pattern, StringComparison.Ordinal);
                if (pos < 0) return "";

                int valStart = pos + pattern.Length;
                while (valStart < search.Length && search[valStart] == ' ') valStart++;
                if (valStart >= search.Length) return "";

                if (search[valStart] == '"')
                {
                    int end = search.IndexOf('"', valStart + 1);
                    return end < 0 ? "" : search.Substring(valStart + 1, end - valStart - 1);
                }
                else
                {
                    int end = valStart;
                    while (end < search.Length && search[end] != ',' && search[end] != '}') end++;
                    return search.Substring(valStart, end - valStart).Trim();
                }
            }
            catch { return ""; }
        }
    }
}
