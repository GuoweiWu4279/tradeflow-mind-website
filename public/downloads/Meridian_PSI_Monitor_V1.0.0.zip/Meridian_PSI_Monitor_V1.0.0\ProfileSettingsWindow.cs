// ProfileSettingsWindow.cs  —  Strategy Profile configuration panel.
//
// Changes vs previous version:
//   - Account list shows only CONNECTED accounts (failed/expired prop-firm
//     accounts are excluded because their Connection.Status is Disconnected).
//   - Preset button Grid uses interleaved star/gap columns (fixes overflow).
//   - Window is resizable: drag right edge, bottom edge, or corner.
//   - Higher contrast colours throughout.

using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;

namespace NinjaTrader.NinjaScript.AddOns
{
    internal sealed class ProfileSettingsWindow : Window
    {
        // ── Win32 resize ──────────────────────────────────────────────────────
        [DllImport("user32.dll")]
        private static extern IntPtr SendMessage(IntPtr hWnd, uint msg, IntPtr wp, IntPtr lp);

        // Direction codes for WM_SYSCOMMAND + SC_SIZE (0xF000):
        // 2=right, 6=bottom, 8=bottom-right, 1=left, 3=top, 4=top-left, 5=top-right, 7=bottom-left
        private void BeginResize(int direction)
        {
            try
            {
                ReleaseMouseCapture();
                SendMessage(new WindowInteropHelper(this).Handle,
                            0x0112 /*WM_SYSCOMMAND*/,
                            new IntPtr(0xF000 + direction), IntPtr.Zero);
            }
            catch { /* best-effort */ }
        }

        // =====================================================================
        // Injected state
        // =====================================================================

        private readonly StrategyProfile _profile;
        private readonly Action<string>  _onError;

        // =====================================================================
        // Form fields
        // =====================================================================

        private readonly TextBox _txStartH, _txStartM, _txEndH, _txEndM;
        private readonly TextBox _txSizeMin, _txSizeMax;
        private readonly TextBox _txSlMax;
        private readonly TextBox _txTp;
        private readonly TextBox _txFreqMin, _txFreqMax;
        private readonly TextBox _txMaxHold;
        private readonly TextBox _txReentryMin, _txRentrySec;
        private readonly TextBox  _txReversalFactor;
        private readonly CheckBox _cbNoStopTrader;

        // =====================================================================
        // Accounts
        // =====================================================================

        private readonly List<CheckBox> _accountChecks = new List<CheckBox>();

        // =====================================================================
        // Weights / presets
        // =====================================================================

        private readonly Slider _slD1, _slD2, _slD3, _slD4, _slD5, _slD6, _slD7;
        private readonly Label  _lbD1, _lbD2, _lbD3, _lbD4, _lbD5, _lbD6, _lbD7;
        private bool            _blockSliders;

        // Preset weights — direct percentages (1–100) that sum to 100.
        // Sliders use the same 1-100 scale; normalization happens only on Apply.
        // [D1 revenge, D2 stop, D3 size, D4 hold, D5 position, D6 rules, D7 overtrade]
        private static readonly double[] PW_Scalper   = { 23, 14, 27, 9, 9, 8, 10 };
        private static readonly double[] PW_DayTrader = { 18, 23, 16, 11, 14, 8, 10 };
        private static readonly double[] PW_Swing     = {  9, 19, 14, 18, 28, 5,  7 };

        private Border    _activePB;       // currently highlighted preset button
        private Border    _pCustom;        // reference kept so OnSliderChanged can switch to it
        private TextBlock _totalBudgetLbl; // live "Total: XX / 100" feedback row

        // =====================================================================
        // Test Mode
        // =====================================================================

        private readonly ToggleButton _btnTestMode;
        private readonly TextBox      _txTestModeMin;
        private readonly TextBlock    _testModeStatus;

        // =====================================================================
        // Advanced (PSI sensitivity + penalty overrides)
        // =====================================================================

        private Border _senConservative, _senBalanced, _senAggressive;
        private Border _activeSenPreset;
        private readonly TextBox _txNakedPenalty;
        private readonly TextBox _txWindowPenalty;
        private readonly TextBox _txRecoverySpeed;
        private readonly TextBox _txFalsePositiveRate;

        // =====================================================================
        // Error banner
        // =====================================================================

        private readonly TextBlock _errBanner;

        // =====================================================================
        // Constructor
        // =====================================================================

        public ProfileSettingsWindow(StrategyProfile profile,
                                     List<string>    availableAccounts,
                                     Action<string>  onError = null)
        {
            _profile = profile ?? throw new ArgumentNullException("profile");
            _onError = onError;

            WindowStyle        = WindowStyle.None;
            AllowsTransparency = true;
            Background         = Brushes.Transparent;
            ResizeMode         = ResizeMode.CanResize;   // enables system resize logic
            ShowInTaskbar      = true;
            Title              = "PSI Monitor – Settings";
            MinWidth           = 340;
            MinHeight          = 420;
            Width              = 430;
            Height             = 600;
            Left               = SystemParameters.WorkArea.Left + 80;
            Top                = SystemParameters.WorkArea.Top  + 60;

            // ── Outer grid: card + invisible resize border zones ──────────────
            var outer = new Grid();
            outer.ColumnDefinitions.Add(
                new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            outer.ColumnDefinitions.Add(
                new ColumnDefinition { Width = new GridLength(6) }); // right resize
            outer.RowDefinitions.Add(
                new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
            outer.RowDefinitions.Add(
                new RowDefinition { Height = new GridLength(6) }); // bottom resize

            // Resize hit zones (transparent but hit-testable)
            var rRight  = ResizeZone(Cursors.SizeWE,   () => BeginResize(2));
            var rBottom = ResizeZone(Cursors.SizeNS,   () => BeginResize(6));
            var rCorner = ResizeZone(Cursors.SizeNWSE,  () => BeginResize(8));
            Grid.SetColumn(rRight,  1); Grid.SetRow(rRight,  0); outer.Children.Add(rRight);
            Grid.SetColumn(rBottom, 0); Grid.SetRow(rBottom, 1); outer.Children.Add(rBottom);
            Grid.SetColumn(rCorner, 1); Grid.SetRow(rCorner, 1); outer.Children.Add(rCorner);

            // ── Card ──────────────────────────────────────────────────────────
            var card = new Border
            {
                CornerRadius    = new CornerRadius(12),
                Background      = new SolidColorBrush(Color.FromRgb(28, 28, 30)), // #1C1C1E Apple dark
                BorderBrush     = new SolidColorBrush(Color.FromArgb(45, 255, 255, 255)),
                BorderThickness = new Thickness(1),
                ClipToBounds    = true,
            };
            Grid.SetColumn(card, 0); Grid.SetRow(card, 0);
            outer.Children.Add(card);

            // ── Card layout: DockPanel (title top, buttons bottom, scroll fills) ──
            var dock = new DockPanel { LastChildFill = true };

            // Title bar
            var titleBar = BuildTitleBar();
            DockPanel.SetDock(titleBar, Dock.Top);
            dock.Children.Add(titleBar);

            // Button row + error at bottom
            _errBanner = new TextBlock
            {
                TextWrapping = TextWrapping.Wrap,
                Foreground   = ErrBrush,
                FontSize     = 10,
                Visibility   = Visibility.Collapsed,
                Margin       = new Thickness(18, 6, 18, 0),
            };

            var btnRow = new Grid { Margin = new Thickness(20, 10, 20, 18) };
            btnRow.ColumnDefinitions.Add(new ColumnDefinition());
            btnRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(10) });
            btnRow.ColumnDefinitions.Add(new ColumnDefinition());

            var applyBtn  = MakeActionBtn("APPLY & SAVE", BgAccent);
            var cancelBtn = MakeActionBtn("CANCEL",       BgSurface);
            applyBtn.MouseLeftButtonDown  += (_, e) => { e.Handled = true; OnApply(); };
            cancelBtn.MouseLeftButtonDown += (_, e) => { e.Handled = true; Close(); };
            Grid.SetColumn(applyBtn,  0); btnRow.Children.Add(applyBtn);
            Grid.SetColumn(cancelBtn, 2); btnRow.Children.Add(cancelBtn);

            var bottomStack = new StackPanel();
            bottomStack.Children.Add(_errBanner);
            bottomStack.Children.Add(btnRow);
            DockPanel.SetDock(bottomStack, Dock.Bottom);
            dock.Children.Add(bottomStack);

            // ── Scrollable form ───────────────────────────────────────────────
            var scroll = new ScrollViewer
            {
                VerticalScrollBarVisibility   = ScrollBarVisibility.Auto,
                HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
            };

            var form = new StackPanel { Margin = new Thickness(20, 6, 20, 0) };

            // ─── TRADING SESSION ────────────────────────────────────────────
            form.Children.Add(SectionRow("TRADING SESSION",
                "Enter the start and end of your normal trading window.\n\n" +
                "Use your computer's local clock time — the same time shown on your taskbar.\n\n" +
                "The PSI Rule Compliance alert fires on any trade placed outside this window."));

            form.Children.Add(new TextBlock
            {
                Text       = "Your clock: " + DateTime.Now.ToString("HH:mm") +
                             "  ·  " + TimeZoneInfo.Local.DisplayName,
                FontSize   = 9,
                Foreground = FgHint,
                Margin     = new Thickness(0, 0, 0, 6),
            });

            var sessGrid = new Grid();
            sessGrid.ColumnDefinitions.Add(new ColumnDefinition());
            sessGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(18) });
            sessGrid.ColumnDefinitions.Add(new ColumnDefinition());

            var startSP = new StackPanel();
            startSP.Children.Add(FieldLbl("Session start"));
            startSP.Children.Add(HhMm(profile.SessionStartHour.ToString("D2"),
                                       profile.SessionStartMinute.ToString("D2"),
                                       out _txStartH, out _txStartM));

            var endSP = new StackPanel();
            endSP.Children.Add(FieldLbl("Session end"));
            endSP.Children.Add(HhMm(profile.SessionEndHour.ToString("D2"),
                                     profile.SessionEndMinute.ToString("D2"),
                                     out _txEndH, out _txEndM));

            Grid.SetColumn(startSP, 0); sessGrid.Children.Add(startSP);
            Grid.SetColumn(endSP,   2); sessGrid.Children.Add(endSP);
            form.Children.Add(sessGrid);

            // ─── POSITION SIZE ───────────────────────────────────────────────
            form.Children.Add(SectionRow("NORMAL POSITION SIZE",
                "Your typical contract range per trade.\n\n" +
                "The Size Spike alert fires when your open position grows significantly " +
                "above your personal average.\n\n" +
                "Measured in contracts — 1 NQ ≠ 1 MNQ in dollar value.  " +
                "If you trade multiple instruments set these for your highest-risk one."));

            form.Children.Add(RangeRow("Min", profile.SizeMin.ToString(),
                                       "Max", profile.SizeMax.ToString(),
                                       "contracts", out _txSizeMin, out _txSizeMax));

            // ─── STOP-LOSS ───────────────────────────────────────────────────
            form.Children.Add(SectionRow("STOP-LOSS",
                "Your maximum allowed stop-loss in ticks.\n\n" +
                "If you always use the same SL, enter that number.\n" +
                "If it varies, enter the highest value you consider acceptable.\n\n" +
                "The Stop Manipulation alert fires when your stop expands beyond this."));

            form.Children.Add(UnitField("Max stop-loss",
                                        profile.SlTicksMax.ToString(), "ticks", out _txSlMax));

            // ─── TAKE-PROFIT ─────────────────────────────────────────────────
            form.Children.Add(SectionRow("TAKE-PROFIT",
                "Your typical take-profit target in ticks.\n\n" +
                "Used only during your first ~5 sessions while the algorithm learns " +
                "your real hold times.  After that, real data takes over.\n\n" +
                "Not sure?  Leave 40 — it only affects early cold-start estimates " +
                "and has no lasting impact."));

            form.Children.Add(UnitField("Typical target",
                                        profile.TpTicksMax.ToString(), "ticks", out _txTp));

            // ─── TRADE FREQUENCY ─────────────────────────────────────────────
            form.Children.Add(SectionRow("TRADES PER SESSION",
                "How many trades you typically take per session.\n\n" +
                "Used to calibrate your baseline trade velocity."));

            form.Children.Add(RangeRow("Min", profile.TradesPerSessionMin.ToString(),
                                       "Max", profile.TradesPerSessionMax.ToString(),
                                       "trades", out _txFreqMin, out _txFreqMax));

            // ─── TIMING ──────────────────────────────────────────────────────
            form.Children.Add(SectionRow("TIMING THRESHOLDS",
                "Three time/style controls:\n\n" +
                "Max hold — A losing trade held longer than this triggers the '扛单' alert. " +
                "Set it to the longest you'd intentionally hold a loser.\n\n" +
                "Re-entry / flip window — After a LARGE loss (> 1.5× your avg), " +
                "re-entering within this window AND with a bigger size is flagged as a " +
                "suspicious re-entry.  Scalpers can set this to 10–30 s. " +
                "Set to 0:00 to disable the check entirely.\n\n" +
                "Direction-flip discount — When the new entry is in the OPPOSITE direction " +
                "to the closed trade (e.g. Short → Long), the D1 score is multiplied by " +
                "this factor.  0 % = flips never count; 25 % (default) = flips register " +
                "weakly; 100 % = flips are treated the same as same-direction re-entries.\n" +
                "Scalpers who tactically reverse should set this to 0–15 %."));

            form.Children.Add(UnitField("Max hold time for a losing trade",
                                        profile.MaxHoldMinutes.ToString(),
                                        "minutes", out _txMaxHold));

            form.Children.Add(FieldLbl("Re-entry / flip detection window"));
            form.Children.Add(MmSs((profile.MaxReentrySeconds / 60).ToString(),
                                    (profile.MaxReentrySeconds % 60).ToString("D2"),
                                    out _txReentryMin, out _txRentrySec));

            form.Children.Add(UnitField("Re-entry reversal penalty",
                                        Math.Round(profile.ReversalPenaltyFactor * 100).ToString(),
                                        "%  (0 = off · 25 = default · 100 = same as double-down)",
                                        out _txReversalFactor));

            // ── No-stop-loss toggle (compact: checkbox + help badge) ──────────
            var noStopRow = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin      = new Thickness(0, 8, 0, 4),
            };
            _cbNoStopTrader = new CheckBox
            {
                Content           = "No stop-loss orders (mental stops / bracket exits only)",
                IsChecked         = profile.NoStopLossTrader,
                Foreground        = FgPrimary,
                FontSize          = 11,
                FontFamily        = new FontFamily("Segoe UI"),
                VerticalAlignment = VerticalAlignment.Center,
            };
            noStopRow.Children.Add(_cbNoStopTrader);
            noStopRow.Children.Add(HelpBadge(
                "Check this if you never use stop-loss orders (mental stops, " +
                "manually-placed exits, or bracket orders placed BEFORE entry).\n\n" +
                "When checked the naked-position detector is completely disabled — " +
                "no alert will fire even if a position has no covering stop order.\n\n" +
                "Leave unchecked if you use ATM strategies or post-entry bracket orders " +
                "so the system can detect when you accidentally remove stop protection mid-trade.\n\n" +
                "ATM grace period (20 s) is applied automatically — enough time for " +
                "NinjaTrader ATM to create the stop order after your entry fill."));
            form.Children.Add(noStopRow);

            // ─── MONITORED ACCOUNTS ──────────────────────────────────────────
            form.Children.Add(SectionRow("MONITORED ACCOUNTS",
                "Only CONNECTED accounts are listed here.\n" +
                "Failed or expired prop-firm accounts are automatically excluded.\n\n" +
                "Check the account(s) you are currently trading on.  " +
                "Leaving all checked monitors everything."));

            var accFilter = MakeTx("", 11);
            accFilter.Tag    = "Search accounts…";
            accFilter.Margin = new Thickness(0, 4, 0, 6);
            SetPlaceholder(accFilter);
            accFilter.TextChanged += (_, __) =>
                FilterAccounts(accFilter.Text == (string)accFilter.Tag ? "" : accFilter.Text);
            form.Children.Add(accFilter);

            var accPanel = new StackPanel();
            var accList  = availableAccounts ?? new List<string>();
            if (accList.Count == 0)
            {
                accPanel.Children.Add(new TextBlock
                {
                    Text       = "No active accounts found.",
                    FontSize   = 10,
                    Foreground = FgHint,
                    Margin     = new Thickness(2, 2, 0, 2),
                });
            }
            else
            {
                foreach (string name in accList)
                {
                    bool mon = profile.MonitoredAccountNames == null ||
                               profile.MonitoredAccountNames.Count == 0 ||
                               profile.MonitoredAccountNames.Contains(name);
                    var cb = new CheckBox
                    {
                        Content    = name,
                        IsChecked  = mon,
                        Foreground = FgPrimary,
                        FontSize   = 11,
                        Margin     = new Thickness(2, 4, 0, 2),
                    };
                    _accountChecks.Add(cb);
                    accPanel.Children.Add(cb);
                }
            }

            var accScroll = new ScrollViewer
            {
                MaxHeight                     = 135,
                VerticalScrollBarVisibility   = ScrollBarVisibility.Auto,
                HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
                Margin                        = new Thickness(0, 0, 0, 4),
                Content                       = accPanel,
            };
            form.Children.Add(accScroll);

            // ─── TEST MODE ──────────────────────────────────────────────────
            form.Children.Add(SectionRow("TEST MODE",
                "Temporarily pause baseline recording so experimental trades " +
                "do not affect your long-term trading profile.\n\n" +
                "PSI still calculates and displays in real-time — only the " +
                "historical statistics used to calibrate your personal baseline " +
                "are frozen while Test Mode is active.\n\n" +
                "Auto-expires after the configured duration to prevent " +
                "accidentally leaving it on."));

            var testRow = new Grid { Margin = new Thickness(0, 4, 0, 8) };
            testRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            testRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(8) });
            testRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto }); // "Duration:"
            testRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(4) });
            testRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            testRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            testRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

            bool testActive = profile.IsTestModeActive;
            _btnTestMode = new ToggleButton
            {
                Content           = testActive ? "ON" : "OFF",
                IsChecked         = testActive,
                Width             = 50,
                Height            = 24,
                FontSize          = 10,
                FontWeight        = FontWeights.Bold,
                FontFamily        = new FontFamily("Segoe UI"),
                Foreground        = Brushes.White,
                Background        = testActive
                    ? new SolidColorBrush(Color.FromRgb(255, 159, 10))
                    : new SolidColorBrush(Color.FromRgb(72, 72, 74)),
                BorderThickness   = new Thickness(0),
                VerticalAlignment = VerticalAlignment.Center,
            };

            _txTestModeMin = MakeTx(profile.TestModeMinutes.ToString(), 10);
            _txTestModeMin.Width     = 42;
            _txTestModeMin.Margin    = new Thickness(0);
            _txTestModeMin.TextAlignment = System.Windows.TextAlignment.Center;

            var minLabel = new TextBlock
            {
                Text              = " min",
                FontSize          = 10,
                Foreground        = FgHint,
                VerticalAlignment = VerticalAlignment.Center,
            };

            _testModeStatus = new TextBlock
            {
                FontSize          = 10,
                Foreground        = new SolidColorBrush(Color.FromRgb(255, 159, 10)),
                VerticalAlignment = VerticalAlignment.Center,
                Margin            = new Thickness(10, 0, 0, 0),
            };
            if (testActive)
                _testModeStatus.Text = $"{profile.TestModeRemainingMinutes} min remaining";

            _btnTestMode.Checked   += (_, __) => OnTestModeToggle(true);
            _btnTestMode.Unchecked += (_, __) => OnTestModeToggle(false);

            var durLabel = new TextBlock
            {
                Text              = "Duration:",
                FontSize          = 10,
                Foreground        = FgHint,
                VerticalAlignment = VerticalAlignment.Center,
            };

            Grid.SetColumn(_btnTestMode,     0); testRow.Children.Add(_btnTestMode);
            Grid.SetColumn(durLabel,         2); testRow.Children.Add(durLabel);
            Grid.SetColumn(_txTestModeMin,   4); testRow.Children.Add(_txTestModeMin);
            Grid.SetColumn(minLabel,         5); testRow.Children.Add(minLabel);
            Grid.SetColumn(_testModeStatus,  6); testRow.Children.Add(_testModeStatus);
            form.Children.Add(testRow);

            // ─── ALERT SENSITIVITY ───────────────────────────────────────────
            form.Children.Add(SectionRow("ALERT SENSITIVITY",
                "How strongly each behaviour lowers your PSI score.\n\n" +
                "Set the relative importance of each signal. Values do not need to " +
                "sum to exactly 100 — on save they are automatically scaled to the " +
                "correct proportions.\n\n" +
                "Tip: aim for a total near 100 so the numbers you see reflect what " +
                "the engine actually uses.  The live total bar below tells you how " +
                "close you are."));

            // ── Preset buttons — interleaved star/gap grid ──────────────────
            var pRow = new Grid { Margin = new Thickness(0, 0, 0, 10) };
            // Columns: btn, gap, btn, gap, btn, gap, btn  (0-6)
            for (int i = 0; i < 4; i++)
            {
                pRow.ColumnDefinitions.Add(new ColumnDefinition()); // star
                if (i < 3)
                    pRow.ColumnDefinitions.Add(
                        new ColumnDefinition { Width = new GridLength(5) }); // gap
            }

            var pScalper  = MakePresetBtn("SCALPER");
            var pDay      = MakePresetBtn("DAY TRADER");
            var pSwing    = MakePresetBtn("SWING");
            var pCustom   = MakePresetBtn("CUSTOM");
            _pCustom      = pCustom; // store reference for OnSliderChanged

            Grid.SetColumn(pScalper, 0); pRow.Children.Add(pScalper);
            Grid.SetColumn(pDay,     2); pRow.Children.Add(pDay);
            Grid.SetColumn(pSwing,   4); pRow.Children.Add(pSwing);
            Grid.SetColumn(pCustom,  6); pRow.Children.Add(pCustom);
            form.Children.Add(pRow);

            // ── Sliders — each shows a direct % (1-100); summing to 100 is not
            // required while editing; OnApply normalises automatically.
            _slD1 = MakeSlider(Math.Round(profile.WeightRevengeEntry     * 100));
            _slD2 = MakeSlider(Math.Round(profile.WeightStopManipulation * 100));
            _slD3 = MakeSlider(Math.Round(profile.WeightSizeOutlier      * 100));
            _slD4 = MakeSlider(Math.Round(profile.WeightHoldTimeCollapse * 100));
            _slD5 = MakeSlider(Math.Round(profile.WeightPositionHold     * 100));
            _slD6 = MakeSlider(Math.Round(profile.WeightRuleCompliance   * 100));
            _slD7 = MakeSlider(Math.Round(profile.WeightOvertrading      * 100));

            // ── Live budget bar ───────────────────────────────────────────────
            _totalBudgetLbl = new TextBlock
            {
                FontSize   = 10,
                FontFamily = new FontFamily("Segoe UI"),
                Margin     = new Thickness(0, 0, 0, 8),
            };
            form.Children.Add(_totalBudgetLbl);

            form.Children.Add(SliderRow("Revenge entry",       _slD1, out _lbD1));
            form.Children.Add(SliderRow("Stop manipulation",   _slD2, out _lbD2));
            form.Children.Add(SliderRow("Size spike",          _slD3, out _lbD3));
            form.Children.Add(SliderRow("Rushed exit",         _slD4, out _lbD4));
            form.Children.Add(SliderRow("Position overstay",   _slD5, out _lbD5));
            form.Children.Add(SliderRow("Rule violations",     _slD6, out _lbD6));
            form.Children.Add(SliderRow("Overtrading pace",    _slD7, out _lbD7));

            _slD1.ValueChanged += OnSliderChanged;
            _slD2.ValueChanged += OnSliderChanged;
            _slD3.ValueChanged += OnSliderChanged;
            _slD4.ValueChanged += OnSliderChanged;
            _slD5.ValueChanged += OnSliderChanged;
            _slD6.ValueChanged += OnSliderChanged;
            _slD7.ValueChanged += OnSliderChanged;

            UpdateWeightLabels();

            // Wire preset buttons after sliders are created
            pScalper.MouseLeftButtonDown += (_, e)
                => { e.Handled = true; ApplyPreset(PW_Scalper,   pScalper, pCustom); };
            pDay.MouseLeftButtonDown     += (_, e)
                => { e.Handled = true; ApplyPreset(PW_DayTrader, pDay,     pCustom); };
            pSwing.MouseLeftButtonDown   += (_, e)
                => { e.Handled = true; ApplyPreset(PW_Swing,     pSwing,   pCustom); };
            pCustom.MouseLeftButtonDown  += (_, e)
                => { e.Handled = true; SetActivePreset(pCustom); };

            // Highlight whichever preset the profile currently matches
            SetActivePreset(MatchPreset(pScalper, PW_Scalper,
                                        pDay,     PW_DayTrader,
                                        pSwing,   PW_Swing,
                                        pCustom));

            // ─── ADVANCED (PSI Sensitivity + penalty overrides) ────────────
            form.Children.Add(SectionRow("ADVANCED",
                "Controls how aggressively the PSI engine reacts to rule " +
                "violations and behavioural deviations.\n\n" +
                "Select a preset, or override individual penalty values " +
                "below (leave blank to use the preset default)."));

            // ── Sensitivity preset buttons ───────────────────────────────
            var senRow = new Grid { Margin = new Thickness(0, 4, 0, 8) };
            for (int i = 0; i < 3; i++)
            {
                senRow.ColumnDefinitions.Add(new ColumnDefinition());
                if (i < 2)
                    senRow.ColumnDefinitions.Add(
                        new ColumnDefinition { Width = new GridLength(5) });
            }

            _senConservative = MakePresetBtn("CONSERVATIVE");
            _senBalanced     = MakePresetBtn("BALANCED");
            _senAggressive   = MakePresetBtn("AGGRESSIVE");

            Grid.SetColumn(_senConservative, 0); senRow.Children.Add(_senConservative);
            Grid.SetColumn(_senBalanced,     2); senRow.Children.Add(_senBalanced);
            Grid.SetColumn(_senAggressive,   4); senRow.Children.Add(_senAggressive);

            _senConservative.MouseLeftButtonDown += (_, e) =>
            { e.Handled = true; SetActiveSenPreset(_senConservative); };
            _senBalanced.MouseLeftButtonDown += (_, e) =>
            { e.Handled = true; SetActiveSenPreset(_senBalanced); };
            _senAggressive.MouseLeftButtonDown += (_, e) =>
            { e.Handled = true; SetActiveSenPreset(_senAggressive); };

            switch (profile.Sensitivity)
            {
                case PsiSensitivity.Conservative: SetActiveSenPreset(_senConservative); break;
                case PsiSensitivity.Aggressive:   SetActiveSenPreset(_senAggressive);   break;
                default:                          SetActiveSenPreset(_senBalanced);      break;
            }

            form.Children.Add(senRow);

            // ── Override fields ──────────────────────────────────────────
            string nakedVal  = profile.NakedPositionPenalty >= 0
                ? profile.NakedPositionPenalty.ToString("0") : "";
            string windowVal = profile.SessionWindowPenalty >= 0
                ? profile.SessionWindowPenalty.ToString("0") : "";
            string recovVal  = profile.RecoverySpeedMultiplier > 0
                ? profile.RecoverySpeedMultiplier.ToString("0.00") : "";
            string fprVal    = profile.FalsePositiveRate > 0
                ? (profile.FalsePositiveRate * 100.0).ToString("0.#") : "";

            _txNakedPenalty      = MakeTx(nakedVal,  10);
            _txWindowPenalty     = MakeTx(windowVal, 10);
            _txRecoverySpeed     = MakeTx(recovVal,  10);
            _txFalsePositiveRate = MakeTx(fprVal,    10);

            _txNakedPenalty.Width      = 52;
            _txWindowPenalty.Width     = 52;
            _txRecoverySpeed.Width     = 52;
            _txFalsePositiveRate.Width = 52;

            form.Children.Add(OverrideRow("False positive rate",
                "1–10 % (blank = preset default)", _txFalsePositiveRate));
            form.Children.Add(OverrideRow("Naked position penalty",
                "0–50 PSI pts (blank = preset default)", _txNakedPenalty));
            form.Children.Add(OverrideRow("Session window penalty",
                "0–50 PSI pts (blank = preset default)", _txWindowPenalty));
            form.Children.Add(OverrideRow("Recovery speed multiplier",
                "0.25–4.00 (blank = preset default)", _txRecoverySpeed));

            form.Children.Add(new Border { Height = 10 }); // bottom spacer

            scroll.Content = form;
            dock.Children.Add(scroll); // LastChildFill = fills remaining height

            card.Child = dock;
            Content    = outer;
        }

        // =====================================================================
        // Apply
        // =====================================================================

        private void OnApply()
        {
            HideErr();
            if (!PI(_txStartH,     0,  23, out int sh)) return;
            if (!PI(_txStartM,     0,  59, out int sm)) return;
            if (!PI(_txEndH,       0,  23, out int eh)) return;
            if (!PI(_txEndM,       0,  59, out int em)) return;
            if (new TimeSpan(sh, sm, 0) >= new TimeSpan(eh, em, 0))
            { ShowErr("Session start must be earlier than session end."); return; }

            if (!PD(_txSizeMin,  0.01, 9999, out double sMin)) return;
            if (!PD(_txSizeMax,  0.01, 9999, out double sMax)) return;
            if (sMin > sMax) { ShowErr("Size Min cannot exceed Size Max."); return; }

            if (!PI(_txSlMax,    1,  9999, out int slMax))   return;
            if (!PI(_txTp,       1,  9999, out int tp))      return;
            if (!PI(_txFreqMin,  1,  9999, out int fMin))    return;
            if (!PI(_txFreqMax,  1,  9999, out int fMax))    return;
            if (fMin > fMax) { ShowErr("Frequency Min cannot exceed Max."); return; }

            if (!PI(_txMaxHold,      1, 1440, out int maxH))  return;
            if (!PI(_txReentryMin,   0,  120, out int rMin))  return;
            if (!PI(_txRentrySec,    0,   59, out int rSec))  return;
            int reentry = rMin * 60 + rSec;
            // No minimum enforced — scalpers may use very short windows or 0:00 to disable.

            if (!PD(_txReversalFactor, 0, 100, out double reversalPct)) return;
            bool noStopTrader = _cbNoStopTrader.IsChecked == true;

            _profile.SessionStartHour   = sh;   _profile.SessionStartMinute = sm;
            _profile.SessionEndHour     = eh;   _profile.SessionEndMinute   = em;
            _profile.SizeMin            = sMin; _profile.SizeMax            = sMax;
            _profile.SlTicksMin         = Math.Max(1, slMax / 2);
            _profile.SlTicksMax         = slMax;
            _profile.TpTicksMin         = tp;   _profile.TpTicksMax         = tp;
            _profile.TradesPerSessionMin = fMin; _profile.TradesPerSessionMax = fMax;
            _profile.MaxHoldMinutes        = maxH;
            _profile.MaxReentrySeconds     = reentry;
            _profile.ReversalPenaltyFactor = reversalPct / 100.0;
            _profile.NoStopLossTrader      = noStopTrader;
            // NoStopGraceSeconds is not exposed in UI; keep current value (default 20 s).

            if (PI(_txTestModeMin, 1, 480, out int tmMin))
                _profile.TestModeMinutes = tmMin;

            // ── Advanced: Sensitivity preset ──
            if (_activeSenPreset == _senConservative)
                _profile.Sensitivity = PsiSensitivity.Conservative;
            else if (_activeSenPreset == _senAggressive)
                _profile.Sensitivity = PsiSensitivity.Aggressive;
            else
                _profile.Sensitivity = PsiSensitivity.Balanced;

            // ── Advanced: Override fields (blank = -1 = use preset default) ──
            // FalsePositiveRate is entered as a percentage (1–10%) and stored as a fraction.
            if (string.IsNullOrWhiteSpace(_txFalsePositiveRate.Text))
                _profile.FalsePositiveRate = -1;
            else
            {
                double pct = PD_Val(_txFalsePositiveRate, 1, 10, -1);
                _profile.FalsePositiveRate = pct > 0 ? pct / 100.0 : -1;
            }

            _profile.NakedPositionPenalty = string.IsNullOrWhiteSpace(_txNakedPenalty.Text)
                ? -1 : PD_Val(_txNakedPenalty, 0, 50, -1);

            _profile.SessionWindowPenalty = string.IsNullOrWhiteSpace(_txWindowPenalty.Text)
                ? -1 : PD_Val(_txWindowPenalty, 0, 50, -1);

            _profile.RecoverySpeedMultiplier = string.IsNullOrWhiteSpace(_txRecoverySpeed.Text)
                ? -1 : PD_Val(_txRecoverySpeed, 0.25, 4.0, -1);

            _profile.MonitoredAccountNames.Clear();
            bool allChecked = true;
            foreach (var cb in _accountChecks)
            {
                if (cb.IsChecked == true)
                    _profile.MonitoredAccountNames.Add(cb.Content as string ?? "");
                else
                    allChecked = false;
            }
            if (allChecked) _profile.MonitoredAccountNames.Clear();

            // Normalise raw percentage sliders to fractions summing to 1.0
            double wsum = _slD1.Value + _slD2.Value + _slD3.Value
                        + _slD4.Value + _slD5.Value + _slD6.Value + _slD7.Value;
            if (wsum < 1) wsum = 1;
            _profile.WeightRevengeEntry     = _slD1.Value / wsum;
            _profile.WeightStopManipulation = _slD2.Value / wsum;
            _profile.WeightSizeOutlier      = _slD3.Value / wsum;
            _profile.WeightHoldTimeCollapse = _slD4.Value / wsum;
            _profile.WeightPositionHold     = _slD5.Value / wsum;
            _profile.WeightRuleCompliance   = _slD6.Value / wsum;
            _profile.WeightOvertrading      = _slD7.Value / wsum;

            _profile.SaveToFile(_onError);
            Close();
        }

        // =====================================================================
        // Test Mode toggle  (takes effect immediately — no Apply needed)
        // =====================================================================

        private void OnTestModeToggle(bool on)
        {
            if (on)
            {
                int mins = 60;
                int.TryParse(_txTestModeMin.Text, out mins);
                if (mins < 1) mins = 1;
                if (mins > 480) mins = 480;
                _profile.TestModeMinutes = mins;
                _profile.ActivateTestMode();
                _btnTestMode.Content    = "ON";
                _btnTestMode.Background = new SolidColorBrush(Color.FromRgb(255, 159, 10));
                _testModeStatus.Text    = $"{mins} min remaining";
            }
            else
            {
                _profile.DeactivateTestMode();
                _btnTestMode.Content    = "OFF";
                _btnTestMode.Background = new SolidColorBrush(Color.FromRgb(72, 72, 74));
                _testModeStatus.Text    = "";
            }
            _profile.SaveToFile(_onError);
        }

        // =====================================================================
        // Presets
        // =====================================================================

        private void ApplyPreset(double[] w, Border btn, Border custom)
        {
            _blockSliders = true;
            _slD1.Value = w[0]; _slD2.Value = w[1]; _slD3.Value = w[2];
            _slD4.Value = w[3]; _slD5.Value = w[4]; _slD6.Value = w[5];
            _slD7.Value = w.Length > 6 ? w[6] : 10;
            _blockSliders = false;
            UpdateWeightLabels();
            SetActivePreset(btn);
        }

        private void OnSliderChanged(object s, RoutedPropertyChangedEventArgs<double> e)
        {
            if (_blockSliders) return;
            UpdateWeightLabels();
            // Dragging while on a named preset → switch to CUSTOM.
            // Dragging while already on CUSTOM (or nothing) → keep as-is.
            if (_activePB != null && _activePB != _pCustom)
                SetActivePreset(_pCustom);
            else if (_activePB == null && _pCustom != null)
                SetActivePreset(_pCustom);
        }

        private void SetActivePreset(Border btn)
        {
            if (_activePB != null) _activePB.Background = BgSurface;
            _activePB = btn;
            if (_activePB != null) _activePB.Background = BgAccent;
        }

        private void SetActiveSenPreset(Border btn)
        {
            if (_activeSenPreset != null) _activeSenPreset.Background = BgSurface;
            _activeSenPreset = btn;
            if (_activeSenPreset != null) _activeSenPreset.Background = BgAccent;
        }

        private static FrameworkElement OverrideRow(string label, string hint, TextBox field)
        {
            var g = new Grid { Margin = new Thickness(0, 2, 0, 2) };
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            var labelSP = new StackPanel();
            labelSP.Children.Add(new TextBlock
            {
                Text       = label,
                FontSize   = 11,
                Foreground = new SolidColorBrush(Color.FromRgb(229, 229, 234)),
                FontFamily = new FontFamily("Segoe UI"),
            });
            labelSP.Children.Add(new TextBlock
            {
                Text       = hint,
                FontSize   = 9,
                Foreground = new SolidColorBrush(Color.FromRgb(142, 142, 147)),
                FontFamily = new FontFamily("Segoe UI"),
            });
            Grid.SetColumn(labelSP, 0); g.Children.Add(labelSP);
            Grid.SetColumn(field,   1); g.Children.Add(field);
            return g;
        }

        private Border MatchPreset(Border b1, double[] w1, Border b2, double[] w2,
                                   Border b3, double[] w3, Border custom)
        {
            if (WMatch(w1)) return b1;
            if (WMatch(w2)) return b2;
            if (WMatch(w3)) return b3;
            return custom;
        }

        private bool WMatch(double[] w)
        {
            // Preset arrays are in the same 1-100 scale as the sliders.
            return Math.Abs(_slD1.Value - w[0]) < 2 &&
                   Math.Abs(_slD2.Value - w[1]) < 2 &&
                   Math.Abs(_slD3.Value - w[2]) < 2 &&
                   Math.Abs(_slD4.Value - w[3]) < 2 &&
                   Math.Abs(_slD5.Value - w[4]) < 2 &&
                   Math.Abs(_slD6.Value - w[5]) < 2 &&
                   (w.Length <= 6 || Math.Abs(_slD7.Value - w[6]) < 2);
        }

        private void UpdateWeightLabels()
        {
            // Show the raw slider value (1-100) directly — no cross-slider normalization.
            // Sliders are independent; normalization happens only on Apply.
            _lbD1.Content = FmtPct(_slD1.Value);
            _lbD2.Content = FmtPct(_slD2.Value);
            _lbD3.Content = FmtPct(_slD3.Value);
            _lbD4.Content = FmtPct(_slD4.Value);
            _lbD5.Content = FmtPct(_slD5.Value);
            _lbD6.Content = FmtPct(_slD6.Value);
            _lbD7.Content = FmtPct(_slD7.Value);
            UpdateBudgetLabel();
        }

        private void UpdateBudgetLabel()
        {
            if (_totalBudgetLbl == null) return;
            int total = (int)Math.Round(
                _slD1.Value + _slD2.Value + _slD3.Value +
                _slD4.Value + _slD5.Value + _slD6.Value + _slD7.Value);

            string text;
            Color  color;

            if (total >= 95 && total <= 105)
            {
                text  = $"Total: {total} / 100  ✓  (values look good — saved as-is)";
                color = Color.FromRgb(48, 209, 88);   // Apple green
            }
            else if (total < 95)
            {
                text  = $"Total: {total} / 100  — {100 - total} pts unallocated (will be scaled on save)";
                color = Color.FromRgb(255, 214, 0);   // Apple yellow
            }
            else
            {
                text  = $"Total: {total} / 100  — {total - 100} pts over (will be scaled on save)";
                color = Color.FromRgb(255, 214, 0);   // Apple yellow
            }

            _totalBudgetLbl.Text       = text;
            _totalBudgetLbl.Foreground = new SolidColorBrush(color);
        }

        private static string FmtPct(double f) => $"{(int)Math.Round(f)}%";

        // =====================================================================
        // Account filter
        // =====================================================================

        private void FilterAccounts(string q)
        {
            foreach (var cb in _accountChecks)
            {
                string n = (cb.Content as string) ?? "";
                cb.Visibility = (q.Length == 0 ||
                                 n.IndexOf(q, StringComparison.OrdinalIgnoreCase) >= 0)
                    ? Visibility.Visible : Visibility.Collapsed;
            }
        }

        private static void SetPlaceholder(TextBox tb)
        {
            var tag = (string)tb.Tag;
            tb.Text       = tag;
            tb.Foreground = FgHint;
            tb.GotFocus   += (_, __) =>
            {
                if (tb.Text == (string)tb.Tag) { tb.Text = ""; tb.Foreground = FgPrimary; }
            };
            tb.LostFocus += (_, __) =>
            {
                if (string.IsNullOrEmpty(tb.Text)) { tb.Text = tag; tb.Foreground = FgHint; }
            };
        }

        // =====================================================================
        // Validation
        // =====================================================================

        private bool PI(TextBox tb, int lo, int hi, out int v)
        {
            tb.BorderBrush = BorderNormal;
            if (int.TryParse(tb.Text.Trim(), out v) && v >= lo && v <= hi) return true;
            tb.BorderBrush = ErrBrush;
            ShowErr($"'{tb.Text}' — expected a whole number {lo}–{hi}.");
            return false;
        }

        private bool PD(TextBox tb, double lo, double hi, out double v)
        {
            tb.BorderBrush = BorderNormal;
            if (double.TryParse(tb.Text.Trim(), out v) && v >= lo && v <= hi) return true;
            tb.BorderBrush = ErrBrush;
            ShowErr($"'{tb.Text}' — expected a number {lo}–{hi}.");
            return false;
        }

        private double PD_Val(TextBox tb, double lo, double hi, double fallback)
        {
            if (double.TryParse(tb.Text.Trim(), out double v) && v >= lo && v <= hi)
                return v;
            return fallback;
        }

        private void ShowErr(string m)
        {
            _errBanner.Text       = "⚠  " + m;
            _errBanner.Visibility = Visibility.Visible;
        }

        private void HideErr() => _errBanner.Visibility = Visibility.Collapsed;

        // =====================================================================
        // =====================================================================
        // Palette  —  Apple dark system  (#1C1C1E family)
        // =====================================================================

        private static readonly Brush FgPrimary   = new SolidColorBrush(Color.FromRgb(245, 245, 247)); // #F5F5F7
        private static readonly Brush FgSecondary = new SolidColorBrush(Color.FromRgb(174, 174, 178)); // #AEAEB2
        private static readonly Brush FgHint      = new SolidColorBrush(Color.FromRgb( 99,  99, 102)); // #636366
        private static readonly Brush FgAccent    = new SolidColorBrush(Color.FromRgb( 10, 132, 255)); // #0A84FF
        private static readonly Brush BgField     = new SolidColorBrush(Color.FromRgb( 58,  58,  60)); // #3A3A3C
        private static readonly Brush BgSurface   = new SolidColorBrush(Color.FromRgb( 44,  44,  46)); // #2C2C2E
        private static readonly Brush BgAccent    = new SolidColorBrush(Color.FromRgb( 10, 132, 255)); // #0A84FF
        private static readonly Brush BorderNormal = new SolidColorBrush(Color.FromRgb( 58,  58,  60)); // matches field bg (invisible border)
        private static readonly Brush ErrBrush    = new SolidColorBrush(Color.FromRgb(255,  69,  58)); // #FF453A

        // =====================================================================
        // Title bar
        // =====================================================================

        private Border BuildTitleBar()
        {
            var bg = new Border
            {
                Background = new SolidColorBrush(Color.FromRgb(44, 44, 46)), // #2C2C2E
                Height     = 34,
            };
            var cols = new Grid();
            cols.ColumnDefinitions.Add(
                new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            cols.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            var lbl = new Label
            {
                Content           = "PSI MONITOR  ·  STRATEGY PROFILE",
                FontSize          = 9,
                FontFamily        = new FontFamily("Segoe UI"),
                FontWeight        = FontWeights.SemiBold,
                Foreground        = FgSecondary,
                VerticalAlignment = VerticalAlignment.Center,
                Padding           = new Thickness(12, 0, 0, 0),
            };

            var x = new Label
            {
                Content                    = "✕",
                FontSize                   = 11,
                Width                      = 30,
                Foreground                 = FgSecondary,
                HorizontalContentAlignment = HorizontalAlignment.Center,
                VerticalContentAlignment   = VerticalAlignment.Center,
                Padding                    = new Thickness(0),
                Cursor                     = Cursors.Hand,
            };
            x.MouseLeftButtonDown += (_, e) => { e.Handled = true; Close(); };
            x.MouseEnter          += (_, __) => x.Foreground = FgPrimary;
            x.MouseLeave          += (_, __) => x.Foreground = FgSecondary;

            Grid.SetColumn(lbl, 0); cols.Children.Add(lbl);
            Grid.SetColumn(x,   1); cols.Children.Add(x);
            bg.Child = cols;

            cols.MouseLeftButtonDown += (_, e) =>
            {
                if (!e.Handled && e.ButtonState == MouseButtonState.Pressed) DragMove();
            };
            return bg;
        }

        // =====================================================================
        // Widget factories
        // =====================================================================

        // ── Section row with help icon ────────────────────────────────────────
        private static UIElement SectionRow(string title, string tip)
        {
            var sp = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin      = new Thickness(0, 20, 0, 8),
            };
            sp.Children.Add(new TextBlock
            {
                Text              = title,
                FontSize          = 10,
                FontFamily        = new FontFamily("Segoe UI"),
                FontWeight        = FontWeights.SemiBold,
                Foreground        = FgSecondary,  // muted Apple-style section header
                VerticalAlignment = VerticalAlignment.Center,
            });
            sp.Children.Add(HelpBadge(tip));
            return sp;
        }

        // ── Help badge ────────────────────────────────────────────────────────
        // Uses a Popup (not ToolTip) for reliable display in custom-chrome windows.
        private static Border HelpBadge(string tipText)
        {
            var inner = new TextBlock
            {
                Text                = "?",
                FontSize            = 9,
                FontWeight          = FontWeights.Bold,
                Foreground          = FgAccent,
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment   = VerticalAlignment.Center,
            };

            var badge = new Border
            {
                Width             = 16,
                Height            = 16,
                CornerRadius      = new CornerRadius(8),
                Background        = new SolidColorBrush(Color.FromArgb(40, 10, 132, 255)),
                BorderBrush       = new SolidColorBrush(Color.FromArgb(80, 10, 132, 255)),
                BorderThickness   = new Thickness(1),
                Margin            = new Thickness(7, 0, 0, 0),
                VerticalAlignment = VerticalAlignment.Center,
                Cursor            = Cursors.Help,
                Child             = inner,
            };

            // Popup tooltip — guaranteed to render on top in borderless windows
            var tipContent = new Border
            {
                Background      = new SolidColorBrush(Color.FromRgb(44, 44, 46)),
                BorderBrush     = new SolidColorBrush(Color.FromArgb(55, 255, 255, 255)),
                BorderThickness = new Thickness(1),
                CornerRadius    = new CornerRadius(8),
                Padding         = new Thickness(13, 10, 13, 11),
                MaxWidth        = 320,
                Child = new TextBlock
                {
                    Text         = tipText,
                    TextWrapping = TextWrapping.Wrap,
                    FontSize     = 11,
                    FontFamily   = new FontFamily("Segoe UI"),
                    Foreground   = new SolidColorBrush(Color.FromRgb(245, 245, 247)),
                    LineHeight   = 18,
                },
            };

            var popup = new Popup
            {
                Child              = tipContent,
                Placement          = PlacementMode.Mouse,
                HorizontalOffset   = 10,
                VerticalOffset     = 16,
                AllowsTransparency = true,
                StaysOpen          = true,
                IsHitTestVisible   = false,
            };

            badge.MouseEnter += (_, __) =>
            {
                badge.Background = new SolidColorBrush(Color.FromArgb(75, 10, 132, 255));
                inner.Foreground = FgPrimary;
                popup.IsOpen     = true;
            };
            badge.MouseLeave += (_, __) =>
            {
                badge.Background = new SolidColorBrush(Color.FromArgb(40, 10, 132, 255));
                inner.Foreground = FgAccent;
                popup.IsOpen     = false;
            };
            return badge;
        }

        // ── Field label ───────────────────────────────────────────────────────
        private static TextBlock FieldLbl(string t) => new TextBlock
        {
            Text       = t,
            FontSize   = 10,
            FontFamily = new FontFamily("Segoe UI"),
            Foreground = FgSecondary,
            Margin     = new Thickness(0, 0, 0, 5),
        };

        // ── HH:MM ─────────────────────────────────────────────────────────────
        private static UIElement HhMm(string hh, string mm,
                                      out TextBox txH, out TextBox txM)
        {
            var g = Col3(20);
            txH = MakeTx(hh); txM = MakeTx(mm);
            var c = Colon();
            Grid.SetColumn(txH, 0); g.Children.Add(txH);
            Grid.SetColumn(c,   1); g.Children.Add(c);
            Grid.SetColumn(txM, 2); g.Children.Add(txM);
            return Margin4(g);
        }

        // ── MM:SS ─────────────────────────────────────────────────────────────
        private static UIElement MmSs(string mm, string ss,
                                      out TextBox txM, out TextBox txS)
        {
            var outer = new Grid { Margin = new Thickness(0, 3, 0, 4) };
            outer.ColumnDefinitions.Add(
                new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            outer.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(20) });
            outer.ColumnDefinitions.Add(
                new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            outer.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(65) });

            txM = MakeTx(mm); txS = MakeTx(ss);
            var c = Colon();
            var lbl = new Label
            {
                Content           = "min : sec",
                FontSize          = 9,
                Foreground        = FgHint,
                VerticalAlignment = VerticalAlignment.Center,
                Padding           = new Thickness(6, 0, 0, 0),
            };

            Grid.SetColumn(txM, 0); outer.Children.Add(txM);
            Grid.SetColumn(c,   1); outer.Children.Add(c);
            Grid.SetColumn(txS, 2); outer.Children.Add(txS);
            Grid.SetColumn(lbl, 3); outer.Children.Add(lbl);
            return outer;
        }

        // ── Min / Max range row ───────────────────────────────────────────────
        private static UIElement RangeRow(string la, string va, string lb, string vb,
                                          string unit, out TextBox txA, out TextBox txB)
        {
            var g = new Grid { Margin = new Thickness(0, 0, 0, 4) };
            g.ColumnDefinitions.Add(new ColumnDefinition());
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(14) });
            g.ColumnDefinitions.Add(new ColumnDefinition());

            var left = new StackPanel();
            left.Children.Add(FieldLbl(la + "  (" + unit + ")"));
            txA = MakeTx(va);
            left.Children.Add(txA);

            var right = new StackPanel();
            right.Children.Add(FieldLbl(lb + "  (" + unit + ")"));
            txB = MakeTx(vb);
            right.Children.Add(txB);

            Grid.SetColumn(left,  0); g.Children.Add(left);
            Grid.SetColumn(right, 2); g.Children.Add(right);
            return g;
        }

        // ── Single field with unit label ──────────────────────────────────────
        private static UIElement UnitField(string label, string value,
                                           string unit, out TextBox tx)
        {
            var sp = new StackPanel { Margin = new Thickness(0, 0, 0, 4) };
            sp.Children.Add(FieldLbl(label));

            var g = new Grid();
            g.ColumnDefinitions.Add(
                new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            tx = MakeTx(value);
            var ul = new Label
            {
                Content           = unit,
                FontSize          = 9,
                Foreground        = FgHint,
                VerticalAlignment = VerticalAlignment.Center,
                Padding           = new Thickness(8, 0, 0, 0),
            };

            Grid.SetColumn(tx, 0); g.Children.Add(tx);
            Grid.SetColumn(ul, 1); g.Children.Add(ul);
            sp.Children.Add(g);
            return sp;
        }

        // ── Slider row ────────────────────────────────────────────────────────
        private static UIElement SliderRow(string name, Slider sl, out Label pct)
        {
            var g = new Grid { Margin = new Thickness(0, 5, 0, 5) };
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(170) });
            g.ColumnDefinitions.Add(
                new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(38) });

            var lbl = new TextBlock
            {
                Text              = name,
                FontSize          = 10,
                FontFamily        = new FontFamily("Segoe UI"),
                Foreground        = FgSecondary,
                VerticalAlignment = VerticalAlignment.Center,
            };

            sl.VerticalAlignment = VerticalAlignment.Center;

            pct = new Label
            {
                Content                    = "–",
                FontSize                   = 10,
                FontWeight                 = FontWeights.SemiBold,
                Foreground                 = FgAccent,
                HorizontalContentAlignment = HorizontalAlignment.Right,
                VerticalAlignment          = VerticalAlignment.Center,
                Padding                    = new Thickness(0),
                Width                      = 38,
            };

            Grid.SetColumn(lbl, 0); g.Children.Add(lbl);
            Grid.SetColumn(sl,  1); g.Children.Add(sl);
            Grid.SetColumn(pct, 2); g.Children.Add(pct);
            return g;
        }

        // ── Preset button ─────────────────────────────────────────────────────
        private Border MakePresetBtn(string text)
        {
            var lbl = new Label
            {
                Content                    = text,
                FontSize                   = 8,
                FontFamily                 = new FontFamily("Segoe UI"),
                FontWeight                 = FontWeights.SemiBold,
                Foreground                 = FgPrimary,
                HorizontalContentAlignment = HorizontalAlignment.Center,
                Padding                    = new Thickness(0, 6, 0, 6),
            };

            var btn = new Border
            {
                Background      = BgSurface,
                CornerRadius    = new CornerRadius(6),
                BorderBrush     = new SolidColorBrush(Color.FromArgb(40, 255, 255, 255)),
                BorderThickness = new Thickness(1),
                Child           = lbl,
                Cursor          = Cursors.Hand,
            };

            btn.MouseEnter += (_, __) =>
            {
                if (btn != _activePB)
                    btn.Background = new SolidColorBrush(Color.FromRgb(58, 58, 60));
            };
            btn.MouseLeave += (_, __) =>
            {
                if (btn != _activePB) btn.Background = BgSurface;
            };
            return btn;
        }

        // ── Action button ─────────────────────────────────────────────────────
        private static Border MakeActionBtn(string text, Brush bg)
        {
            var lbl = new Label
            {
                Content                    = text,
                FontSize                   = 11,
                FontFamily                 = new FontFamily("Segoe UI"),
                FontWeight                 = FontWeights.SemiBold,
                Foreground                 = FgPrimary,
                HorizontalContentAlignment = HorizontalAlignment.Center,
                Padding                    = new Thickness(0, 9, 0, 9),
            };
            var btn = new Border
            {
                Background      = bg,
                CornerRadius    = new CornerRadius(8),
                BorderBrush     = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255)),
                BorderThickness = new Thickness(1),
                Child           = lbl,
                Cursor          = Cursors.Hand,
            };
            btn.MouseEnter += (_, __) => btn.Opacity = 0.80;
            btn.MouseLeave += (_, __) => btn.Opacity = 1.0;
            return btn;
        }

        // ── Resize zone (transparent hit target) ─────────────────────────────
        private static Border ResizeZone(Cursor cursor, Action onDown)
        {
            var b = new Border
            {
                // Use a 1-alpha brush so the element still participates in hit testing
                Background = new SolidColorBrush(Color.FromArgb(1, 0, 0, 0)),
                Cursor     = cursor,
            };
            b.MouseLeftButtonDown += (_, e) => { e.Handled = true; onDown(); };
            return b;
        }

        // ── TextBox ───────────────────────────────────────────────────────────
        private static TextBox MakeTx(string value, double fs = 13) => new TextBox
        {
            Text            = value,
            FontSize        = fs,
            FontFamily      = new FontFamily("Segoe UI"),
            Foreground      = FgPrimary,
            Background      = BgField,
            BorderBrush     = BorderNormal, // same color as BgField → invisible; turns red on error
            BorderThickness = new Thickness(1),
            Padding         = new Thickness(9, 7, 9, 7),
            VerticalContentAlignment = VerticalAlignment.Center,
            CaretBrush      = FgPrimary,
        };

        // ── Slider ────────────────────────────────────────────────────────────
        private static Slider MakeSlider(double v) => new Slider
        {
            Minimum     = 1,
            Maximum     = 100,
            Value       = Math.Max(1, Math.Min(100, v)),
            SmallChange = 1,
            LargeChange = 5,
            TickFrequency = 5,
        };

        // ── Tiny helpers ──────────────────────────────────────────────────────
        private static Grid Col3(double midWidth)
        {
            var g = new Grid();
            g.ColumnDefinitions.Add(new ColumnDefinition());
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(midWidth) });
            g.ColumnDefinitions.Add(new ColumnDefinition());
            return g;
        }

        private static Border Margin4(UIElement child)
        {
            var b = new Border { Margin = new Thickness(0, 0, 0, 4), Child = (FrameworkElement)child };
            return b;
        }

        private static TextBlock Colon() => new TextBlock
        {
            Text              = ":",
            FontSize          = 15,
            FontWeight        = FontWeights.SemiBold,
            Foreground        = FgHint,
            HorizontalAlignment = HorizontalAlignment.Center,
            VerticalAlignment = VerticalAlignment.Center,
            TextAlignment     = TextAlignment.Center,
            Margin            = new Thickness(0, -1, 0, 0),
        };
    }
}
