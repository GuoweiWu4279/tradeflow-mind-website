// PsiEngine.cs
//
// Core PSI calculation engine.  Implements all seven behavioural signal dimensions,
// the weighted composite, and the asymmetric time-weighted EWMA.
//
// Design constraints:
//   - Zero NinjaTrader API dependencies — fully unit-testable in isolation.
//   - All public methods are thread-safe (single internal lock).
//   - No blocking I/O, no allocations on the hot path.
//   - All dimension outputs are strictly in [0, 1].
//   - PSI is strictly in [0, 100].

using System;
using System.Collections.Generic;

namespace NinjaTrader.NinjaScript.AddOns
{
    public sealed class PsiEngine
    {
        // =====================================================================
        // Dependencies (injected, immutable)
        // =====================================================================

        private readonly StrategyProfile  _profile;
        private readonly TradeBaseline    _baseline;
        private readonly PsiEngineConfig  _cfg;
        private readonly object           _sync = new object();

        // =====================================================================
        // PSI state
        // =====================================================================

        private double   _psi            = 100.0;
        private DateTime _lastEwmaUpdate = DateTime.MinValue;

        // =====================================================================
        // Consecutive-loss counter  (float for geometric decay)
        // =====================================================================

        private double _consecutiveLosses = 0.0;

        // =====================================================================
        // D1 — Revenge Entry state
        // =====================================================================

        private double   _lastRealizedPnl       = 0.0;
        private DateTime _lastRealizedFillTime  = DateTime.MinValue;

        // Direction of the last CLOSED position:
        //   +1 = was Long,  -1 = was Short,  0 = unknown
        private int _lastRealizedDirection = 0;

        // =====================================================================
        // D2 — Stop-Loss Manipulation state
        // Key = orderId.  Cleared when any position closes.
        // =====================================================================

        private readonly Dictionary<string, double> _prevSlTicks  = new Dictionary<string, double>();
        private readonly Dictionary<string, int>    _adverseMoves = new Dictionary<string, int>();

        // =====================================================================
        // D6 — Hard-deduction cooldown (max one per HardDeductionCooldownSec)
        // =====================================================================

        private DateTime _lastHardDeductionTime = DateTime.MinValue;

        // =====================================================================
        // D7 — Overtrading (过度交易)
        //
        // Measures intra-session entry pace acceleration and deviation from
        // the trader's declared profile frequency.  Fires regardless of P&L:
        // a winning streak at 10× normal pace is still a psychological alarm.
        //
        // Two signals combined as max():
        //   A. Acceleration: recentAvgGap << sessionAvgGap
        //   B. Profile:      sessionAvgGap << expectedGap (from LambdaVelocity)
        //
        // Partial-fill deduplication: entries within OversizeImpulseCooldownSec
        // of the previous entry are ignored (one order = one entry decision).
        // =====================================================================

        // Ring buffer of the most recent D7AccelWindowEntries entry timestamps.
        private readonly Queue<DateTime> _recentEntryTimes  = new Queue<DateTime>();
        private DateTime _sessionFirstEntryTime             = DateTime.MinValue;
        private int      _sessionEntryCount                 = 0;
        // Last entry fill time used for partial-fill deduplication.
        private DateTime _lastEntryFillTime                 = DateTime.MinValue;

        // =====================================================================
        // Live Exposure Monitor — tracks whether open position currently exceeds
        // profile.SizeMax, enabling the real-time D3 override in PollPositions.
        // =====================================================================

        // True while the trader holds more contracts than profile.SizeMax.
        // When true: D3 is overridden with the live reading, and EWMA recovery
        // is completely frozen (PSI can only fall or hold, never climb).
        private bool     _liveOverExposed         = false;

        // After overexposure clears, recovery is throttled for OverexposureCooldownMinutes
        // so that a lucky profitable exit doesn't immediately erase the position risk memory.
        private DateTime _overExposureCooldownEnd = DateTime.MinValue;

        // Last platformTime seen by PollPositions — used to detect when
        // Market Replay is paused (same time each tick) so EWMA doesn't keep
        // pushing PSI down while the trader can't act.
        private DateTime _lastPollPlatformTime = DateTime.MinValue;

        // ── Oversize impulse tracking ─────────────────────────────────────────
        // When the net position crosses into (or worsens) the oversize zone,
        // we force a minimum EWMA alpha so the penalty is visible immediately
        // even when Δt ≈ 0 (e.g. two fills at the same Market Replay timestamp).
        // _prevSizeForD remembers the last sizeForD to detect worsening.
        // _oversizeImpulseLastTime provides a short cooldown so a single order
        // reported as multiple partial fills only fires one impulse.
        private double   _prevSizeForD            = 0.0;
        private DateTime _oversizeImpulseLastTime = DateTime.MinValue;

        // =====================================================================
        // Sustained violation escalation
        //
        // Tracks how many consecutive fills produced at least one extreme
        // dimension score (≥ ExtremeThreshold).  Drives two mechanisms in
        // CompositeRawPenalty that break through the weighted-sum ceiling:
        //   1. Boost:      BoostFactor × maxD²  (stateless, any single extreme)
        //   2. Escalation: EscalationPerFill per consecutive extreme fill
        //                  (stateful, catches Martingale spirals and revenge
        //                  cascades; capped at MaxEscalationFills)
        // Decremented by 1 on each calm fill, so the trader must demonstrate
        // sustained improvement to escape the penalty zone.
        // =====================================================================

        private int _sustainedViolationCount = 0;

        // 0-based index (0=D1…6=D7) of the dimension that last incremented
        // _sustainedViolationCount above zero.  Escalation is attributed to this
        // dimension rather than the instantaneous highest at each tick, so the HUD
        // bar that caused the sustained-violation spiral is the one that grows.
        // -1 = no active escalation target.
        private int _sustainedViolationDimIdx = -1;

        // ExtremeThreshold, BoostFactor, EscalationPerFill, MaxEscalationFills
        // now read from _cfg (PsiEngineConfig).

        // =====================================================================
        // Instantaneous dimension signals  (0–1, refreshed on each event)
        // These are the raw behavioural inputs that feed the EWMA debt below.
        // Also exposed publicly (ScoreD1-D6) for session-record and log use.
        // =====================================================================

        private double _d1, _d2, _d3, _d4, _d5, _d6, _d7;

        // =====================================================================
        // Decomposed PSI debt per dimension  (unit: PSI points, 0–100)
        //
        // Each C_i tracks how many PSI points dimension i currently "owes"
        // via its own asymmetric EWMA.  The identity
        //
        //     PSI  =  100  −  Σ C_i  −  _carryDebt
        //
        // holds at every moment, so the HUD bars are a perfect decomposition
        // of the PSI value: if PSI = 50, the seven bars sum to ~45–50 pts and
        // the longest bar is the primary culprit.
        // =====================================================================

        private double _c1, _c2, _c3, _c4, _c5, _c6, _c7;

        // Carry-forward debt from the previous session.
        // Initialised to (100 − sessionOpenPsi) in StartNewSession.
        // Decays at the recovery tau so it dissolves as the trader trades
        // calmly today.  Not attributed to any dimension bar — it is
        // historical context, not a current behavioural signal.
        private double _carryDebt = 0.0;

        // =====================================================================
        // Constructor
        // =====================================================================

        /// <param name="profile">Strategy profile (user-supplied priors).</param>
        /// <param name="baseline">Historical baseline statistics.</param>
        /// <param name="config">
        /// Engine tuning parameters.  Pass null to use <see cref="PsiEngineConfig.Default"/>
        /// (exact original hard-coded values).
        /// </param>
        public PsiEngine(StrategyProfile profile, TradeBaseline baseline,
                         PsiEngineConfig config = null)
        {
            _profile  = profile  ?? throw new ArgumentNullException("profile");
            _baseline = baseline ?? throw new ArgumentNullException("baseline");
            _cfg      = config   ?? PsiEngineConfig.Default;
        }

        // =====================================================================
        // Public API
        // =====================================================================

        /// <summary>Current PSI score (0 = fully tilted, 100 = perfectly stable).</summary>
        public double CurrentPsi { get { lock (_sync) return _psi; } }

        /// <summary>Active configuration (read-only reference).</summary>
        public PsiEngineConfig Config => _cfg;

        // ── Instantaneous raw dimension signals (0–1) ────────────────────────
        // Used by TradeMonitor to record per-trade behavioural state in
        // SessionData (Tilt Cascade, Behavioral Quality Score).
        // NOT used for the live HUD bars — use DebtD1-D6 instead.
        public double ScoreD1 { get { lock (_sync) return _d1; } }
        public double ScoreD2 { get { lock (_sync) return _d2; } }
        public double ScoreD3 { get { lock (_sync) return _d3; } }
        public double ScoreD4 { get { lock (_sync) return _d4; } }
        public double ScoreD5 { get { lock (_sync) return _d5; } }
        public double ScoreD6 { get { lock (_sync) return _d6; } }
        public double ScoreD7 { get { lock (_sync) return _d7; } }

        // ── EWMA debt per dimension (unit: PSI points, 0–100) ────────────────
        // These power the HUD bar display.  Their sum + _carryDebt = 100 − PSI,
        // so the bars are a mathematically exact decomposition of the PSI value.
        // When PSI = 95, all bars are near-zero.  When PSI = 50, the bars sum
        // to ~50 pts and the longest bar identifies the primary cause.
        public double DebtD1 { get { lock (_sync) return _c1; } }
        public double DebtD2 { get { lock (_sync) return _c2; } }
        public double DebtD3 { get { lock (_sync) return _c3; } }
        public double DebtD4 { get { lock (_sync) return _c4; } }
        public double DebtD5 { get { lock (_sync) return _c5; } }
        public double DebtD6 { get { lock (_sync) return _c6; } }
        public double DebtD7 { get { lock (_sync) return _c7; } }

        /// <summary>
        /// True when the current open position exceeds profile.SizeMax.
        /// Consumed by the HUD overlay to show the "OVERSIZE" alarm indicator and
        /// to suppress PSI recovery until the position is reduced.
        /// </summary>
        public bool IsOverExposed { get { lock (_sync) return _liveOverExposed; } }

        /// <summary>
        /// Carry-forward PSI debt from the previous session (PSI points, 0–100).
        /// Decays toward zero as the trader demonstrates calm behaviour today.
        /// When non-zero, it contributes to the PSI deficit alongside C1–C7 but is
        /// not attributable to any single current behaviour — it is historical context.
        /// The HUD displays this so the trader can distinguish "recovering from
        /// yesterday" from "recovering from today's own violations".
        /// </summary>
        public double CarryDebt { get { lock (_sync) return _carryDebt; } }

        // ─────────────────────────────────────────────────────────────────────

        /// <summary>
        /// Call on every confirmed fill (NT8 ExecutionUpdate).
        /// Updates D1, D3, D4, and the size-portion of D6.
        /// IMPORTANT: call <see cref="TradeBaseline.UpdateOnExecution"/> BEFORE
        /// this so that session averages are already updated when D4 reads them.
        /// </summary>
        /// <param name="pnl">Gross PnL of this fill (negative = loss).</param>
        /// <param name="size">Filled quantity (contracts / shares).</param>
        /// <param name="fillTime">Wall-clock time of the fill.</param>
        /// <param name="isWin">True when pnl &gt; 0.</param>
        /// <param name="holdSeconds">
        /// Seconds from position entry to this close-fill.  Zero for entry fills.
        /// </param>
        /// <param name="currentNetPosition">
        /// Net open position (contracts) AFTER this fill.
        /// Pass 0 for closing fills (position is flat).
        /// Used by D3 and D6 to evaluate cumulative exposure, not just single-fill size.
        /// </param>
        /// <param name="fillDirection">
        /// Direction of THIS fill:
        ///   +1 = opening / holding a Long position,
        ///   -1 = opening / holding a Short position,
        ///    0 = unknown.
        /// For CLOSING fills, pass the direction of the position that was CLOSED.
        /// For OPENING fills, pass the direction of the new position.
        /// Used by D1 to distinguish panicked double-downs from strategic direction flips.
        /// </param>
        /// <returns>Updated PSI.</returns>
        public double ProcessExecution(double pnl, double size, DateTime fillTime,
                                       bool isWin, double holdSeconds,
                                       double currentNetPosition = 0,
                                       int fillDirection = 0)
        {
            lock (_sync)
            {
                bool hasRealizedOutcome = holdSeconds > 0 || pnl != 0.0;

                // ── Consecutive losses (geometric decay) ──────────────────────
                // Only update on realised outcomes. Entry fills (PnL=0) must not
                // increment or reset the loss streak.
                if (hasRealizedOutcome)
                {
                    if (isWin)
                    {
                        _consecutiveLosses *= _cfg.WinStreakDecayFactor;
                        if (_consecutiveLosses < _cfg.StreakClearThreshold)
                            _consecutiveLosses = 0.0;
                    }
                    else
                    {
                        _consecutiveLosses += 1.0;
                    }
                }

                double muLoss = _baseline.GetEffectiveMuLoss();
                double muSize = _baseline.GetEffectiveMuSize(_profile);

                // ── D1: Revenge Entry ─────────────────────────────────────────
                _d1 = CalcD1(size, fillTime, muLoss, muSize, hasRealizedOutcome, fillDirection);

                // ── D3: Size Outlier ──────────────────────────────────────────
                // Use net position (not single-fill qty) to catch salami-slicing
                // scale-ins (e.g. 3×3 lots → 9 lots net triggers once at 9).
                //
                // Closing fills (hasRealizedOutcome = true): sizeForD = 0.
                //   The trader is REDUCING exposure — charging D3 again on the exit
                //   would penalise them for correcting an oversize mistake.
                //   Ongoing overexposure during the hold is captured by PollPositions
                //   (fires every 30 s while position > SizeMax) — no gap in coverage.
                //
                // Entry fills (hasRealizedOutcome = false): use cumulative net position
                //   so D3 fires on the total (catches 3×3-lot scale-ins).
                double sizeForD = hasRealizedOutcome
                    ? 0.0
                    : (currentNetPosition > 0 ? currentNetPosition : size);
                _d3 = CalcD3(sizeForD, muSize);

                // ── D4: Hold-Time Collapse ────────────────────────────────────
                _d4 = CalcD4();

                // ── D6: Rule Compliance (size + time window; no SL info here) ─
                // Closing fills are suppressed entirely: the session-window (and size)
                // violation was already captured at entry time.  Re-charging D6 on the
                // closing fill penalises the corrective exit action — the opposite of
                // what the system should do.  The EWMA debt from the entry deduction
                // persists naturally; no additional signal needed on the close.
                double d6Hard = 0.0;
                _d6 = hasRealizedOutcome
                    ? _d6   // hold current value; EWMA decay handles the return
                    : CalcD6(fillTime, slTicks: 0, size: sizeForD, out d6Hard);

                // ── D7: Overtrading — only updates on entry fills ─────────────
                _d7 = CalcD7(fillTime, isEntry: !hasRealizedOutcome);

                // ── D2: Reset adverse-move tracking when a position FULLY closes ─
                // Partial closes (currentNetPosition > 0) still have open exposure,
                // so the stop-manipulation history remains relevant for the residual.
                // Only purge when the position is completely gone (currentNetPosition == 0).
                // Use (pnl != 0 || holdSeconds > 0) instead of just holdSeconds > 0:
                // bootstrapped positions (entry time from reconciliation) correctly
                // report holdSeconds=0 but still represent a real close if PnL != 0.
                if ((holdSeconds > 0 || pnl != 0.0) && currentNetPosition == 0)
                {
                    _adverseMoves.Clear();
                    _prevSlTicks.Clear();
                    _d2 = 0.0;
                }

                // ── Persist state for next D1 evaluation ──────────────────────
                // D1 anchors on the LAST REALISED outcome, not entry fills.
                // For closing fills (holdSeconds > 0), fillDirection carries the
                // direction of the position that was just closed — stored so CalcD1
                // can detect same-direction double-downs vs. strategic flips.
                if (hasRealizedOutcome)
                {
                    _lastRealizedPnl       = pnl;
                    _lastRealizedFillTime  = fillTime;
                    if (fillDirection != 0)
                        _lastRealizedDirection = fillDirection;
                }

                // ── Sustained violation tracking ────────────────────────────
                if (MaxDimension() >= _cfg.ExtremeThreshold)
                {
                    _sustainedViolationCount = Math.Min(
                        _sustainedViolationCount + 1, _cfg.MaxEscalationFills);
                    // Record which dimension is driving the violation so escalation
                    // can be attributed to it rather than whatever happens to be
                    // highest at the moment the escalation penalty fires.
                    _sustainedViolationDimIdx = MaxDimensionIndex();
                }
                else if (_sustainedViolationCount > 0)
                {
                    _sustainedViolationCount--;
                    if (_sustainedViolationCount == 0)
                        _sustainedViolationDimIdx = -1;
                }

                // ── Oversize impulse ─────────────────────────────────────────
                // When the net position crosses into (or worsens) the oversize
                // zone, fill.Time may equal the previous fill's time (Market
                // Replay paused) or differ by only milliseconds, making the
                // EWMA alpha ≈ 0 and swallowing the D3 penalty entirely.
                //
                // Fix: force a minimum alpha of 1 - 1/e ≈ 0.632 — exactly the
                // weight that would apply after one full EwmaDropTau has elapsed.
                // This is the EWMA "one time-constant step response": principled,
                // not a magic number.
                //
                // Partial-fill deduplication: a single order split into n fills
                // by NT8 would fire n impulses for one decision. The cooldown
                // (OversizeImpulseCooldownSec, default 3 s) prevents this.
                double impulseMinAlpha = 0.0;
                if (sizeForD > _profile.SizeMax && sizeForD > _prevSizeForD)
                {
                    bool inCooldown = _oversizeImpulseLastTime != DateTime.MinValue &&
                        Math.Abs((fillTime - _oversizeImpulseLastTime).TotalSeconds)
                            < _cfg.OversizeImpulseCooldownSec;
                    if (!inCooldown)
                    {
                        impulseMinAlpha          = 1.0 - Math.Exp(-1.0); // ≈ 0.632
                        _oversizeImpulseLastTime = fillTime;
                    }
                }
                _prevSizeForD = sizeForD;

                // Set overexposure flag immediately at fill time.
                // PollPositions (30-second timer) also sets/clears this flag, but only
                // fires up to 30 seconds after the oversize fill — causing the "OVERSIZE ALARM"
                // banner and PSI recovery-freeze to appear late.  Setting it here removes
                // that delay: the moment a fill brings cumulative size above SizeMax, the
                // HUD alarm fires on the same PushPsiToHud call that processes the fill.
                // PollPositions remains responsible for CLEARING the flag (it cross-checks
                // all accounts; ProcessExecution cannot safely do so).
                if (sizeForD > _profile.SizeMax)
                    _liveOverExposed = true;

                return ApplyDecomposedEwma(fillTime,
                    d2HardDeduction: 0.0,
                    d6HardDeduction: d6Hard,
                    oversizeMinAlpha: impulseMinAlpha);
            }
        }

        // ─────────────────────────────────────────────────────────────────────

        /// <summary>
        /// Call on every NT8 OrderUpdate that modifies a stop-loss price.
        /// Updates D2 (stop manipulation) and the SL-range + time portions of D6.
        /// </summary>
        /// <param name="orderId">Unique NT8 order ID string.</param>
        /// <param name="newSlTicks">
        /// New stop-loss width in ticks (absolute distance from entry; always positive).
        /// </param>
        /// <param name="orderTime">Time of this order change.</param>
        /// <param name="orderSize">
        /// Order size (optional).  Pass 0 if unknown — size check in D6 will be skipped.
        /// </param>
        public void ProcessOrderChange(string orderId, double newSlTicks,
                                       DateTime orderTime, double orderSize = 0)
        {
            if (string.IsNullOrEmpty(orderId) || newSlTicks <= 0) return;

            lock (_sync)
            {
                // ── D2: Adverse stop-move detection ───────────────────────────
                // Widening the stop (larger ticks from entry) = adverse.
                if (_prevSlTicks.TryGetValue(orderId, out double prevTicks))
                {
                    if (newSlTicks > prevTicks + _cfg.D2SlTickRoundingBuffer)
                    {
                        int prev = _adverseMoves.TryGetValue(orderId, out int cv) ? cv : 0;
                        _adverseMoves[orderId] = prev + 1;
                    }
                }
                _prevSlTicks[orderId] = newSlTicks;

                // Recompute D2 from the latest SL width (captures both move count
                // and the absolute extent of the violation).
                _d2 = CalcD2(newSlTicks);

                // ── D6: SL-range + time window ────────────────────────────────
                double d6Hard;
                _d6 = CalcD6(orderTime, slTicks: newSlTicks, size: orderSize, out d6Hard);

                ApplyDecomposedEwma(orderTime,
                    d2HardDeduction: 0.0,
                    d6HardDeduction: d6Hard);
            }
        }

        // ─────────────────────────────────────────────────────────────────────

        /// <summary>
        /// Call every 30 seconds from the background timer.
        /// Updates D5 (position-hold / 扛单 monitor) and allows PSI to recover
        /// naturally when all signals are low.
        /// </summary>
        /// <param name="positions">
        /// Snapshot of all currently open positions, captured by TradeMonitor.
        /// </param>
        /// <param name="platformTime">
        /// Current platform time injected by the caller.
        /// Use NinjaTrader.Core.Globals.Now (not DateTime.Now) so that the EWMA
        /// clock respects playback / simulation speed and does not drift during pauses.
        /// </param>
        /// <param name="nakedPositionDetected">
        /// Set to true if at least one open position was found with no covering stop-loss
        /// order and has been open longer than <see cref="StrategyProfile.NoStopGraceSeconds"/>.
        /// The caller (TradeMonitor) should fire an immediate critical alert when this is true.
        /// </param>
        /// <returns>Updated PSI.</returns>
        public double PollPositions(IEnumerable<PositionSnapshot> positions,
                                    DateTime platformTime,
                                    out bool nakedPositionDetected)
        {
            lock (_sync)
            {
                // ── Time-base sanity checks ──────────────────────────────────
                // Detect two forms of clock corruption that occur in Market Replay:
                //
                // 1. Frozen: Globals.Now returns the same value each tick (paused).
                // 2. Switched: Globals.Now jumps from playback time (07:xx) to
                //    real wall-clock time (11:xx AM) — a multi-hour gap.
                //
                // In either case, skip ALL stateful updates (EWMA, hard deductions,
                // cooldown timers) so PSI holds steady while the trader cannot act.
                // D-scores and overexposure flags are still refreshed below since
                // they are pure reads of current state, not time-dependent.
                bool timeFrozen = _lastPollPlatformTime != DateTime.MinValue &&
                    Math.Abs((platformTime - _lastPollPlatformTime).TotalSeconds) < _cfg.PollFrozenThresholdSec;
                bool timeSwitched = _lastEwmaUpdate != DateTime.MinValue &&
                    Math.Abs((platformTime - _lastEwmaUpdate).TotalSeconds) > _cfg.EwmaForwardGuardSec;
                bool skipEwma = timeFrozen || timeSwitched;

                _lastPollPlatformTime = platformTime;

                _d5 = CalcD5(positions, out nakedPositionDetected);

                // ── Live Exposure Monitor (real-time D3 override) ─────────────
                // Check each position independently — DO NOT sum across positions
                // because copy-trading followers (Replikanto) replicate the same
                // trade to multiple accounts.  Summing would multiply the exposure
                // by the number of accounts and trigger false oversize alarms.
                bool anyOverExposed = false;
                if (positions != null)
                {
                    foreach (var snap in positions)
                    {
                        if (snap.Quantity > _profile.SizeMax)
                        {
                            anyOverExposed = true;
                            double muSize  = _baseline.GetEffectiveMuSize(_profile);
                            double liveD3  = CalcD3(snap.Quantity, muSize);
                            if (liveD3 > _d3) _d3 = liveD3;
                        }
                    }
                }

                bool wasOverExposed = _liveOverExposed;
                if (anyOverExposed)
                {
                    _liveOverExposed = true;
                }
                else
                {
                    _liveOverExposed = false;
                    if (wasOverExposed && !skipEwma)
                        _overExposureCooldownEnd = platformTime.AddMinutes(_cfg.OverexposureCooldownMinutes);
                }

                if (nakedPositionDetected)
                    _d2 = 1.0;
                else if (_d2 >= 1.0)
                    _d2 = _cfg.D2PartialRelaxValue;

                if (skipEwma)
                    return _psi;

                // ── Hard deduction for naked position ─────────────────────────
                // Attributed to D2 (Stop-Loss Manipulation) so the D2 bar
                // spikes immediately, making the cause visible to the trader.
                double d2Hard = 0.0;
                if (nakedPositionDetected)
                {
                    double secSinceLast = _lastHardDeductionTime == DateTime.MinValue
                        ? double.MaxValue
                        : (platformTime - _lastHardDeductionTime).TotalSeconds;
                    if (secSinceLast >= _cfg.HardDeductionCooldownSec)
                    {
                        double freq   = _baseline.GetNakedFrequency();
                        double rarity = Math.Max(0.1, 1.0 - freq);
                        d2Hard                 = _cfg.NakedPositionDeduction * rarity;
                        _lastHardDeductionTime = platformTime;
                    }
                }

                return ApplyDecomposedEwma(platformTime,
                    d2HardDeduction: d2Hard,
                    d6HardDeduction: 0.0);
            }
        }

        // ─────────────────────────────────────────────────────────────────────

        /// <summary>
        /// Called at startup or Playback restart when only the previous session's
        /// final PSI is available (individual C_i values are not persisted to disk).
        ///
        /// Opening PSI is computed via overnight EWMA decay of the aggregate deficit:
        ///   openPSI = 100 − (100 − prevFinalPsi) × exp(−estimatedHours / τ_overnight)
        ///
        /// This replaces the old three-bucket (threshold → fixed value) system, which
        /// created cliff edges (PSI 69 → 80, PSI 70 → 95) and a flat floor (PSI 0–39
        /// all gave 65).  The continuous formula gives proportional, fair opening values.
        ///
        /// All C_i debts are reset to zero because they are not recoverable at startup;
        /// the entire history is summarised as _carryDebt = 100 − openPSI.
        /// </summary>
        /// <param name="previousSessionFinalPsi">
        /// PSI at the moment the previous session ended.  Pass 100 on first run.
        /// </param>
        public void StartNewSession(double previousSessionFinalPsi)
        {
            lock (_sync)
            {
                // Continuous overnight decay: deficit shrinks proportionally.
                double decayFactor = Math.Exp(
                    -_cfg.OvernightEstimatedHours / _cfg.OvernightRecoveryTauHours);
                _psi = 100.0 - (100.0 - previousSessionFinalPsi) * decayFactor;
                _psi = Math.Max(0.0, Math.Min(100.0, _psi));

                // C_i history is not available at startup — encode the entire deficit
                // as carryDebt so the decomposition identity holds (PSI = 100 − Σ C_i − carryDebt).
                _c1 = _c2 = _c3 = _c4 = _c5 = _c6 = _c7 = 0.0;
                _carryDebt = Math.Max(0.0, 100.0 - _psi);

                // D7 pace state must be reset on a full session restart (startup /
                // Playback rewind).  NOT reset by ResetBehavioralFlagsInternal — see
                // comment there.
                ResetD7PaceState();

                ResetBehavioralFlagsInternal();
            }
        }

        /// <summary>
        /// Called at a real cross-day session boundary when live C_i debt values are
        /// still in memory.  Applies the actual overnight elapsed time to each dimension's
        /// debt independently, then resets intra-session behavioural state.
        ///
        ///   C_i_open = C_i_close × exp(−elapsedHours / τ_overnight)
        ///
        /// Benefits over StartNewSession:
        ///   • No information loss — all seven debt components are individually preserved.
        ///   • Actual elapsed time is used (handles weekends, holidays automatically).
        ///   • A 60-hour weekend gap recovers more than a 16-hour overnight gap, which
        ///     is psychologically correct.
        /// </summary>
        public void ApplyOvernightDecay(double elapsedHours)
        {
            lock (_sync)
            {
                double decay = Math.Exp(
                    -Math.Max(0.0, elapsedHours) / _cfg.OvernightRecoveryTauHours);

                _c1 *= decay;  _c2 *= decay;  _c3 *= decay;
                _c4 *= decay;  _c5 *= decay;  _c6 *= decay;  _c7 *= decay;
                _carryDebt *= decay;

                // Recompute PSI from the decayed components.
                _psi = 100.0 - _c1 - _c2 - _c3 - _c4 - _c5 - _c6 - _c7 - _carryDebt;
                _psi = Math.Max(0.0, Math.Min(100.0, _psi));

                ResetD7PaceState();
                ResetBehavioralFlagsInternal();
            }
        }

        /// <summary>
        /// Called by Fix A (stale-state reset) and OnPositionUpdate (external flat)
        /// to clear intra-session position-tracking state without touching PSI or C_i.
        ///
        /// Purpose: Fix A detects a phantom direction (e.g. stale Long after account
        /// reset) and needs to restart position tracking cleanly.  It does NOT need to
        /// reset behavioural debt — the trader's accumulated D3/D1/etc. violations are
        /// a fact of the session, not an artefact of the position-tracking state machine.
        ///
        /// Resets: all state-machine flags that could fire false penalties on the very
        ///         next fill (overexposure, escalation, timing guards).
        /// Preserves: _c1–_c6, _carryDebt, _psi  (the psychological history).
        /// </summary>
        public void ResetBehavioralFlags()
        {
            lock (_sync)
            {
                ResetBehavioralFlagsInternal();
            }
        }

        // Internal helper (must be called from within _sync lock).
        private void ResetD7PaceState()
        {
            _recentEntryTimes.Clear();
            _sessionFirstEntryTime = DateTime.MinValue;
            _sessionEntryCount     = 0;
            _lastEntryFillTime     = DateTime.MinValue;
        }

        private void ResetBehavioralFlagsInternal()
        {
            _consecutiveLosses        = 0.0;
            _lastRealizedPnl          = 0.0;
            _lastRealizedFillTime     = DateTime.MinValue;
            _lastRealizedDirection    = 0;
            _lastHardDeductionTime    = DateTime.MinValue;
            _lastEwmaUpdate           = DateTime.MinValue;
            _liveOverExposed          = false;
            _overExposureCooldownEnd  = DateTime.MinValue;
            _lastPollPlatformTime     = DateTime.MinValue;
            _sustainedViolationCount  = 0;
            _sustainedViolationDimIdx = -1;
            _prevSizeForD             = 0.0;
            _oversizeImpulseLastTime  = DateTime.MinValue;

            _d1 = _d2 = _d3 = _d4 = _d5 = _d6 = _d7 = 0.0;

            // D7 raw score resets so it recomputes on the very next entry fill.
            // The PACE FIELDS (_recentEntryTimes, _sessionEntryCount, etc.) are
            // intentionally NOT cleared here.  They record factual entry history
            // this session — a position-tracking reset (Fix A / OnPositionUpdate)
            // does not erase the trader's behavioural record.  Those fields are
            // cleared only by StartNewSession and ApplyOvernightDecay (full restart).

            _adverseMoves.Clear();
            _prevSlTicks.Clear();
        }

        // =====================================================================
        // Dimension calculations  (called from within the lock)
        // =====================================================================

        // ── D1: Revenge Entry ─────────────────────────────────────────────────
        // Three-way AND: significant loss on last fill × quick re-entry × larger size.
        // Returns 0 unless ALL three conditions are met.
        //
        // Direction-reversal discount (ReversalPenaltyFactor):
        //   When the new entry is in the OPPOSITE direction to the closed position,
        //   the score is multiplied by ReversalPenaltyFactor (default 0.25).
        //   Rationale: closing Short and immediately going Long is often a tactical
        //   "flip" driven by a new signal, not emotional revenge (especially for
        //   scalpers).  Same-direction re-entry (double-down) always uses the full
        //   penalty since it is the canonical revenge pattern.
        //
        //   The discount is intentionally NOT zero so that an outsized flip
        //   (e.g. 4× position after a big loss) still registers weakly.

        private double CalcD1(double size, DateTime fillTime, double muLoss,
                               double muSize, bool hasRealizedOutcome, int entryDirection = 0)
        {
            if (hasRealizedOutcome) return 0.0;
            if (_lastRealizedFillTime == DateTime.MinValue) return 0.0;
            if (_lastRealizedPnl >= 0) return 0.0;   // only after a loss

            double T = _profile.MaxReentrySeconds;
            if (T <= 0) return 0.0;
            double deltaSec = Math.Max(_cfg.D1MinDeltaSeconds,
                (fillTime - _lastRealizedFillTime).TotalSeconds);
            if (deltaSec >= T) return 0.0;

            double urgency = (T - deltaSec) / T;

            // ── lossX: two additive components ──────────────────────────────
            //
            // Component A — statistical severity (existing):
            //   Fires at full strength for outlier losses (lossZ >> ZThreshold).
            //   Near-zero for average-sized losses — that is intentional; a single
            //   normal stop-loss is not inherently alarming.
            //
            // Component B — consecutive-loss pressure (new):
            //   Even average-sized losses create cumulative psychological stress
            //   when they occur in a row.  After N straight losses the trader's
            //   mental state is meaningfully different from after 0 losses — the
            //   system's goal is to measure this, not to judge whether the loss
            //   was "valid" or not.
            //   Uses an exponential saturation so the first loss barely moves
            //   the needle, the second and third create a noticeable signal,
            //   and the curve flattens out to prevent runaway charging.
            double sigmaLoss  = _baseline.GetEffectiveSigmaLoss();
            double lossZ      = muLoss > 0
                              ? (Math.Abs(_lastRealizedPnl) - muLoss) / sigmaLoss
                              : 0.0;
            double lossXStat  = NormalCdf(lossZ - _cfg.ZThreshold);

            double streakPressure = _cfg.D1ConsecutiveLossBase
                                  * (1.0 - Math.Exp(-_cfg.D1ConsecutiveLossGain * _consecutiveLosses));

            double lossX = Math.Max(lossXStat, streakPressure);
            if (lossX <= 0) return 0.0;

            // Size: amplifier only — NOT a hard gate.
            double sigmaSize = _baseline.GetEffectiveSigmaSize(_profile);
            double sizeZ     = muSize > _cfg.D1MuSizeZeroGuard
                             ? (size - muSize) / sigmaSize : 0.0;
            double sizeX     = NormalCdf(Math.Max(sizeZ, 0.0) - _cfg.ZThreshold * 0.5);

            double baseScore = Clamp01(urgency * Math.Max(sizeX, _cfg.D1MinSizeFactor) * lossX);

            bool isReversal = _lastRealizedDirection != 0
                           && entryDirection        != 0
                           && entryDirection        != _lastRealizedDirection;

            double dirFactor = isReversal
                ? Clamp01(_profile.ReversalPenaltyFactor)
                : 1.0;

            return Clamp01(baseScore * dirFactor);
        }

        // ── D2: Stop-Loss Manipulation ────────────────────────────────────────
        // Exponential penalty on the number of adverse stop moves, boosted if
        // the current SL already exceeds the profile maximum.

        private double CalcD2(double currentSlTicks)
        {
            // Count the maximum adverse moves across all tracked orders.
            int maxAdverse = 0;
            foreach (var kv in _adverseMoves)
                if (kv.Value > maxAdverse) maxAdverse = kv.Value;

            double baseScore = 1.0 - Math.Exp(-_cfg.D2AdverseSaturationRate * maxAdverse);

            double maxTicks = _profile.SlTicksMax;
            if (maxTicks > 0 && currentSlTicks > maxTicks * _cfg.D2SlBreachMultiplier)
                return Clamp01(baseScore * (currentSlTicks / maxTicks));

            return Clamp01(baseScore);
        }

        // ── D3: Position Size Outlier ─────────────────────────────────────────
        // Z-score scaled by the consecutive-loss multiplier (context-sensitive).
        // Multiplier is applied INSIDE NormalCdf so the output stays in (0, 1).
        //
        // Within-range behaviour:
        //   size ≤ SizeMax  → D3 is proportionally capped at D3WithinProfileCap.
        //     The cap scales linearly: 0 at SizeMin, D3WithinProfileCap at SizeMax.
        //     Consecutive losses raise the *effective* bar within that cap, but the
        //     cap itself is a hard ceiling — even after 5 straight losses the bar
        //     CANNOT go red for a trade that is within the trader's declared range.
        //   size > SizeMax  → no cap; D3ProfileViolationFloor guarantees a minimum.
        //
        // This ensures the D3 bar is consistent with PSI: yellow/amber = within
        // profile (informational), orange/red = profile violation (alarm).

        private double CalcD3(double size, double muSize)
        {
            double sigma = _baseline.GetEffectiveSigmaSize(_profile);
            double z     = (size - muSize) / sigma;
            double ctx   = 1.0 + _cfg.D3ConsecutiveLossGain * _consecutiveLosses;
            double raw   = Clamp01(NormalCdf(z * ctx - _cfg.ZThreshold));

            if (size > 0 && size <= _profile.SizeMax)
            {
                // Proportional position along the declared range [SizeMin, SizeMax].
                // t = 0 at SizeMin (no concern), t = 1 at SizeMax (at the limit).
                double range = _profile.SizeMax - _profile.SizeMin;
                double t     = range > 0
                    ? Math.Max(0.0, (size - _profile.SizeMin) / range)
                    : 0.0;

                // Loss context modulates the signal within the range, but the hard cap
                // at t × D3WithinProfileCap is never exceeded.
                double lossCtx = Math.Min(1.0,
                    _cfg.D3DampenBase + _cfg.D3DampenRampPerLoss * _consecutiveLosses);

                double cap = t * _cfg.D3WithinProfileCap * lossCtx;
                raw = Math.Min(raw, cap);
            }

            // Profile-declaration floor: when the position explicitly exceeds
            // the trader's declared SizeMax, guarantee a minimum D3 score.
            if (size > _profile.SizeMax)
                raw = Math.Max(raw, _cfg.D3ProfileViolationFloor);

            return raw;
        }

        // ── D4: Hold-Time Collapse ────────────────────────────────────────────
        // Log-odds ratio of session-average holding times vs long-term means.
        // Signals when winners are closed too quickly and losers held too long.

        private double CalcD4()
        {
            double muWinHold  = Math.Max(_cfg.D4MinHoldGuardSec, _baseline.GetEffectiveMuWinHold(_profile));
            double muLossHold = Math.Max(_cfg.D4MinHoldGuardSec, _baseline.GetEffectiveMuLossHold(_profile));

            double sessWin  = Math.Max(0.0, _baseline.SessionAvgWinHold);
            double sessLoss = Math.Max(0.0, _baseline.SessionAvgLossHold);

            double ratioWin  = sessWin  / muWinHold;
            double ratioLoss = sessLoss / muLossHold;

            double logOdds = Math.Log((ratioLoss + _cfg.D4LogOddsEpsilon)
                                    / (ratioWin  + _cfg.D4LogOddsEpsilon));
            double d4Raw   = Clamp01(NormalCdf(logOdds - _cfg.ZThreshold));

            // Standard-error convergence: confidence = 1 - 1/sqrt(n).
            // At n=1, confidence=0; at n=4, 0.50; at n=16, 0.75; at n=100, 0.90.
            // This correctly reflects that 5 trades are NOT sufficient for a
            // stable mean estimate (the old linear ramp hit 1.0 at n=5).
            int    n          = _baseline.SessionTradeCount;
            double seRatio    = n > 0 ? 1.0 / Math.Sqrt(n) : 1.0;
            double confidence = Clamp01(1.0 - seRatio);

            return d4Raw * confidence;
        }

        // ── D5: Position Hold (扛单) Monitor ─────────────────────────────────
        // Timer-driven; detects holding a losing position beyond the trader's
        // personal historical 90th percentile.
        //
        // Aggregation across multiple simultaneous positions:
        //   Old approach: worst = max(d5_i) — ignored all but the worst position,
        //   so ES + NQ both overstaying was no worse than one.
        //   New approach: probability union = 1 - ∏(1 - d5_i) across DISTINCT
        //   instruments.  Within each instrument group, max is taken (handles
        //   Replikanto cross-account copies of the same trade without inflating).
        //
        // MAE (Maximum Adverse Excursion) memory:
        //   Old: if (UnrealizedPnl >= 0) skip — instantly forgave a position that
        //   recovered to breakeven after 3 hours underwater.
        //   New: effectiveLoss = min(currentPnl, MinUnrealizedPnl) — if the
        //   position was ever at -$500, D5 reflects that even if it's now +$1,
        //   until the position is actually closed.

        private double CalcD5(IEnumerable<PositionSnapshot> positions,
                              out bool nakedPositionDetected)
        {
            nakedPositionDetected = false;
            if (positions == null) return 0.0;

            // Naked-position check is disabled when:
            //   (a) user declared themselves a no-stop-loss trader, OR
            //   (b) NoStopGraceSeconds was explicitly set to 0.
            bool checkNaked = !_profile.NoStopLossTrader && _profile.NoStopGraceSeconds > 0;

            double muLoss = _baseline.GetEffectiveMuLoss();
            double p90    = _baseline.GetP90LossHold(_profile);

            // instrD5: best (highest) D5 per unique instrument.
            // Keyed by the instrument portion of the position key (after "::") so
            // that Replikanto cross-account copies of the same trade collapse into
            // one entry and are not double-counted in the union formula.
            var instrD5 = new Dictionary<string, double>();

            foreach (var pos in positions)
            {
                if (pos == null) continue;

                // ── Naked-position check ──────────────────────────────────────
                if (checkNaked &&
                    !pos.HasStopOrder &&
                    pos.HoldSeconds >= _profile.NoStopGraceSeconds)
                {
                    nakedPositionDetected = true;
                    return 1.0; // maximum D5; no need to evaluate other positions
                }

                // ── Extract instrument key for Replikanto dedup ───────────────
                string instrKey = pos.Key != null && pos.Key.Contains("::")
                    ? pos.Key.Substring(pos.Key.IndexOf("::") + 2)
                    : (pos.Key ?? string.Empty);

                // ── MAE: use worst-case PnL seen, not just current ────────────
                // MinUnrealizedPnl is always ≤ 0 (set in PositionSnapshot.Create).
                // If position was at -$500 but recovered to +$10, effectiveLoss = -500.
                // If position was always profitable, effectiveLoss = 0 → skip below.
                double effectiveLoss = Math.Min(pos.UnrealizedPnl, pos.MinUnrealizedPnl);

                if (effectiveLoss >= 0) continue; // never was in meaningful loss territory

                // Loss severity via z-score against the trader's loss baseline.
                double sigmaLoss    = _baseline.GetEffectiveSigmaLoss();
                double lossZ        = sigmaLoss > 0
                    ? (Math.Abs(effectiveLoss) - muLoss) / sigmaLoss : 0.0;
                double lossSeverity = Clamp01(NormalCdf(lossZ));
                double hold         = pos.HoldSeconds;

                double d5;
                if (hold < p90)
                {
                    d5 = lossSeverity * _cfg.D5BackgroundSignalFactor;
                }
                else
                {
                    double denom    = Math.Max(p90, _cfg.D5P90DenomFloorSec);
                    double overtime = (hold - p90) / denom;
                    d5 = Clamp01(Math.Min(_cfg.D5MaxCap,
                        NormalCdf(overtime - _cfg.ZThreshold) * lossSeverity));
                }

                // Keep highest d5 per instrument (collapses Replikanto copies).
                double current;
                if (!instrD5.TryGetValue(instrKey, out current) || d5 > current)
                    instrD5[instrKey] = d5;
            }

            if (instrD5.Count == 0) return 0.0;

            // Probability union across distinct instruments:
            //   P(at least one position is critically held) = 1 - ∏(1 - d5_i)
            // Rationale: holding ES + NQ simultaneously in loss is worse than
            // holding either alone.  A single position with d5=0.7 gives 0.7.
            // Two positions both at d5=0.7 give 1 - 0.3² = 0.91.
            double combined = 0.0;
            foreach (var kv in instrD5)
                combined = 1.0 - (1.0 - combined) * (1.0 - kv.Value);

            return Clamp01(combined);
        }

        // ── D6: Rule Compliance ───────────────────────────────────────────────
        // Checks up to three deterministic rules at each event.
        // Returns a fraction in {0, 0.25, 0.5, 0.75}.
        // Also produces a rarity-scaled hard deduction for time-window violations,
        // subject to a configurable cooldown (HardDeductionCooldownSec).

        private double CalcD6(DateTime eventTime, double slTicks, double size,
                               out double hardDeduction)
        {
            int violations = 0;
            hardDeduction  = 0.0;

            // Rule 1: Must trade within declared session window.
            TimeSpan tod     = eventTime.TimeOfDay;
            bool     outside = tod < _profile.SessionStart || tod > _profile.SessionEnd;

            if (outside)
            {
                violations++;

                double secSinceLast = _lastHardDeductionTime == DateTime.MinValue
                    ? double.MaxValue
                    : (eventTime - _lastHardDeductionTime).TotalSeconds;
                if (secSinceLast >= _cfg.HardDeductionCooldownSec)
                {
                    double freq   = _baseline.GetWindowViolationFrequency();
                    double rarity = Math.Max(0.1, 1.0 - freq);
                    hardDeduction          = _cfg.SessionWindowDeduction * rarity;
                    _lastHardDeductionTime = eventTime;
                }
            }

            if (slTicks > 0 && _profile.SlTicksMax > 0 &&
                slTicks > _profile.SlTicksMax * _cfg.D6SlViolationMultiplier)
                violations++;

            if (size > 0 && _profile.SizeMax > 0 &&
                size > _profile.SizeMax * _cfg.D6SizeViolationMultiplier)
                violations++;

            return violations / (double)_cfg.D6TotalRules;
        }

        // ── D7: Overtrading (过度交易) ────────────────────────────────────────
        // Measures intra-session entry-pace acceleration (Signal A) and deviation
        // from the trader's profile frequency baseline (Signal B).
        //
        // isEntry == true  → update the pace statistics and compute the score.
        // isEntry == false → return 0.0.
        //
        // IMPORTANT — Signal semantics:
        //   D7 is a POINT-IN-TIME EVENT signal, not a continuous state.  It is only
        //   meaningful at the moment of a new entry: "Is the trader entering too fast
        //   right now?"  Between entries there is no new pace information — the correct
        //   D7 raw value is 0, so the EWMA recovery branch fires and C7 decays.
        //   Returning the stale _d7 from the last entry would falsely continue to
        //   charge D7 debt during position holds and on exit fills (the Q4 / Q3b bug).
        //
        // Partial-fill deduplication: if a second fill arrives within
        // OversizeImpulseCooldownSec of the last recorded entry, it is silently
        // ignored (treated as part of the same order).
        private double CalcD7(DateTime fillTime, bool isEntry)
        {
            if (!isEntry)
                return 0.0;  // No new entry → no pace signal; EWMA recovery branch fires

            // ── Partial-fill deduplication ────────────────────────────────────
            double secSinceLast = _lastEntryFillTime == DateTime.MinValue
                ? double.MaxValue
                : (fillTime - _lastEntryFillTime).TotalSeconds;

            if (secSinceLast < _cfg.OversizeImpulseCooldownSec)
                return 0.0;  // Same order partial fill → first fill already charged EWMA; recovery branch here

            _lastEntryFillTime = fillTime;

            // ── Update session statistics ─────────────────────────────────────
            if (_sessionFirstEntryTime == DateTime.MinValue)
                _sessionFirstEntryTime = fillTime;

            _sessionEntryCount++;

            // Maintain the rolling window of most-recent N timestamps.
            _recentEntryTimes.Enqueue(fillTime);
            while (_recentEntryTimes.Count > _cfg.D7AccelWindowEntries + 1)
                _recentEntryTimes.Dequeue();

            double floor = _cfg.D7MinGapFloorSec;

            // ── Session average inter-entry gap ───────────────────────────────
            double sessionSpanSec = Math.Max(floor,
                (fillTime - _sessionFirstEntryTime).TotalSeconds);
            double sessionAvgGap  = Math.Max(floor,
                sessionSpanSec / Math.Max(1, _sessionEntryCount - 1));

            // ── Signal B: deviation from profile frequency baseline ───────────
            // LambdaVelocity is trades-per-hour declared in StrategyProfile.
            // Convert to seconds-per-trade as the "expected" inter-entry gap.
            //
            // Fires from entry 2 onward (need at least 1 gap for sessionAvgGap
            // to reflect actual pace; at n=1 the gap is the floor, not real data).
            // Confidence ramps from 0 at n=2 to 1.0 at n=D7AccelWindowEntries+1,
            // matching the natural data requirement of Signal A.
            double signalB = 0.0;
            if (_profile.LambdaVelocity > 0.0 && _sessionEntryCount >= 2)
            {
                double expectedGap = 3600.0 / _profile.LambdaVelocity;
                double profileZ    = -Math.Log(sessionAvgGap / Math.Max(floor, expectedGap))
                                     / _cfg.D7ProfileSigma;
                double rawB        = NormalCdf(profileZ - _cfg.ZThreshold);

                // Natural warm-up: full confidence at D7AccelWindowEntries+1 entries
                // (the same number Signal A requires to fill its ring buffer).
                int    minForFull = _cfg.D7AccelWindowEntries + 1;
                double conf       = Math.Min(1.0,
                    (double)(_sessionEntryCount - 2) / Math.Max(1, minForFull - 2));
                signalB = rawB * conf;
            }

            // ── Signal A: session-internal acceleration ───────────────────────
            // Requires at least D7AccelWindowEntries+1 timestamps in the ring buffer.
            double signalA = 0.0;
            if (_recentEntryTimes.Count >= _cfg.D7AccelWindowEntries + 1)
            {
                DateTime[] ts    = _recentEntryTimes.ToArray();
                int         n    = ts.Length;
                double      sumRecent = 0.0;
                int         countR    = 0;

                for (int i = n - _cfg.D7AccelWindowEntries; i < n; i++)
                {
                    sumRecent += Math.Max(floor, (ts[i] - ts[i-1]).TotalSeconds);
                    countR++;
                }

                double recentAvgGap = countR > 0 ? sumRecent / countR : sessionAvgGap;

                // Log-ratio: negative when recent pace is faster than session average.
                double accelZ  = -Math.Log(recentAvgGap / sessionAvgGap)
                                  / _cfg.D7AccelSigma;
                signalA = NormalCdf(accelZ - _cfg.ZThreshold);
            }

            return Math.Max(signalA, signalB);
        }

        // =====================================================================
        // Decomposed parallel EWMA
        //
        // Each of the seven behavioural dimensions maintains its own PSI-debt
        // component C_i (unit: PSI points).  The composite PSI is:
        //
        //     PSI  =  clamp( 100 − Σ C_i − carryDebt, 0, 100 )
        //
        // so the HUD bars are a mathematically exact decomposition of the PSI
        // value.  Boost and escalation are attributed to the dimension with the
        // highest instantaneous raw signal, ensuring every PSI point is
        // traceable to a specific behavioural cause.
        //
        // Hard deductions (naked position → D2, session-window → D6) are added
        // directly to the responsible C_i AFTER the EWMA step, bypassing the
        // per-event drop cap (same as original design) but NOW appearing on the
        // appropriate dimension bar rather than being invisible "ghost" penalties.
        // =====================================================================

        private double ApplyDecomposedEwma(DateTime eventTime,
                                           double d2HardDeduction = 0.0,
                                           double d6HardDeduction = 0.0,
                                           double oversizeMinAlpha = 0.0)
        {
            // ── Time-base sanity ─────────────────────────────────────────────
            double deltaSec;
            if (_lastEwmaUpdate == DateTime.MinValue)
            {
                deltaSec = 0.0;
            }
            else
            {
                double rawDelta = (eventTime - _lastEwmaUpdate).TotalSeconds;

                if (rawDelta < -_cfg.EwmaBackwardGuardSec || rawDelta > _cfg.EwmaForwardGuardSec)
                {
                    // Time-domain switch (wall ↔ playback) — skip this step,
                    // reset the anchor so the next event gets a clean delta.
                    _lastEwmaUpdate = eventTime;
                    return _psi;
                }

                deltaSec = Math.Max(_cfg.EwmaMinDeltaSec, rawDelta);
            }
            _lastEwmaUpdate = eventTime;

            // ── Effective recovery tau (overexposure state) ───────────────────
            double recoveryTau;
            if (_liveOverExposed)
                recoveryTau = _cfg.EwmaFrozenRecoveryTau;
            else if (_overExposureCooldownEnd != DateTime.MinValue &&
                     eventTime < _overExposureCooldownEnd)
                recoveryTau = _cfg.EwmaPostOverexposureTau;
            else
                recoveryTau = _cfg.EwmaNormalRecoveryTau;

            // ── Boost + escalation ────────────────────────────────────────────
            // Boost:      stateless — charged to the instantaneous highest dimension.
            //             Rationale: one extreme signal at this tick is alarming regardless
            //             of history; attributing it to the current worst dimension is correct.
            // Escalation: attributed to _sustainedViolationDimIdx — the dimension that
            //             built the streak — so the HUD bar that caused the spiral grows,
            //             not whichever happens to be highest at this exact tick.
            int    boostIdx        = MaxDimensionIndex();
            double maxDraw         = MaxDimension();
            double boostExtra      = _cfg.BoostFactor * maxDraw * maxDraw;
            double escalationExtra = 0.0;
            if (_sustainedViolationCount >= 2)
                escalationExtra = _cfg.EscalationPerFill *
                                  Math.Min(_sustainedViolationCount - 1,
                                           _cfg.MaxEscalationFills - 1);
            int escalationIdx = (_sustainedViolationDimIdx >= 0)
                ? _sustainedViolationDimIdx
                : boostIdx;  // fallback: if no tracked driver, use current max

            // ── Per-dimension EWMA update ─────────────────────────────────────
            double[] raws    = { _d1, _d2, _d3, _d4, _d5, _d6, _d7 };
            double[] weights =
            {
                _profile.WeightRevengeEntry,    _profile.WeightStopManipulation,
                _profile.WeightSizeOutlier,     _profile.WeightHoldTimeCollapse,
                _profile.WeightPositionHold,    _profile.WeightRuleCompliance,
                _profile.WeightOvertrading,
            };
            double[] cs = { _c1, _c2, _c3, _c4, _c5, _c6, _c7 };

            double prevPsi = _psi;

            for (int i = 0; i < 7; i++)
            {
                // Weighted target in PSI points.
                // Boost charged to instantaneous max; escalation charged to the
                // dimension that built the sustained-violation streak.
                double extra = 0.0;
                if (i == boostIdx)      extra += boostExtra      * 100.0;
                if (i == escalationIdx) extra += escalationExtra * 100.0;
                double target = weights[i] * raws[i] * 100.0 + extra;

                target = Math.Max(0.0, Math.Min(100.0, target));

                // Asymmetric tau: fast drop when worsening, slow recovery.
                double tau   = target > cs[i] ? _cfg.EwmaDropTau : recoveryTau;
                double alpha = 1.0 - Math.Exp(-deltaSec / tau);

                // Oversize impulse: only D3 receives the forced minimum alpha
                // so that scale-in fills reported at identical timestamps still
                // move the Size bar visibly.
                if (i == 2)
                    alpha = Math.Max(alpha, oversizeMinAlpha);

                cs[i] = alpha * target + (1.0 - alpha) * cs[i];
                cs[i] = Math.Max(0.0, cs[i]);
            }

            // ── Carry-forward decay ───────────────────────────────────────────
            // Uses recovery tau: dissolves at the same rate as calm trading
            // would heal a PSI deficit caused by the previous session.
            double carryAlpha = 1.0 - Math.Exp(-deltaSec / recoveryTau);
            _carryDebt = Math.Max(0.0, (1.0 - carryAlpha) * _carryDebt);

            // ── Per-event drop cap ────────────────────────────────────────────
            // Prevents a single EWMA step from crashing PSI more than maxDrop.
            // When triggered, all C_i are scaled proportionally so the identity
            // PSI = 100 − Σ C_i − carryDebt is preserved exactly.
            double totalDebt = cs[0]+cs[1]+cs[2]+cs[3]+cs[4]+cs[5]+cs[6] + _carryDebt;
            double rawNewPsi = Math.Max(0.0, Math.Min(100.0, 100.0 - totalDebt));
            double maxDrop   = _cfg.EwmaPerEventDropCap * (prevPsi / 100.0);

            if (rawNewPsi < prevPsi - maxDrop)
            {
                double cappedPsi  = prevPsi - maxDrop;
                double cappedDebt = Math.Max(0.0, 100.0 - cappedPsi - _carryDebt);
                double dimDebt    = totalDebt - _carryDebt;
                if (dimDebt > 0.0)
                {
                    double scale = cappedDebt / dimDebt;
                    for (int i = 0; i < 7; i++) cs[i] *= scale;
                }
                rawNewPsi = cappedPsi;
            }

            _c1=cs[0]; _c2=cs[1]; _c3=cs[2]; _c4=cs[3]; _c5=cs[4]; _c6=cs[5]; _c7=cs[6];

            // ── Hard deductions: instant additions to specific dimension debts ─
            // These bypass the drop cap (same behaviour as the original design)
            // and are attributed to their causal dimension so the bar display
            // immediately shows WHY PSI just dropped sharply.
            if (d2HardDeduction > 0.0)
                _c2 = Math.Min(100.0, _c2 + d2HardDeduction);  // Naked position → D2
            if (d6HardDeduction > 0.0)
                _c6 = Math.Min(100.0, _c6 + d6HardDeduction);  // Session window → D6

            // ── Final PSI from identity ───────────────────────────────────────
            double finalDebt = _c1+_c2+_c3+_c4+_c5+_c6+_c7 + _carryDebt;
            _psi = Math.Max(0.0, Math.Min(100.0, 100.0 - finalDebt));
            return _psi;
        }

        // =====================================================================
        // Composite penalty  (legacy — REPLACED by ApplyDecomposedEwma)
        // Kept as a private helper only during any future A/B comparison.
        // Currently unreferenced; the compiler will elide it.
        // =====================================================================

        private double CompositeRawPenalty()
        {
            double p = _profile.WeightRevengeEntry     * _d1
                     + _profile.WeightStopManipulation * _d2
                     + _profile.WeightSizeOutlier      * _d3
                     + _profile.WeightHoldTimeCollapse * _d4
                     + _profile.WeightPositionHold     * _d5
                     + _profile.WeightRuleCompliance   * _d6;

            double maxD = MaxDimension();
            p += _cfg.BoostFactor * maxD * maxD;

            if (_sustainedViolationCount >= 2)
                p += _cfg.EscalationPerFill *
                     Math.Min(_sustainedViolationCount - 1, _cfg.MaxEscalationFills - 1);

            return Clamp01(p);
        }

        // =====================================================================
        // Math helpers
        // =====================================================================

        private double MaxDimension() =>
            Math.Max(_d1, Math.Max(_d2, Math.Max(_d3,
                Math.Max(_d4, Math.Max(_d5, Math.Max(_d6, _d7))))));

        // Returns the 0-based index (0=D1 … 6=D7) of the dimension with the
        // highest instantaneous raw score.  Used to attribute boost and
        // escalation extra-penalty to the correct C_i.
        private int MaxDimensionIndex()
        {
            double max = _d1; int idx = 0;
            if (_d2 > max) { max = _d2; idx = 1; }
            if (_d3 > max) { max = _d3; idx = 2; }
            if (_d4 > max) { max = _d4; idx = 3; }
            if (_d5 > max) { max = _d5; idx = 4; }
            if (_d6 > max) { max = _d6; idx = 5; }
            if (_d7 > max) {             idx = 6; }
            return idx;
        }

        private static double Clamp01(double v)
        {
            if (double.IsNaN(v) || double.IsNegativeInfinity(v)) return 0.0;
            if (double.IsPositiveInfinity(v)) return 1.0;
            return v < 0.0 ? 0.0 : v > 1.0 ? 1.0 : v;
        }

        /// <summary>
        /// Standard normal CDF — Abramowitz &amp; Stegun approximation 26.2.17.
        /// Max absolute error 7.5e-8.  Same implementation used in Black-Scholes
        /// pricing engines across the financial industry.
        /// </summary>
        private static double NormalCdf(double x)
        {
            const double a1 =  0.254829592,  a2 = -0.284496736,
                         a3 =  1.421413741,  a4 = -1.453152027,
                         a5 =  1.061405429,  p  =  0.3275911;
            int sign = x < 0 ? -1 : 1;
            x = Math.Abs(x) / Math.Sqrt(2.0);
            double t = 1.0 / (1.0 + p * x);
            double y = 1.0 - (((((a5 * t + a4) * t + a3) * t + a2) * t + a1) * t
                       * Math.Exp(-x * x));
            return 0.5 * (1.0 + sign * y);
        }

        /// <summary>
        /// Inverse standard normal CDF — Peter Acklam's rational approximation.
        /// Max relative error &lt; 1.15e-9.
        /// Ref: Glasserman (2003), Monte Carlo Methods in Financial Engineering.
        /// </summary>
        internal static double NormalCdfInverse(double prob)
        {
            const double a1 = -3.969683028665376e+01, a2 =  2.209460984245205e+02,
                         a3 = -2.759285104469687e+02, a4 =  1.383577518672690e+02,
                         a5 = -3.066479806614716e+01, a6 =  2.506628277459239e+00;
            const double b1 = -5.447609879822406e+01, b2 =  1.615858368580409e+02,
                         b3 = -1.556989798598866e+02, b4 =  6.680131188771972e+01,
                         b5 = -1.328068155288572e+01;
            const double c1 = -7.784894002430293e-03, c2 = -3.223964580411365e-01,
                         c3 = -2.400758277161838e+00, c4 = -2.549732539343734e+00,
                         c5 =  4.374664141464968e+00, c6 =  2.938163982698783e+00;
            const double d1 =  7.784695709041462e-03, d2 =  3.224671290700398e-01,
                         d3 =  2.445134137142996e+00, d4 =  3.754408661907416e+00;

            const double pLow = 0.02425, pHigh = 1.0 - pLow;

            if (prob <= 0) return double.NegativeInfinity;
            if (prob >= 1) return double.PositiveInfinity;

            double q, r;
            if (prob < pLow)
            {
                q = Math.Sqrt(-2.0 * Math.Log(prob));
                return (((((c1 * q + c2) * q + c3) * q + c4) * q + c5) * q + c6)
                     / ((((d1 * q + d2) * q + d3) * q + d4) * q + 1.0);
            }
            if (prob <= pHigh)
            {
                q = prob - 0.5;
                r = q * q;
                return (((((a1 * r + a2) * r + a3) * r + a4) * r + a5) * r + a6) * q
                     / (((((b1 * r + b2) * r + b3) * r + b4) * r + b5) * r + 1.0);
            }
            q = Math.Sqrt(-2.0 * Math.Log(1.0 - prob));
            return -(((((c1 * q + c2) * q + c3) * q + c4) * q + c5) * q + c6)
                  / ((((d1 * q + d2) * q + d3) * q + d4) * q + 1.0);
        }
    }
}
