// HistoryWindow.cs
//
// "My History" analytics dashboard — 30-day PSI trend, calendar heatmap,
// key performance tiles, and a scrollable session log.
//
// Reads only from SessionHistoryStore (history.xml); never writes.
// Apple dark-mode style, consistent with SessionReportWindow.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;

namespace NinjaTrader.NinjaScript.AddOns
{
    internal sealed class HistoryWindow : Window
    {
        // ── Data ──────────────────────────────────────────────────────────────
        private readonly SessionHistoryStore        _store;
        private readonly List<SessionHistoryEntry>  _recent; // last 30 days, oldest→newest

        // ── Apple dark-mode palette (matches SessionReportWindow) ─────────────
        private static readonly Brush FgPrimary   = new SolidColorBrush(Color.FromRgb(245, 245, 247));
        private static readonly Brush FgSecondary = new SolidColorBrush(Color.FromRgb(174, 174, 178));
        private static readonly Brush FgHint      = new SolidColorBrush(Color.FromRgb( 99,  99, 102));
        private static readonly Brush FgAccent    = new SolidColorBrush(Color.FromRgb( 10, 132, 255));
        private static readonly Brush BgWindow    = new SolidColorBrush(Color.FromRgb( 28,  28,  30));
        private static readonly Brush BgCard      = new SolidColorBrush(Color.FromRgb( 38,  38,  40));
        private static readonly Brush BgHeader    = new SolidColorBrush(Color.FromRgb( 44,  44,  46));
        private static readonly Color ColStable   = Color.FromRgb( 48, 209,  88);
        private static readonly Color ColCaution  = Color.FromRgb(255, 214,   0);
        private static readonly Color ColCritical = Color.FromRgb(255,  69,  58);

        // ── Live chart canvas ─────────────────────────────────────────────────
        private Canvas _chartCanvas;

        // =====================================================================
        // Constructor
        // =====================================================================

        public HistoryWindow(SessionHistoryStore store)
        {
            _store  = store ?? new SessionHistoryStore();
            _recent = _store.Recent(30).ToList();

            // ── Window chrome ─────────────────────────────────────────────────
            WindowStyle        = WindowStyle.None;
            AllowsTransparency = true;
            Background         = Brushes.Transparent;
            ResizeMode         = ResizeMode.CanResizeWithGrip;
            ShowInTaskbar      = true;
            Title              = "PSI My History";
            Width              = 580;
            Height             = 760;
            MinWidth           = 440;
            MinHeight          = 560;
            Left = (SystemParameters.WorkArea.Width  - Width)  / 2;
            Top  = (SystemParameters.WorkArea.Height - Height) / 2;

            // ── Outer rounded card ────────────────────────────────────────────
            var card = new Border
            {
                CornerRadius    = new CornerRadius(14),
                Background      = BgWindow,
                BorderBrush     = new SolidColorBrush(Color.FromArgb(40, 255, 255, 255)),
                BorderThickness = new Thickness(1),
                ClipToBounds    = true,
            };

            var root = new Grid();
            root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(44) });
            root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });

            // ── Header bar ────────────────────────────────────────────────────
            var hdrBorder = new Border { Background = BgHeader };
            hdrBorder.MouseLeftButtonDown += (s, e) => DragMove();

            var hdrGrid = new Grid();
            hdrGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            hdrGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            hdrGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            var titleText = new TextBlock
            {
                Text              = "MY HISTORY  ·  LAST 30 DAYS",
                Foreground        = FgPrimary,
                FontSize          = 12,
                FontWeight        = FontWeights.SemiBold,
                VerticalAlignment = VerticalAlignment.Center,
                Margin            = new Thickness(16, 0, 0, 0),
            };
            Grid.SetColumn(titleText, 0);

            var copyBtn = MakeHeaderButton("⎘");
            copyBtn.ToolTip = "Copy 30-day summary to clipboard";
            copyBtn.Click  += (s, e) => CopySummary();
            Grid.SetColumn(copyBtn, 1);

            var closeBtn = MakeHeaderButton("✕");
            closeBtn.Click += (s, e) => Close();
            Grid.SetColumn(closeBtn, 2);

            hdrGrid.Children.Add(titleText);
            hdrGrid.Children.Add(copyBtn);
            hdrGrid.Children.Add(closeBtn);
            hdrBorder.Child = hdrGrid;
            Grid.SetRow(hdrBorder, 0);

            // ── Scrollable body ───────────────────────────────────────────────
            var scroll = new ScrollViewer
            {
                VerticalScrollBarVisibility   = ScrollBarVisibility.Auto,
                HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
            };
            var body = new StackPanel { Margin = new Thickness(14, 12, 14, 18) };
            scroll.Content = body;
            Grid.SetRow(scroll, 1);

            // ── Build sections ────────────────────────────────────────────────
            BuildStatTiles(body);
            body.Children.Add(Gap(16));
            BuildPsiTrendChart(body);
            body.Children.Add(Gap(16));
            BuildCalendarHeatmap(body);
            body.Children.Add(Gap(16));
            BuildSessionList(body);

            root.Children.Add(hdrBorder);
            root.Children.Add(scroll);
            card.Child = root;
            Content    = card;
        }

        // =====================================================================
        // Stat tiles
        // =====================================================================

        private void BuildStatTiles(Panel parent)
        {
            var grid = new Grid();
            for (int i = 0; i < 4; i++)
                grid.ColumnDefinitions.Add(
                    new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

            // Stable-day streak — neutral gray when no sessions yet (not alarming red)
            int    streak    = _store.CurrentStableStreak();
            Color  streakCol = streak >= 3 ? ColStable
                             : streak >= 1 ? ColCaution
                             : Color.FromRgb(120, 120, 128); // neutral — not "bad", just "no data"
            AddTile(grid, 0, "STREAK",
                    $"{streak}",
                    streakCol,
                    streak == 1 ? "day" : "days");

            // Stable sessions % — neutral gray when no history yet
            double? stabPct = _store.StableDaysPct(30);
            Color   stabCol = !stabPct.HasValue     ? Color.FromRgb(120, 120, 128)
                            : stabPct.Value >= 60   ? ColStable
                            : stabPct.Value >= 40   ? ColCaution : ColCritical;
            AddTile(grid, 1, "STABLE DAYS",
                    stabPct.HasValue ? $"{stabPct.Value:0}%" : "–",
                    stabCol, "of sessions");

            // Avg Composure — neutral gray when no trading data yet; never shows 100% on no data
            var    tradingDays = _recent.Where(e => e.TotalTrades > 0).ToList();
            string compStr = tradingDays.Count > 0
                ? $"{(int)tradingDays.Average(e => e.ComposurePct)}%"
                : "–";
            Color compCol = tradingDays.Count > 0
                ? ((int)tradingDays.Average(e => e.ComposurePct) >= 70 ? ColStable : ColCaution)
                : Color.FromRgb(120, 120, 128);
            AddTile(grid, 2, "COMPOSURE", compStr, compCol, "composure score");

            // Average net P&L
            double? avgPnl = _store.AvgPnl(30);
            Color   pnlCol = !avgPnl.HasValue ? Color.FromRgb(120, 120, 128)
                           : avgPnl.Value >= 0 ? ColStable : ColCritical;
            string  pnlStr = !avgPnl.HasValue ? "–"
                           : (avgPnl.Value >= 0 ? "+" : "-") + "$" + Math.Abs(avgPnl.Value).ToString("0");
            AddTile(grid, 3, "AVG P&L", pnlStr, pnlCol, "per session");

            parent.Children.Add(grid);
        }

        private static void AddTile(Grid grid, int col,
                                    string label, string value, Color valueColor, string sub)
        {
            var card = new Border
            {
                Background   = new SolidColorBrush(Color.FromRgb(38, 38, 40)),
                CornerRadius = new CornerRadius(10),
                Margin       = new Thickness(col == 0 ? 0 : 4, 0, 0, 0),
                Padding      = new Thickness(8, 10, 8, 10),
            };
            var sp = new StackPanel { HorizontalAlignment = HorizontalAlignment.Center };
            sp.Children.Add(new TextBlock
            {
                Text                = label,
                Foreground          = new SolidColorBrush(Color.FromRgb(99, 99, 102)),
                FontSize            = 8.5,
                FontWeight          = FontWeights.SemiBold,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin              = new Thickness(0, 0, 0, 4),
            });
            sp.Children.Add(new TextBlock
            {
                Text                = value,
                Foreground          = new SolidColorBrush(valueColor),
                FontSize            = 20,
                FontWeight          = FontWeights.Bold,
                HorizontalAlignment = HorizontalAlignment.Center,
            });
            sp.Children.Add(new TextBlock
            {
                Text                = sub,
                Foreground          = new SolidColorBrush(Color.FromRgb(99, 99, 102)),
                FontSize            = 8.5,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin              = new Thickness(0, 2, 0, 0),
            });
            card.Child = sp;
            Grid.SetColumn(card, col);
            grid.Children.Add(card);
        }

        // =====================================================================
        // PSI trend chart
        // =====================================================================

        private void BuildPsiTrendChart(Panel parent)
        {
            parent.Children.Add(SectionLabel("PSI TREND  ·  FINAL SCORE PER SESSION"));

            var card = new Border
            {
                Background   = BgCard,
                CornerRadius = new CornerRadius(10),
                Padding      = new Thickness(12, 10, 12, 6),
            };

            if (_recent.Count == 0)
            {
                card.Child = Placeholder("No sessions recorded yet. Start trading to populate your chart.");
                parent.Children.Add(card);
                return;
            }

            // Container: chart area on top, date labels below
            var outer = new Grid();
            outer.RowDefinitions.Add(new RowDefinition { Height = new GridLength(150) });
            outer.RowDefinitions.Add(new RowDefinition { Height = new GridLength(18) });

            _chartCanvas = new Canvas { Height = 150, ClipToBounds = true };
            _chartCanvas.SizeChanged += (s, e) => DrawPsiChart(_chartCanvas, e.NewSize.Width);
            Grid.SetRow(_chartCanvas, 0);

            // X-axis labels canvas (shares same width computation)
            var xLabels = new Canvas { Height = 18 };
            _chartCanvas.Tag = xLabels; // cross-reference for label drawing
            Grid.SetRow(xLabels, 1);

            outer.Children.Add(_chartCanvas);
            outer.Children.Add(xLabels);
            card.Child = outer;
            parent.Children.Add(card);
        }

        private void DrawPsiChart(Canvas canvas, double w)
        {
            canvas.Children.Clear();

            double h   = canvas.ActualHeight;
            if (w < 10 || h < 10) return;

            // Y: PSI 0-100 mapped to canvas height with 6px top/bottom padding
            const double padTop = 6, padBot = 6;
            double plotH = h - padTop - padBot;
            double yOf(double psi) => padTop + (1.0 - psi / 100.0) * plotH;

            // X: distribute entries evenly with 12px left margin (for Y labels)
            const double padLeft = 22, padRight = 4;
            double plotW = w - padLeft - padRight;
            int    n     = _recent.Count;
            double xOf(int i) => padLeft + (n == 1 ? plotW / 2.0 : i * plotW / (n - 1.0));

            // ── Zone background bands ─────────────────────────────────────────
            double zCrit = SessionData.ZoneCriticalThreshold; // 55
            double zStab = SessionData.ZoneStableThreshold;   // 88
            var critBand = new Rectangle
            {
                Width  = plotW,
                Height = yOf(0) - yOf(zCrit),
                Fill   = new SolidColorBrush(Color.FromArgb(15, 255, 69, 58)),
            };
            Canvas.SetLeft(critBand, padLeft);
            Canvas.SetTop(critBand,  yOf(zCrit));
            canvas.Children.Add(critBand);

            var cautBand = new Rectangle
            {
                Width  = plotW,
                Height = yOf(zCrit) - yOf(zStab),
                Fill   = new SolidColorBrush(Color.FromArgb(15, 255, 214, 0)),
            };
            Canvas.SetLeft(cautBand, padLeft);
            Canvas.SetTop(cautBand,  yOf(zStab));
            canvas.Children.Add(cautBand);

            // ── Horizontal grid lines at zone thresholds ──────────────────────
            foreach (double psi in new[] { zCrit, zStab })
            {
                double y = yOf(psi);
                canvas.Children.Add(new Line
                {
                    X1 = padLeft, Y1 = y, X2 = padLeft + plotW, Y2 = y,
                    Stroke          = new SolidColorBrush(Color.FromArgb(35, 255, 255, 255)),
                    StrokeThickness = 1,
                    StrokeDashArray = new DoubleCollection(new[] { 3.0, 4.0 }),
                });
                var yLbl = new TextBlock
                {
                    Text       = ((int)psi).ToString(),
                    Foreground = new SolidColorBrush(Color.FromRgb(99, 99, 102)),
                    FontSize   = 9,
                };
                Canvas.SetLeft(yLbl, 0);
                Canvas.SetTop(yLbl, y - 6);
                canvas.Children.Add(yLbl);
            }

            // ── Build point list ──────────────────────────────────────────────
            var pts = new Point[n];
            for (int i = 0; i < n; i++)
                pts[i] = new Point(xOf(i), yOf(_recent[i].FinalPsi));

            // ── Filled area under the line (gradient) ─────────────────────────
            var areaPts = new PointCollection(n + 2);
            foreach (var p in pts) areaPts.Add(p);
            areaPts.Add(new Point(pts[n - 1].X, h));
            areaPts.Add(new Point(pts[0].X, h));
            canvas.Children.Add(new Polygon
            {
                Points = areaPts,
                Fill   = new LinearGradientBrush(
                    Color.FromArgb(55, 10, 132, 255),
                    Color.FromArgb(0,  10, 132, 255),
                    new Point(0, 0), new Point(0, 1)),
            });

            // ── Line ─────────────────────────────────────────────────────────
            var polyPts = new PointCollection(pts);
            canvas.Children.Add(new Polyline
            {
                Points          = polyPts,
                Stroke          = FgAccent,
                StrokeThickness = 2,
                StrokeLineJoin  = PenLineJoin.Round,
            });

            // ── Data point dots ───────────────────────────────────────────────
            for (int i = 0; i < n; i++)
            {
                var e   = _recent[i];
                var dot = new Ellipse
                {
                    Width  = 7, Height = 7,
                    Fill   = new SolidColorBrush(ZoneColor(e.FinalZone)),
                    Stroke = BgCard, StrokeThickness = 1.5,
                    ToolTip = BuildDotTooltip(e),
                };
                Canvas.SetLeft(dot, pts[i].X - 3.5);
                Canvas.SetTop(dot,  pts[i].Y - 3.5);
                canvas.Children.Add(dot);
            }

            // ── X-axis date labels (in the sibling canvas stored in Tag) ──────
            if (!(canvas.Tag is Canvas xCanvas)) return;
            xCanvas.Children.Clear();
            // Show at most 8 labels so they never overlap
            int step = Math.Max(1, (int)Math.Ceiling(n / 8.0));
            for (int i = 0; i < n; i += step)
            {
                var lbl = new TextBlock
                {
                    Text       = _recent[i].Date.ToString("M/d"),
                    Foreground = new SolidColorBrush(Color.FromRgb(99, 99, 102)),
                    FontSize   = 9,
                };
                Canvas.SetLeft(lbl, xOf(i) - 10);
                Canvas.SetTop(lbl,  1);
                xCanvas.Children.Add(lbl);
            }
        }

        private static string BuildDotTooltip(SessionHistoryEntry e)
        {
            string pnl = (e.TotalPnl >= 0 ? "+" : "") + "$" + Math.Abs(e.TotalPnl).ToString("0");
            return $"{e.Date:MMM d, yyyy}\n" +
                   $"Final PSI: {e.FinalPsi:0}  ({e.FinalZone})\n" +
                   $"Trades: {e.TotalTrades}  Win%: {e.WinPct:0}%\n" +
                   $"P&L: {pnl}  COMP: {e.ComposurePct}%";
        }

        // =====================================================================
        // Calendar heatmap
        // =====================================================================

        private void BuildCalendarHeatmap(Panel parent)
        {
            parent.Children.Add(SectionLabel("CALENDAR  ·  LAST 5 WEEKS"));

            var card = new Border
            {
                Background   = BgCard,
                CornerRadius = new CornerRadius(10),
                Padding      = new Thickness(10, 8, 10, 8),
            };

            var byDate = _recent.ToDictionary(e => e.Date.Date);

            // Find the Monday that starts the 5-week window
            DateTime today     = DateTime.Today;
            DateTime anchor    = today.AddDays(-28);
            int      dow       = ((int)anchor.DayOfWeek + 6) % 7; // Mon=0, Sun=6
            DateTime gridStart = anchor.AddDays(-dow);

            // Build a 7-column grid: row 0 = day-name headers, rows 1-5 = weeks
            var calGrid = new Grid();
            for (int c = 0; c < 7; c++)
                calGrid.ColumnDefinitions.Add(
                    new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            calGrid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto }); // header
            for (int r = 0; r < 5; r++)
                calGrid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(32) });

            // Day-name headers
            string[] dayNames = { "Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun" };
            for (int c = 0; c < 7; c++)
            {
                var lbl = new TextBlock
                {
                    Text                = dayNames[c],
                    Foreground          = FgHint,
                    FontSize            = 9,
                    HorizontalAlignment = HorizontalAlignment.Center,
                    Margin              = new Thickness(0, 0, 0, 4),
                };
                Grid.SetRow(lbl, 0);
                Grid.SetColumn(lbl, c);
                calGrid.Children.Add(lbl);
            }

            // Day cells (35 = 5 weeks × 7 days)
            for (int i = 0; i < 35; i++)
            {
                DateTime cellDate = gridStart.AddDays(i);
                int row = i / 7 + 1;
                int col = i % 7;

                // Cells in the future: empty placeholder
                if (cellDate > today)
                {
                    var empty = new Border { Margin = new Thickness(2) };
                    Grid.SetRow(empty, row);
                    Grid.SetColumn(empty, col);
                    calGrid.Children.Add(empty);
                    continue;
                }

                SessionHistoryEntry entry;
                byDate.TryGetValue(cellDate.Date, out entry);

                Color  cellColor;
                string tooltip;

                if (entry == null || entry.TotalTrades == 0)
                {
                    // No session or monitoring-only day
                    bool isWeekend = cellDate.DayOfWeek == DayOfWeek.Saturday ||
                                     cellDate.DayOfWeek == DayOfWeek.Sunday;
                    byte alpha = isWeekend ? (byte)15 : (byte)35;
                    cellColor = Color.FromArgb(alpha, 255, 255, 255);
                    tooltip   = entry == null
                        ? $"{cellDate:MMM d}  —  No data recorded"
                        : $"{cellDate:MMM d}  —  Monitored (no trades)";
                }
                else
                {
                    Color zc = ZoneColor(entry.FinalZone);
                    cellColor = Color.FromArgb(185, zc.R, zc.G, zc.B);
                    string pnl = (entry.TotalPnl >= 0 ? "+" : "-") + "$" +
                                 Math.Abs(entry.TotalPnl).ToString("0");
                    tooltip = $"{cellDate:ddd MMM d}\n" +
                              $"Final PSI: {entry.FinalPsi:0}  ({entry.FinalZone})\n" +
                              $"Trades: {entry.TotalTrades}  P&L: {pnl}\n" +
                              $"COMP: {entry.ComposurePct}%  Win%: {entry.WinPct:0}%";
                }

                // Is today highlighted specially
                bool isToday = cellDate.Date == today.Date;

                var cell = new Border
                {
                    Background      = new SolidColorBrush(cellColor),
                    CornerRadius    = new CornerRadius(4),
                    Margin          = new Thickness(2),
                    BorderBrush     = isToday
                        ? new SolidColorBrush(Color.FromArgb(200, 10, 132, 255))
                        : Brushes.Transparent,
                    BorderThickness = new Thickness(isToday ? 1.5 : 0),
                    ToolTip         = tooltip,
                };
                cell.Child = new TextBlock
                {
                    Text                = cellDate.Day.ToString(),
                    Foreground          = new SolidColorBrush(Color.FromArgb(140, 245, 245, 247)),
                    FontSize            = 9,
                    HorizontalAlignment = HorizontalAlignment.Center,
                    VerticalAlignment   = VerticalAlignment.Center,
                };
                Grid.SetRow(cell, row);
                Grid.SetColumn(cell, col);
                calGrid.Children.Add(cell);
            }

            card.Child = calGrid;
            parent.Children.Add(card);
        }

        // =====================================================================
        // Session log table
        // =====================================================================

        private void BuildSessionList(Panel parent)
        {
            parent.Children.Add(SectionLabel("SESSION LOG"));

            var card = new Border
            {
                Background   = BgCard,
                CornerRadius = new CornerRadius(10),
                Padding      = new Thickness(0, 4, 0, 4),
            };

            if (_recent.Count == 0)
            {
                card.Child = new Border
                {
                    Padding = new Thickness(12, 10, 12, 10),
                    Child   = Placeholder("No sessions yet. Complete your first traded session to see history."),
                };
                parent.Children.Add(card);
                return;
            }

            var listStack = new StackPanel();
            listStack.Children.Add(SessionTableHeader());

            bool alt = false;
            foreach (var e in _recent.OrderByDescending(x => x.Date))
            {
                listStack.Children.Add(SessionTableRow(e, alt));
                alt = !alt;
            }

            card.Child = listStack;
            parent.Children.Add(card);
        }

        private static UIElement SessionTableHeader()
        {
            var g = new Grid { Margin = new Thickness(12, 2, 12, 5) };
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(54) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(46) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(66) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(36) });

            string[] heads = { "DATE", "PSI", "TRADES", "P&L", "COMP" };
            for (int i = 0; i < heads.Length; i++)
            {
                var tb = new TextBlock
                {
                    Text       = heads[i],
                    Foreground = FgHint,
                    FontSize   = 9,
                    FontWeight = FontWeights.SemiBold,
                    VerticalAlignment = VerticalAlignment.Center,
                    HorizontalAlignment = i > 1 ? HorizontalAlignment.Right : HorizontalAlignment.Left,
                };
                Grid.SetColumn(tb, i);
                g.Children.Add(tb);
            }
            return g;
        }

        private static UIElement SessionTableRow(SessionHistoryEntry e, bool alt)
        {
            var row = new Border
            {
                Background = new SolidColorBrush(alt
                    ? Color.FromArgb(12, 255, 255, 255)
                    : Color.FromArgb(0,  255, 255, 255)),
                Padding = new Thickness(12, 5, 12, 5),
                ToolTip = BuildRowTooltip(e),
            };

            var g = new Grid();
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(54) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(46) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(66) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(36) });

            // Date
            Add(g, 0, new TextBlock
            {
                Text = e.Date.ToString("MMM d"),
                Foreground = FgSecondary, FontSize = 11,
                VerticalAlignment = VerticalAlignment.Center,
            });

            // PSI mini-bar + value
            var psiWrap = new Grid();
            psiWrap.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(26) });
            psiWrap.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

            Grid.SetColumn(new TextBlock(), 0); // placeholder — added below
            var psiNumTb = new TextBlock
            {
                Text              = e.FinalPsi.ToString("0"),
                Foreground        = new SolidColorBrush(ZoneColor(e.FinalZone)),
                FontSize          = 11, FontWeight = FontWeights.SemiBold,
                VerticalAlignment = VerticalAlignment.Center,
            };
            Grid.SetColumn(psiNumTb, 0);
            psiWrap.Children.Add(psiNumTb);

            // Proportional mini-bar via two-column Grid
            var barGrid = new Grid { Height = 4, VerticalAlignment = VerticalAlignment.Center };
            double fillPct  = Math.Max(0.0, Math.Min(100.0, e.FinalPsi));
            double emptyPct = 100.0 - fillPct;
            barGrid.ColumnDefinitions.Add(new ColumnDefinition
                { Width = new GridLength(fillPct, GridUnitType.Star) });
            barGrid.ColumnDefinitions.Add(new ColumnDefinition
                { Width = new GridLength(emptyPct, GridUnitType.Star) });
            var fillRect  = new Border { Background = new SolidColorBrush(ZoneColor(e.FinalZone)), CornerRadius = new CornerRadius(2) };
            var emptyRect = new Border { Background = new SolidColorBrush(Color.FromArgb(35, 255, 255, 255)), CornerRadius = new CornerRadius(2) };
            Grid.SetColumn(fillRect,  0);
            Grid.SetColumn(emptyRect, 1);
            barGrid.Children.Add(fillRect);
            barGrid.Children.Add(emptyRect);
            Grid.SetColumn(barGrid, 1);
            psiWrap.Children.Add(barGrid);

            Add(g, 1, psiWrap);

            // Trades
            Add(g, 2, new TextBlock
            {
                Text = e.TotalTrades.ToString(),
                Foreground = FgSecondary, FontSize = 11,
                HorizontalAlignment = HorizontalAlignment.Right,
                VerticalAlignment   = VerticalAlignment.Center,
            });

            // P&L
            bool pos = e.TotalPnl >= 0;
            Add(g, 3, new TextBlock
            {
                Text       = (pos ? "+" : "-") + "$" + Math.Abs(e.TotalPnl).ToString("0"),
                Foreground = new SolidColorBrush(pos ? ColStable : ColCritical),
                FontSize   = 11, FontWeight = FontWeights.SemiBold,
                HorizontalAlignment = HorizontalAlignment.Right,
                VerticalAlignment   = VerticalAlignment.Center,
            });

            // Composure score
            Color compC = e.ComposurePct >= 70 ? ColStable
                        : e.ComposurePct >= 40 ? ColCaution : ColCritical;
            Add(g, 4, new TextBlock
            {
                Text       = e.ComposurePct + "%",
                Foreground = new SolidColorBrush(compC),
                FontSize   = 11,
                HorizontalAlignment = HorizontalAlignment.Right,
                VerticalAlignment   = VerticalAlignment.Center,
            });

            row.Child = g;
            return row;
        }

        private static string BuildRowTooltip(SessionHistoryEntry e)
        {
            var sb = new StringBuilder();
            sb.AppendLine($"{e.Date:dddd, MMMM d, yyyy}");
            sb.AppendLine($"PSI: {e.StartPsi:0} → {e.FinalPsi:0}   min {e.MinPsi:0}   avg {e.AvgPsi:0}");
            sb.AppendLine($"Trades: {e.TotalTrades}   Wins: {e.WinTrades}   Win%: {e.WinPct:0}%");
            string pnl = (e.TotalPnl >= 0 ? "+" : "-") + "$" + Math.Abs(e.TotalPnl).ToString("0.00");
            sb.AppendLine($"P&L: {pnl}   COMP: {e.ComposurePct}%");
            if (e.DurationMinutes > 0)
            {
                sb.AppendLine($"Duration: {e.DurationMinutes} min" +
                              $"   Stable: {e.TimeInStableMin:0}m" +
                              $"   Caution: {e.TimeInCautionMin:0}m" +
                              $"   Critical: {e.TimeInCriticalMin:0}m");
            }
            if (e.TopDimensionIndex >= 0)
                sb.AppendLine($"Dominant signal: {e.TopDimensionLabel}");
            if (e.NakedPositionDetections > 0)
                sb.AppendLine($"⚠ Naked position alerts: {e.NakedPositionDetections}×");
            return sb.ToString().TrimEnd();
        }

        // =====================================================================
        // Copy-to-clipboard summary
        // =====================================================================

        private void CopySummary()
        {
            var sb = new StringBuilder();
            sb.AppendLine("📊 MY 30-DAY PSI SUMMARY");
            sb.AppendLine("────────────────────────────");

            double? stabPct = _store.StableDaysPct(30);
            int     streak  = _store.CurrentStableStreak();
            double? avgPnl  = _store.AvgPnl(30);
            var     days    = _recent.Where(e => e.TotalTrades > 0).ToList();
            double? avgBq   = days.Count > 0 ? (double?)days.Average(e => e.ComposurePct) : null;

            sb.AppendLine($"🏆 Stable streak:    {streak} day{(streak != 1 ? "s" : "")}");
            sb.AppendLine($"🟢 Stable sessions:  {(stabPct.HasValue ? $"{stabPct.Value:0}%" : "–")} of last 30 days");
            sb.AppendLine($"💰 Avg P&L:          {(avgPnl.HasValue ? (avgPnl.Value >= 0 ? "+" : "-") + "$" + Math.Abs(avgPnl.Value).ToString("0") : "–")} / session");
            sb.AppendLine($"🧠 Avg composure:    {(avgBq.HasValue ? $"{avgBq.Value:0}%" : "–")}");
            sb.AppendLine();
            sb.AppendLine("RECENT SESSIONS");

            foreach (var e in _recent.OrderByDescending(x => x.Date).Take(7))
            {
                string z   = e.FinalZone == PsiZone.Stable ? "🟢" : e.FinalZone == PsiZone.Caution ? "🟡" : "🔴";
                string pnl = (e.TotalPnl >= 0 ? "+" : "-") + "$" + Math.Abs(e.TotalPnl).ToString("0");
                sb.AppendLine($"  {z} {e.Date:MMM d}  PSI {e.FinalPsi:0}  {pnl}  COMP {e.ComposurePct}%");
            }

            sb.AppendLine();
            sb.AppendLine("Monitored by PSI TradeMonitor");

            try { System.Windows.Clipboard.SetText(sb.ToString()); }
            catch { /* clipboard failure is non-critical */ }
        }

        // =====================================================================
        // Helpers
        // =====================================================================

        private static Color ZoneColor(PsiZone z) =>
            z == PsiZone.Stable  ? ColStable  :
            z == PsiZone.Caution ? ColCaution : ColCritical;

        private static void Add(Grid g, int col, UIElement el)
        {
            Grid.SetColumn(el, col);
            g.Children.Add(el);
        }

        private static TextBlock SectionLabel(string text) =>
            new TextBlock
            {
                Text       = text,
                Foreground = FgHint,
                FontSize   = 9,
                FontWeight = FontWeights.SemiBold,
                Margin     = new Thickness(2, 0, 0, 6),
            };

        private static Border Gap(double height) => new Border { Height = height };

        private static TextBlock Placeholder(string msg) =>
            new TextBlock
            {
                Text                = msg,
                Foreground          = FgHint,
                FontSize            = 11,
                FontStyle           = FontStyles.Italic,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin              = new Thickness(0, 12, 0, 12),
            };

        private static Button MakeHeaderButton(string glyph) =>
            new Button
            {
                Content                    = glyph,
                Width                      = 36,
                Foreground                 = FgSecondary,
                Background                 = Brushes.Transparent,
                BorderThickness            = new Thickness(0),
                FontSize                   = 13,
                Cursor                     = Cursors.Hand,
                VerticalContentAlignment   = VerticalAlignment.Center,
                HorizontalContentAlignment = HorizontalAlignment.Center,
            };
    }
}
