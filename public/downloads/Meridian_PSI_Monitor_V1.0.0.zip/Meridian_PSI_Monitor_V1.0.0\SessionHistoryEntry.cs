// SessionHistoryEntry.cs
//
// Per-session summary snapshot persisted to disk for the "My History" feature.
// Each session archives one entry the moment the next session begins (or when
// NinjaTrader shuts down).  The data is intentionally compact: each entry is
// ~500 bytes of XML, so 365 entries (1 year) occupy roughly 180 KB.
//
// Two classes are co-located here because neither has any NinjaTrader API
// dependencies — they can be unit-tested in isolation.
//
//   SessionHistoryEntry — one row per trading session
//   SessionHistoryStore — load / save / query the rolling history file

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml.Serialization;

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================================
    // SessionHistoryEntry
    // =========================================================================

    /// <summary>
    /// Compact, immutable summary of a single trading session.
    ///
    /// All fields are public-settable (required by <see cref="XmlSerializer"/>)
    /// but must be treated as write-once: set during construction, read
    /// afterwards.  Computed properties are <c>[XmlIgnore]</c> and derive from
    /// the stored values.
    /// </summary>
    public sealed class SessionHistoryEntry
    {
        // ── Identity ──────────────────────────────────────────────────────────

        /// <summary>Calendar date this session belongs to (date portion only).</summary>
        [XmlElement] public DateTime Date { get; set; }

        // ── PSI metrics ───────────────────────────────────────────────────────

        /// <summary>PSI at the start of the first recorded fill (carries in from prior session).</summary>
        [XmlElement] public double StartPsi  { get; set; }

        /// <summary>Lowest PSI recorded during active session time.</summary>
        [XmlElement] public double MinPsi    { get; set; }

        /// <summary>PSI at the end of the session (when the next session triggered).</summary>
        [XmlElement] public double FinalPsi  { get; set; }

        /// <summary>Average PSI over all recorded snapshots (proxy for session stability).</summary>
        [XmlElement] public double AvgPsi    { get; set; }

        // ── Trade performance ─────────────────────────────────────────────────

        /// <summary>Number of closed trade fills (entries + partial adds are not counted).</summary>
        [XmlElement] public int    TotalTrades { get; set; }

        /// <summary>Subset of <see cref="TotalTrades"/> that were profitable.</summary>
        [XmlElement] public int    WinTrades   { get; set; }

        /// <summary>Net realized P&amp;L across all closing fills.</summary>
        [XmlElement] public double TotalPnl    { get; set; }

        // ── Session duration ──────────────────────────────────────────────────

        /// <summary>
        /// Active trading window in minutes: time from the first PSI snapshot to
        /// the last.  Pre-market monitoring time is excluded.
        /// </summary>
        [XmlElement] public int DurationMinutes { get; set; }

        // ── Time-in-zone (minutes) ────────────────────────────────────────────

        [XmlElement] public double TimeInStableMin   { get; set; }
        [XmlElement] public double TimeInCautionMin  { get; set; }
        [XmlElement] public double TimeInCriticalMin { get; set; }

        // ── Alerts & risk ─────────────────────────────────────────────────────

        /// <summary>Total compliance alerts fired (PSI-zone + naked-position).</summary>
        [XmlElement] public int AlertsFired             { get; set; }

        /// <summary>
        /// Number of 30-second polling cycles that detected an open position
        /// without a stop-loss order.  Multiply by ~0.5 min for approximate
        /// naked-exposure time.
        /// </summary>
        [XmlElement] public int NakedPositionDetections { get; set; }

        // ── Composure score ───────────────────────────────────────────────────

        /// <summary>
        /// 0–100 composite composure score for the session.
        /// Blends three equal-weight components:
        ///   1. Trade composure  — % of closing trades with MaxD &lt; 0.30 (covers D1,D3,D4,D6,D7)
        ///   2. Hold quality     — (1 − peakDebtD5/100): penalises sessions with sustained overstay
        ///   3. SL integrity     — (1 − peakDebtD2/100): penalises sessions with sustained stop manipulation
        /// Equal weighting reflects that decision quality, hold discipline, and stop discipline
        /// are independently necessary for full psychological composure.
        /// XML element name kept as "BehavioralQualityPct" for backward compatibility with existing history files.
        /// </summary>
        [XmlElement("BehavioralQualityPct")] public int ComposurePct { get; set; }

        // ── Dimension cumulative scores ───────────────────────────────────────

        /// <summary>
        /// Sum of each D-score across all fills this session.  Used to identify
        /// which behavioral dimension dominated.
        ///
        /// D1 = Revenge trading   D4 = Concentration risk
        /// D2 = Stop manipulation D5 = Excessive hold time
        /// D3 = Oversizing        D6 = Rule compliance
        /// D7 = Overtrading pace
        /// </summary>
        [XmlElement] public double D1 { get; set; }
        [XmlElement] public double D2 { get; set; }
        [XmlElement] public double D3 { get; set; }
        [XmlElement] public double D4 { get; set; }
        [XmlElement] public double D5 { get; set; }
        [XmlElement] public double D6 { get; set; }
        [XmlElement] public double D7 { get; set; }

        // ── Computed convenience properties (not persisted) ───────────────────

        [XmlIgnore] public int    LossTrades => TotalTrades - WinTrades;
        [XmlIgnore] public double WinPct     => TotalTrades > 0 ? 100.0 * WinTrades / TotalTrades : 0;

        [XmlIgnore] public PsiZone FinalZone =>
            FinalPsi >= 88 ? PsiZone.Stable :
            FinalPsi >= 55 ? PsiZone.Caution : PsiZone.Critical;

        /// <summary>
        /// Index (0–5) of the most-impactful D-dimension this session,
        /// or -1 if every D-score was 0.
        /// </summary>
        [XmlIgnore]
        public int TopDimensionIndex
        {
            get
            {
                double[] scores = { D1, D2, D3, D4, D5, D6, D7 };
                double   max    = scores.Max();
                return max > 0.0 ? Array.IndexOf(scores, max) : -1;
            }
        }

        /// <summary>Percentage of active session time spent in the Stable zone.</summary>
        [XmlIgnore]
        public double StablePct =>
            DurationMinutes > 0 ? TimeInStableMin / DurationMinutes * 100.0 : 0;

        /// <summary>Formatted label matching the top D-dimension (e.g. "D3 Oversizing").</summary>
        private static readonly string[] DimLabels =
        {
            "D1 Revenge", "D2 Stop Manip.", "D3 Oversize",
            "D4 Hold Bias", "D5 Overstay", "D6 Rules", "D7 Overtrading"
        };

        [XmlIgnore]
        public string TopDimensionLabel =>
            TopDimensionIndex >= 0 ? DimLabels[TopDimensionIndex] : "None";
    }

    // =========================================================================
    // SessionHistoryStore
    // =========================================================================

    /// <summary>
    /// Ordered, self-persisting collection of <see cref="SessionHistoryEntry"/>
    /// records.  Stores up to <see cref="MaxEntries"/> days in a rolling window.
    ///
    /// <para>
    /// File location:
    ///   <c>Documents\NinjaTrader 8\bin\Custom\AddOns\TradeMonitorData\history.xml</c>
    /// </para>
    ///
    /// <para>
    /// Persistence strategy: atomic write via temp-file → rename, so a crash
    /// during save cannot corrupt the existing file.  A backup of corrupt files
    /// is created before discarding them.
    /// </para>
    /// </summary>
    [XmlRoot("PSISessionHistory")]
    public sealed class SessionHistoryStore
    {
        // ── Configuration ─────────────────────────────────────────────────────

        private const int MaxEntries = 365; // 1-year rolling window

        // Shared with TradeBaseline.cs — same subfolder keeps all plugin data together.
        internal static string DataDir = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
            "NinjaTrader 8", "bin", "Custom", "AddOns", "TradeMonitorData");

        /// <inheritdoc cref="StrategyProfile.SetDataDir"/>
        internal static void SetDataDir(string path)
        {
            if (!string.IsNullOrEmpty(path)) DataDir = path;
        }

        public static string HistoryPath => Path.Combine(DataDir, "history.xml");

        // ── Persisted data ────────────────────────────────────────────────────

        [XmlArray("Sessions")]
        [XmlArrayItem("S")]
        public List<SessionHistoryEntry> Sessions { get; set; } =
            new List<SessionHistoryEntry>(MaxEntries);

        // ── Query helpers (not persisted) ─────────────────────────────────────

        /// <summary>Entries sorted newest-first (for UI display).</summary>
        [XmlIgnore]
        public IEnumerable<SessionHistoryEntry> ByDateDescending =>
            Sessions.OrderByDescending(s => s.Date);

        /// <summary>Entries within the last <paramref name="days"/> calendar days, oldest-first.</summary>
        public IEnumerable<SessionHistoryEntry> Recent(int days)
        {
            var cutoff = DateTime.Today.AddDays(-days);
            return Sessions
                .Where(s => s.Date.Date >= cutoff)
                .OrderBy(s => s.Date);
        }

        /// <summary>
        /// Counts consecutive "Stable" sessions (FinalPsi ≥ 70) going backward
        /// from the most-recent entry.  Returns 0 if the last session was not Stable.
        /// </summary>
        public int CurrentStableStreak()
        {
            int streak = 0;
            foreach (var s in Sessions.OrderByDescending(x => x.Date))
            {
                if (s.FinalZone == PsiZone.Stable) streak++;
                else break;
            }
            return streak;
        }

        /// <summary>
        /// Entries with FinalZone == Stable in the given window, as a percentage.
        /// Returns null if there are no entries in the window.
        /// </summary>
        public double? StableDaysPct(int days = 30)
        {
            var window = Recent(days).ToList();
            if (window.Count == 0) return null;
            return 100.0 * window.Count(s => s.FinalZone == PsiZone.Stable) / window.Count;
        }

        /// <summary>Average net P&amp;L per session over the given window.</summary>
        public double? AvgPnl(int days = 30)
        {
            var window = Recent(days).Where(s => s.TotalTrades > 0).ToList();
            return window.Count > 0 ? window.Average(s => s.TotalPnl) : (double?)null;
        }

        // ── Mutation ──────────────────────────────────────────────────────────

        /// <summary>
        /// Adds or replaces the entry for <paramref name="entry"/>'s calendar date,
        /// then trims the store to <see cref="MaxEntries"/> and saves to disk.
        ///
        /// Only sessions with at least one trade are persisted; empty monitoring
        /// sessions are silently skipped.
        /// </summary>
        public void Append(SessionHistoryEntry entry, Action<string> onError = null)
        {
            if (entry == null) return;
            if (entry.TotalTrades == 0) return; // never persist zero-trade sessions

            Sessions.RemoveAll(s => s.Date.Date == entry.Date.Date);
            Sessions.Add(entry);

            if (Sessions.Count > MaxEntries)
            {
                Sessions = Sessions
                    .OrderBy(s => s.Date)
                    .Skip(Sessions.Count - MaxEntries)
                    .ToList();
            }

            SaveToFile(onError);
        }

        // ── I/O ───────────────────────────────────────────────────────────────

        /// <summary>
        /// Loads from disk.  Never throws — returns an empty store on any failure.
        /// Corrupt files are backed-up before being discarded.
        /// </summary>
        public static SessionHistoryStore LoadFromFile(Action<string> onError = null)
        {
            if (!File.Exists(HistoryPath))
                return new SessionHistoryStore();

            try
            {
                var xs = new XmlSerializer(typeof(SessionHistoryStore));
                using (var fs = new FileStream(HistoryPath, FileMode.Open,
                                               FileAccess.Read, FileShare.Read))
                    return (SessionHistoryStore)xs.Deserialize(fs) ?? new SessionHistoryStore();
            }
            catch (Exception ex)
            {
                onError?.Invoke(
                    $"[TradeMonitor] Session history load failed — starting with empty history. Reason: {ex.Message}");
                try
                {
                    // Back up the corrupt file so the user does not permanently lose data.
                    File.Copy(HistoryPath,
                              HistoryPath + ".corrupt." + DateTime.Now.Ticks,
                              overwrite: true);
                }
                catch { /* backup is best-effort */ }
                return new SessionHistoryStore();
            }
        }

        /// <summary>
        /// Saves to disk using an atomic temp-file → rename strategy.
        /// Never throws — persistence failures are reported via <paramref name="onError"/>
        /// so live monitoring is never interrupted.
        /// </summary>
        public void SaveToFile(Action<string> onError = null)
        {
            try
            {
                Directory.CreateDirectory(DataDir);

                string tempPath = HistoryPath + ".tmp";
                var xs = new XmlSerializer(typeof(SessionHistoryStore));
                using (var fs = new FileStream(tempPath, FileMode.Create,
                                               FileAccess.Write, FileShare.None))
                    xs.Serialize(fs, this);

                // Replace atomically: deleting target + renaming temp is as safe
                // as Windows allows without using transacted NTFS.
                if (File.Exists(HistoryPath)) File.Delete(HistoryPath);
                File.Move(tempPath, HistoryPath);
            }
            catch (Exception ex)
            {
                onError?.Invoke(
                    $"[TradeMonitor] Session history save failed. Reason: {ex.Message}");
            }
        }
    }
}
