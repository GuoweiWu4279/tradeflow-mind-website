// TradeMonitorHub.cs
//
// Unified dashboard window that consolidates Session Report, History,
// Trading Profile, and Settings into a single tabbed interface with
// a sidebar navigation panel.
//
// Content for each page is produced by the existing standalone Window
// classes (SessionReportWindow, HistoryWindow, BaselineWindow) via a
// "content transplant" pattern: the window is instantiated but never
// shown, its body content is extracted and placed into the Hub's
// content area.  This eliminates code duplication while keeping
// all existing visual and behavioral code intact.

using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;

namespace NinjaTrader.NinjaScript.AddOns
{
    internal enum HubPage { Session, History, Profile, Settings, License }

    internal sealed class TradeMonitorHub : Window
    {
        // ── Events ───────────────────────────────────────────────────────────
        public event Action        BaselineResetRequested;
        public event Action        HistoryClearRequested;
        public event Action        SettingsRequested;

        // ── Data references (shared with TradeMonitor) ───────────────────────
        private TradeBaseline       _baseline;
        private StrategyProfile     _profile;
        private SessionHistoryStore _historyStore;
        private SessionData         _sessionData;
        private List<string>        _availableAccounts;
        private Action<string>      _onError;
        private LicenseManager      _licenseManager;
        private string              _updateVersion;
        private string              _updateNotes;

        // ── Page state ───────────────────────────────────────────────────────
        private HubPage  _currentPage = HubPage.Session;
        private readonly Grid       _contentArea;
        private readonly Border[]   _navBorders = new Border[5];
        private readonly TextBlock[] _navLabels  = new TextBlock[5];
        private readonly TextBlock[] _navIcons   = new TextBlock[5];

        // Keep reference to BaselineWindow for ResetRequested event
        private BaselineWindow _embeddedBaselineWindow;

        // ── Palette ──────────────────────────────────────────────────────────
        private static readonly Brush BgWindow     = new SolidColorBrush(Color.FromRgb( 28,  28,  30));
        private static readonly Brush BgSidebar    = new SolidColorBrush(Color.FromRgb( 22,  22,  24));
        private static readonly Brush BgHeader     = new SolidColorBrush(Color.FromRgb( 44,  44,  46));
        private static readonly Brush BgNavActive  = new SolidColorBrush(Color.FromArgb( 30, 255, 255, 255));
        private static readonly Brush BgNavHover   = new SolidColorBrush(Color.FromArgb( 18, 255, 255, 255));
        private static readonly Brush FgPrimary    = new SolidColorBrush(Color.FromRgb(245, 245, 247));
        private static readonly Brush FgSecondary  = new SolidColorBrush(Color.FromRgb(174, 174, 178));
        private static readonly Brush FgHint       = new SolidColorBrush(Color.FromRgb( 99,  99, 102));
        private static readonly Brush FgAccent     = new SolidColorBrush(Color.FromRgb( 10, 132, 255));
        private static readonly Brush BgCard       = new SolidColorBrush(Color.FromRgb( 38,  38,  40));

        // Nav item labels and icons (Unicode glyphs)
        private static readonly string[] NavIcons  = { "\u2261", "\u2637", "\u2616", "\u2699", "\u26BF" };
        private static readonly string[] NavLabels = { "Session", "History", "Profile", "Settings", "License" };

        // =====================================================================
        // Constructor
        // =====================================================================

        public TradeMonitorHub(TradeBaseline baseline,
                               StrategyProfile profile,
                               SessionHistoryStore historyStore,
                               SessionData sessionData,
                               List<string> availableAccounts,
                               Action<string> onError,
                               LicenseManager licenseManager = null,
                               string updateVersion = null,
                               string updateNotes   = null)
        {
            _baseline          = baseline      ?? new TradeBaseline();
            _profile           = profile       ?? new StrategyProfile();
            _historyStore      = historyStore  ?? new SessionHistoryStore();
            _sessionData       = sessionData;
            _availableAccounts = availableAccounts ?? new List<string>();
            _onError           = onError;
            _licenseManager    = licenseManager;
            _updateVersion     = updateVersion;
            _updateNotes       = updateNotes;

            WindowStyle        = WindowStyle.None;
            AllowsTransparency = true;
            Background         = Brushes.Transparent;
            ResizeMode         = ResizeMode.CanResizeWithGrip;
            ShowInTaskbar      = true;
            Title              = "TradeMonitor Dashboard";
            Width              = 640;
            Height             = 720;
            MinWidth           = 500;
            MinHeight          = 480;
            Left = (SystemParameters.WorkArea.Width  - Width)  / 2;
            Top  = (SystemParameters.WorkArea.Height - Height) / 2;

            // ── Outer card ─────────────────────────────────────────────────────
            var card = new Border
            {
                CornerRadius    = new CornerRadius(14),
                Background      = BgWindow,
                BorderBrush     = new SolidColorBrush(Color.FromArgb(40, 255, 255, 255)),
                BorderThickness = new Thickness(1),
                ClipToBounds    = true,
            };

            var rootGrid = new Grid();
            rootGrid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(44) });
            rootGrid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });

            // ── Header ─────────────────────────────────────────────────────────
            var header = BuildHeader();
            Grid.SetRow(header, 0);
            rootGrid.Children.Add(header);

            // ── Body: sidebar + content ────────────────────────────────────────
            var bodyGrid = new Grid();
            bodyGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(140) });
            bodyGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1) });
            bodyGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

            // Sidebar
            var sidebar = BuildSidebar();
            Grid.SetColumn(sidebar, 0);
            bodyGrid.Children.Add(sidebar);

            // Separator line
            var sep = new Border
            {
                Width      = 1,
                Background = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255)),
            };
            Grid.SetColumn(sep, 1);
            bodyGrid.Children.Add(sep);

            // Content area
            _contentArea = new Grid { Background = Brushes.Transparent };
            Grid.SetColumn(_contentArea, 2);
            bodyGrid.Children.Add(_contentArea);

            Grid.SetRow(bodyGrid, 1);
            rootGrid.Children.Add(bodyGrid);

            card.Child = rootGrid;
            Content    = card;

            // ── Show initial page ──────────────────────────────────────────────
            Closed += OnHubWindowClosed;

            NavigateTo(HubPage.Session);
        }

        private void OnHubWindowClosed(object sender, EventArgs e)
        {
            TeardownEmbeddedBaseline();
            _contentArea?.Children.Clear();
        }

        /// <summary>
        /// Unhook embedded page objects so they are not leaked after the visual tree
        /// is torn down.  BaselineWindow subscribes to <see cref="BaselineResetRequested"/>.
        /// </summary>
        private void TeardownEmbeddedBaseline()
        {
            if (_embeddedBaselineWindow == null) return;
            _embeddedBaselineWindow.ResetRequested -= OnEmbeddedBaselineReset;
            _embeddedBaselineWindow = null;
        }

        // =====================================================================
        // Header
        // =====================================================================

        private Border BuildHeader()
        {
            var bg = new Border { Background = BgHeader };
            var grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            var title = new TextBlock
            {
                Text              = "TRADEMONITOR",
                FontSize          = 12,
                FontWeight        = FontWeights.SemiBold,
                FontFamily        = new FontFamily("Segoe UI"),
                Foreground        = FgPrimary,
                VerticalAlignment = VerticalAlignment.Center,
                Margin            = new Thickness(16, 0, 0, 0),
            };
            Grid.SetColumn(title, 0);
            grid.Children.Add(title);

            var closeBtn = MakeHeaderBtn("\u2715", "Close dashboard");
            closeBtn.MouseLeftButtonDown += (_, e) => { e.Handled = true; Close(); };
            Grid.SetColumn(closeBtn, 1);
            grid.Children.Add(closeBtn);

            bg.Child = grid;

            bg.MouseLeftButtonDown += (_, e) =>
            {
                if (!e.Handled && e.ButtonState == MouseButtonState.Pressed)
                    DragMove();
            };

            return bg;
        }

        private static Border MakeHeaderBtn(string glyph, string tooltip)
        {
            var lbl = new TextBlock
            {
                Text                = glyph,
                FontSize            = 14,
                Foreground          = FgSecondary,
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment   = VerticalAlignment.Center,
            };
            var btn = new Border
            {
                Width     = 40,
                Height    = 40,
                Background = Brushes.Transparent,
                Cursor    = Cursors.Hand,
                Child     = lbl,
                ToolTip   = tooltip,
                VerticalAlignment = VerticalAlignment.Center,
            };
            btn.MouseEnter += (_, __) => btn.Background = BgNavHover;
            btn.MouseLeave += (_, __) => btn.Background = Brushes.Transparent;
            return btn;
        }

        // =====================================================================
        // Sidebar
        // =====================================================================

        private Border BuildSidebar()
        {
            var bg = new Border { Background = BgSidebar };
            var stack = new StackPanel
            {
                Margin = new Thickness(0, 8, 0, 0),
            };

            for (int i = 0; i < 5; i++)
            {
                int idx = i;
                var navItem = BuildNavItem(NavIcons[i], NavLabels[i], (HubPage)i, out var border, out var icon, out var label);
                _navBorders[i] = border;
                _navIcons[i]   = icon;
                _navLabels[i]  = label;
                navItem.MouseLeftButtonDown += (_, e) =>
                {
                    e.Handled = true;
                    NavigateTo((HubPage)idx);
                };
                stack.Children.Add(navItem);
            }

            bg.Child = stack;
            return bg;
        }

        private static Border BuildNavItem(string icon, string label, HubPage page,
                                           out Border borderRef, out TextBlock iconRef, out TextBlock labelRef)
        {
            var iconTb = new TextBlock
            {
                Text                = icon,
                FontSize            = 16,
                Foreground          = FgHint,
                VerticalAlignment   = VerticalAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Center,
                Width               = 28,
            };

            var labelTb = new TextBlock
            {
                Text              = label,
                FontSize          = 12,
                FontFamily        = new FontFamily("Segoe UI"),
                Foreground        = FgSecondary,
                VerticalAlignment = VerticalAlignment.Center,
                Margin            = new Thickness(8, 0, 0, 0),
            };

            var row = new StackPanel
            {
                Orientation       = Orientation.Horizontal,
                VerticalAlignment = VerticalAlignment.Center,
                Margin            = new Thickness(12, 0, 8, 0),
            };
            row.Children.Add(iconTb);
            row.Children.Add(labelTb);

            var border = new Border
            {
                Height          = 40,
                Background      = Brushes.Transparent,
                Cursor          = Cursors.Hand,
                Child           = row,
                Margin          = new Thickness(6, 1, 6, 1),
                CornerRadius    = new CornerRadius(6),
            };
            border.MouseEnter += (_, __) =>
            {
                if (border.Tag as string != "active")
                    border.Background = BgNavHover;
            };
            border.MouseLeave += (_, __) =>
            {
                if (border.Tag as string != "active")
                    border.Background = Brushes.Transparent;
            };

            borderRef = border;
            iconRef   = iconTb;
            labelRef  = labelTb;
            return border;
        }

        private void UpdateNavHighlight(HubPage page)
        {
            int idx = (int)page;
            for (int i = 0; i < 5; i++)
            {
                bool active = i == idx;
                _navBorders[i].Background = active ? BgNavActive : Brushes.Transparent;
                _navBorders[i].Tag        = active ? "active" : null;
                _navIcons[i].Foreground   = active ? FgAccent : FgHint;
                _navLabels[i].Foreground  = active ? FgPrimary : FgSecondary;
                _navLabels[i].FontWeight  = active ? FontWeights.SemiBold : FontWeights.Normal;
            }
        }

        // =====================================================================
        // Navigation
        // =====================================================================

        public void NavigateTo(HubPage page)
        {
            if (!Dispatcher.CheckAccess())
            {
                Dispatcher.InvokeAsync(() => NavigateTo(page));
                return;
            }

            TeardownEmbeddedBaseline();
            _currentPage = page;
            UpdateNavHighlight(page);

            _contentArea.Children.Clear();

            FrameworkElement content;
            switch (page)
            {
                case HubPage.Session:
                    content = CreateSessionPage();
                    break;
                case HubPage.History:
                    content = CreateHistoryPage();
                    break;
                case HubPage.Profile:
                    content = CreateProfilePage();
                    break;
                case HubPage.Settings:
                    content = CreateSettingsPage();
                    break;
                case HubPage.License:
                    content = CreateLicensePage();
                    break;
                default:
                    content = new TextBlock { Text = "Unknown page", Foreground = FgPrimary };
                    break;
            }

            _contentArea.Children.Add(content);
        }

        // =====================================================================
        // Public API — called from TradeMonitor
        // =====================================================================

        /// <summary>
        /// Refresh session data and rebuild the Session page if it's visible.
        /// </summary>
        public void UpdateSessionData(SessionData data)
        {
            _sessionData = data;
            if (_currentPage == HubPage.Session)
                NavigateTo(HubPage.Session);
        }

        /// <summary>
        /// Update data references after a baseline reset.
        /// </summary>
        public void UpdateDataRefs(TradeBaseline baseline, StrategyProfile profile)
        {
            _baseline = baseline;
            _profile  = profile;
            if (_currentPage == HubPage.Profile)
                NavigateTo(HubPage.Profile);
        }

        public void UpdateAccounts(List<string> accounts)
        {
            _availableAccounts = accounts ?? new List<string>();
        }

        // =====================================================================
        // Page: Session Report
        // =====================================================================

        private FrameworkElement CreateSessionPage()
        {
            if (_sessionData == null || !_sessionData.HasRecordedTrades())
                return BuildEmptyPage(
                    "\u25CE",
                    "No Session Data",
                    "Start trading to see your session report here.\n" +
                    "The report will show PSI trend, behavioral signals, " +
                    "trade stats, and discipline analysis.");

            try
            {
                // Point-in-time copy: timer + execution threads mutate live SessionData.
                SessionData snap = _sessionData.CreateSnapshot();
                // Commit the current zone's pending time slice into the snapshot so
                // Time-in-State is accurate when the report is opened mid-session.
                snap.Flush(DateTime.Now);
                var source = new SessionReportWindow(snap);
                return TransplantWindowBody(source);
            }
            catch
            {
                return BuildEmptyPage("\u26A0", "Error", "Could not load session report.");
            }
        }

        // =====================================================================
        // Page: History
        // =====================================================================

        private FrameworkElement CreateHistoryPage()
        {
            try
            {
                // Outer DockPanel: history content fills remaining space; danger zone docked to bottom.
                var dock = new DockPanel { LastChildFill = true };

                // ── Danger zone (bottom) ─────────────────────────────────────
                var dangerZone = BuildHistoryDangerZone();
                DockPanel.SetDock(dangerZone, Dock.Bottom);
                dock.Children.Add(dangerZone);

                // ── History content (fill) ───────────────────────────────────
                var source = new HistoryWindow(_historyStore);
                dock.Children.Add(TransplantWindowBody(source));

                return dock;
            }
            catch
            {
                return BuildEmptyPage("\u26A0", "Error", "Could not load history.");
            }
        }

        private FrameworkElement BuildHistoryDangerZone()
        {
            var container = new Border
            {
                Background      = new SolidColorBrush(Color.FromRgb(28, 28, 30)),
                BorderBrush     = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255)),
                BorderThickness = new Thickness(0, 1, 0, 0),
                Padding         = new Thickness(20, 12, 20, 14),
            };

            var clearBtn = new Border
            {
                Background      = new SolidColorBrush(Color.FromRgb(55, 30, 30)),
                CornerRadius    = new CornerRadius(6),
                Padding         = new Thickness(14, 8, 14, 8),
                Cursor          = Cursors.Hand,
                BorderBrush     = new SolidColorBrush(Color.FromRgb(255, 69, 58)),
                BorderThickness = new Thickness(1),
            };

            var btnStack = new StackPanel();
            btnStack.Children.Add(new TextBlock
            {
                Text       = "Clear Session History",
                FontSize   = 12,
                FontFamily = new FontFamily("Segoe UI"),
                FontWeight = FontWeights.SemiBold,
                Foreground = new SolidColorBrush(Color.FromRgb(255, 69, 58)),
            });
            btnStack.Children.Add(new TextBlock
            {
                Text         = "Deletes all session log entries. Does not affect your statistical baseline.",
                FontSize     = 10,
                FontFamily   = new FontFamily("Segoe UI"),
                Foreground   = new SolidColorBrush(Color.FromRgb(174, 174, 178)),
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 3, 0, 0),
            });
            clearBtn.Child = btnStack;

            clearBtn.MouseLeftButtonDown += (_, e) =>
            {
                e.Handled = true;
                var result = MessageBox.Show(
                    "This will permanently delete all session history entries.\n\n" +
                    "Your statistical baseline is NOT affected — only the session log will be cleared.\n\n" +
                    "Are you sure?",
                    "Clear Session History",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Warning,
                    MessageBoxResult.No);

                if (result == MessageBoxResult.Yes)
                {
                    HistoryClearRequested?.Invoke();
                    NavigateTo(HubPage.History);
                }
            };

            container.Child = clearBtn;
            return container;
        }

        // =====================================================================
        // Page: Profile (Baseline)
        // =====================================================================

        private FrameworkElement CreateProfilePage()
        {
            try
            {
                if (_embeddedBaselineWindow != null)
                    _embeddedBaselineWindow.ResetRequested -= OnEmbeddedBaselineReset;

                _embeddedBaselineWindow = new BaselineWindow(_baseline, _profile);
                _embeddedBaselineWindow.ResetRequested += OnEmbeddedBaselineReset;

                return TransplantWindowBody(_embeddedBaselineWindow);
            }
            catch
            {
                return BuildEmptyPage("\u26A0", "Error", "Could not load profile.");
            }
        }

        private void OnEmbeddedBaselineReset()
        {
            BaselineResetRequested?.Invoke();
        }

        // =====================================================================
        // Page: License
        // =====================================================================

        private FrameworkElement CreateLicensePage()
        {
            var lm = _licenseManager;

            // ── Status badge colours ─────────────────────────────────────────
            LicenseStatus status = lm?.Status ?? LicenseStatus.Trial_Active;
            string statusText;
            Brush  statusBg;
            switch (status)
            {
                case LicenseStatus.Trial_Active:
                    int days = lm?.TrialDaysRemaining ?? LicenseManager.TrialDays;
                    statusText = $"试用中 — 剩余 {days} 天";
                    statusBg   = new SolidColorBrush(Color.FromRgb(52, 120, 50));
                    break;
                case LicenseStatus.Trial_Expired:
                    statusText = "试用已到期 — 请激活";
                    statusBg   = new SolidColorBrush(Color.FromRgb(160, 60, 40));
                    break;
                case LicenseStatus.Licensed:
                    statusText = "已激活  ✓";
                    statusBg   = new SolidColorBrush(Color.FromRgb(30, 100, 180));
                    break;
                case LicenseStatus.Offline_Grace:
                    statusText = $"离线模式 — 最多 {LicenseManager.GraceDays} 天宽限";
                    statusBg   = new SolidColorBrush(Color.FromRgb(140, 100, 20));
                    break;
                case LicenseStatus.Expired:
                    statusText = "订阅已过期 — 请续费";
                    statusBg   = new SolidColorBrush(Color.FromRgb(160, 60, 40));
                    break;
                default:
                    statusText = "License 无效 — 请重新激活";
                    statusBg   = new SolidColorBrush(Color.FromRgb(160, 60, 40));
                    break;
            }

            // ── Root scroll ─────────────────────────────────────────────────
            var scroll = new System.Windows.Controls.ScrollViewer
            {
                VerticalScrollBarVisibility   = ScrollBarVisibility.Auto,
                HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
            };

            var stack = new StackPanel { Margin = new Thickness(28, 24, 28, 24) };

            // ── Update available banner (shown above everything else) ─────────
            if (_updateVersion != null)
            {
                var updateBorder = new Border
                {
                    Background   = new SolidColorBrush(Color.FromRgb(40, 80, 140)),
                    CornerRadius = new CornerRadius(6),
                    Padding      = new Thickness(16, 12, 16, 12),
                    Margin       = new Thickness(0, 0, 0, 20),
                };
                var updateInner = new StackPanel();
                updateInner.Children.Add(new TextBlock
                {
                    Text       = $"⬆  新版本可用 — {_updateVersion}",
                    FontSize   = 14,
                    FontFamily = new FontFamily("Segoe UI"),
                    FontWeight = FontWeights.SemiBold,
                    Foreground = FgPrimary,
                    Margin     = new Thickness(0, 0, 0, 4),
                });
                if (!string.IsNullOrEmpty(_updateNotes))
                {
                    updateInner.Children.Add(new TextBlock
                    {
                        Text       = _updateNotes,
                        FontSize   = 12,
                        FontFamily = new FontFamily("Segoe UI"),
                        Foreground = FgSecondary,
                        TextWrapping = TextWrapping.Wrap,
                        Margin     = new Thickness(0, 0, 0, 8),
                    });
                }
                var dlBtn = new Button
                {
                    Content             = "前往下载更新",
                    Padding             = new Thickness(14, 6, 14, 6),
                    Background          = new SolidColorBrush(Color.FromRgb(30, 120, 220)),
                    Foreground          = FgPrimary,
                    BorderThickness     = new Thickness(0),
                    FontFamily          = new FontFamily("Segoe UI"),
                    FontSize            = 12,
                    HorizontalAlignment = HorizontalAlignment.Left,
                    Cursor              = System.Windows.Input.Cursors.Hand,
                };
                dlBtn.Click += (s, e) =>
                {
                    try { System.Diagnostics.Process.Start(LicenseManager.StoreUrl); } catch { }
                };
                updateInner.Children.Add(dlBtn);
                updateBorder.Child = updateInner;
                stack.Children.Add(updateBorder);
            }

            // ── Status badge ────────────────────────────────────────────────
            var badge = new Border
            {
                Background    = statusBg,
                CornerRadius  = new CornerRadius(6),
                Padding       = new Thickness(14, 8, 14, 8),
                Margin        = new Thickness(0, 0, 0, 24),
                HorizontalAlignment = HorizontalAlignment.Left,
            };
            badge.Child = new TextBlock
            {
                Text       = statusText,
                FontSize   = 13,
                FontFamily = new FontFamily("Segoe UI"),
                FontWeight = FontWeights.SemiBold,
                Foreground = FgPrimary,
            };
            stack.Children.Add(badge);

            // ── Machine ID row ───────────────────────────────────────────────
            stack.Children.Add(MakeLicenseLabel("Machine ID"));
            string machineId = LicenseManager.GetMachineId();
            var midRow = new Grid { Margin = new Thickness(0, 4, 0, 20) };
            midRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            midRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            var midBox = new TextBox
            {
                Text              = machineId,
                IsReadOnly        = true,
                FontFamily        = new FontFamily("Consolas"),
                FontSize          = 12,
                Foreground        = FgSecondary,
                Background        = BgCard,
                BorderBrush       = new SolidColorBrush(Color.FromArgb(50, 255, 255, 255)),
                BorderThickness   = new Thickness(1),
                Padding           = new Thickness(10, 7, 10, 7),
            };
            Grid.SetColumn(midBox, 0);
            midRow.Children.Add(midBox);

            var copyBtn = MakeLicenseButton("复制");
            copyBtn.Margin = new Thickness(8, 0, 0, 0);
            copyBtn.Click += (_, __) =>
            {
                try { System.Windows.Clipboard.SetText(machineId); } catch { }
            };
            Grid.SetColumn(copyBtn, 1);
            midRow.Children.Add(copyBtn);
            stack.Children.Add(midRow);

            // ── Key input (hidden when already licensed) ─────────────────────
            bool showActivate = status != LicenseStatus.Licensed &&
                                status != LicenseStatus.Offline_Grace;

            if (showActivate)
            {
                stack.Children.Add(MakeLicenseLabel("License Key"));
                var keyRow = new Grid { Margin = new Thickness(0, 4, 0, 8) };
                keyRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
                keyRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

                var keyBox = new TextBox
                {
                    FontFamily      = new FontFamily("Consolas"),
                    FontSize        = 12,
                    Foreground      = FgPrimary,
                    Background      = BgCard,
                    BorderBrush     = new SolidColorBrush(Color.FromArgb(80, 255, 255, 255)),
                    BorderThickness = new Thickness(1),
                    Padding         = new Thickness(10, 7, 10, 7),
                    ToolTip         = "粘贴你的 License Key，格式：XXXX-XXXX-XXXX-XXXX",
                };
                // Pre-fill with existing key if we have one (invalid/expired case).
                if (!string.IsNullOrEmpty(lm?.LicenseKey)) keyBox.Text = lm.LicenseKey;
                Grid.SetColumn(keyBox, 0);
                keyRow.Children.Add(keyBox);

                var activateBtn = MakeLicenseButton("激活", accent: true);
                activateBtn.Margin = new Thickness(8, 0, 0, 0);
                Grid.SetColumn(activateBtn, 1);
                keyRow.Children.Add(activateBtn);
                stack.Children.Add(keyRow);

                // Feedback label
                var feedbackLabel = new TextBlock
                {
                    FontSize   = 12,
                    FontFamily = new FontFamily("Segoe UI"),
                    Foreground = FgSecondary,
                    Margin     = new Thickness(0, 4, 0, 20),
                    TextWrapping = TextWrapping.Wrap,
                };
                stack.Children.Add(feedbackLabel);

                activateBtn.Click += (_, __) =>
                {
                    if (lm == null) { feedbackLabel.Text = "License 模块未加载。"; return; }
                    activateBtn.IsEnabled = false;
                    feedbackLabel.Foreground = FgSecondary;
                    feedbackLabel.Text = "正在连接服务器...";

                    Task.Run(async () =>
                    {
                        var result = await lm.ActivateAsync(keyBox.Text);
                        Dispatcher.InvokeAsync(() =>
                        {
                            activateBtn.IsEnabled = true;
                            if (result.Success)
                            {
                                feedbackLabel.Foreground = new SolidColorBrush(Color.FromRgb(80, 200, 80));
                                feedbackLabel.Text = "激活成功！TradeMonitor PSI 已完整解锁。";
                                // Refresh this page to show the Licensed badge.
                                NavigateTo(HubPage.License);
                            }
                            else
                            {
                                feedbackLabel.Foreground = new SolidColorBrush(Color.FromRgb(220, 80, 60));
                                feedbackLabel.Text = result.ErrorMessage ?? "激活失败。";
                            }
                        });
                    });
                };
            }
            else
            {
                // Already licensed — show masked key + deactivate option
                stack.Children.Add(MakeLicenseLabel("License Key"));
                string maskedKey = lm?.LicenseKey ?? "";
                if (maskedKey.Length > 8)
                    maskedKey = maskedKey.Substring(0, 4) + "-****-****-" + maskedKey.Substring(maskedKey.Length - 4);

                stack.Children.Add(new TextBlock
                {
                    Text         = maskedKey,
                    FontFamily   = new FontFamily("Consolas"),
                    FontSize     = 12,
                    Foreground   = FgSecondary,
                    Margin       = new Thickness(0, 4, 0, 20),
                });

                // Deactivate button (frees the activation slot)
                var deactBtn = MakeLicenseButton("在此电脑上注销（换机器使用）");
                deactBtn.Margin = new Thickness(0, 0, 0, 8);

                var deactFeedback = new TextBlock
                {
                    FontSize   = 12,
                    FontFamily = new FontFamily("Segoe UI"),
                    Foreground = FgSecondary,
                    Margin     = new Thickness(0, 4, 0, 20),
                    TextWrapping = TextWrapping.Wrap,
                };
                stack.Children.Add(deactBtn);
                stack.Children.Add(deactFeedback);

                deactBtn.Click += (_, __) =>
                {
                    if (lm == null) return;
                    deactBtn.IsEnabled = false;
                    deactFeedback.Text = "正在注销...";
                    Task.Run(async () =>
                    {
                        var result = await lm.DeactivateAsync();
                        Dispatcher.InvokeAsync(() =>
                        {
                            deactBtn.IsEnabled = true;
                            if (result.Success)
                                NavigateTo(HubPage.License);
                            else
                            {
                                deactFeedback.Foreground = new SolidColorBrush(Color.FromRgb(220, 80, 60));
                                deactFeedback.Text = result.ErrorMessage;
                            }
                        });
                    });
                };
            }

            // ── Divider ──────────────────────────────────────────────────────
            stack.Children.Add(new Border
            {
                Height     = 1,
                Background = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255)),
                Margin     = new Thickness(0, 8, 0, 20),
            });

            // ── Store link ───────────────────────────────────────────────────
            stack.Children.Add(new TextBlock
            {
                Text         = "订阅 / 购买",
                FontSize     = 11,
                FontFamily   = new FontFamily("Segoe UI"),
                FontWeight   = FontWeights.SemiBold,
                Foreground   = FgHint,
                Margin       = new Thickness(0, 0, 0, 4),
            });

            var storeLink = new TextBlock
            {
                Text            = LicenseManager.StoreUrl,
                FontSize        = 12,
                FontFamily      = new FontFamily("Segoe UI"),
                Foreground      = FgAccent,
                Cursor          = Cursors.Hand,
                TextDecorations = TextDecorations.Underline,
                Margin          = new Thickness(0, 0, 0, 0),
            };
            storeLink.MouseLeftButtonDown += (_, __) =>
            {
                try { System.Diagnostics.Process.Start(LicenseManager.StoreUrl); } catch { }
            };
            stack.Children.Add(storeLink);

            scroll.Content = stack;
            return scroll;
        }

        // ── License page helpers ──────────────────────────────────────────────

        private static TextBlock MakeLicenseLabel(string text) => new TextBlock
        {
            Text       = text,
            FontSize   = 11,
            FontFamily = new FontFamily("Segoe UI"),
            FontWeight = FontWeights.SemiBold,
            Foreground = FgHint,
            Margin     = new Thickness(0, 0, 0, 2),
        };

        private static System.Windows.Controls.Button MakeLicenseButton(string label, bool accent = false)
        {
            return new System.Windows.Controls.Button
            {
                Content    = label,
                FontSize   = 12,
                FontFamily = new FontFamily("Segoe UI"),
                Foreground = FgPrimary,
                Background = accent
                    ? new SolidColorBrush(Color.FromRgb(10, 132, 255))
                    : BgCard,
                BorderBrush     = new SolidColorBrush(Color.FromArgb(60, 255, 255, 255)),
                BorderThickness = new Thickness(1),
                Padding         = new Thickness(14, 7, 14, 7),
                Cursor          = Cursors.Hand,
            };
        }

        // =====================================================================
        // Page: Settings
        // =====================================================================

        private FrameworkElement CreateSettingsPage()
        {
            try
            {
                var source = new ProfileSettingsWindow(_profile, _availableAccounts, _onError);
                return TransplantSettingsBody(source);
            }
            catch
            {
                return BuildEmptyPage("\u26A0", "Error", "Could not load settings.");
            }
        }

        /// <summary>
        /// ProfileSettingsWindow has a different structure:
        /// Content = Grid(outer) → [Border(card, col0 row0), resize zones]
        /// card → DockPanel → [titleBar(top), bottomStack(bottom), scroll(fill)]
        /// We extract the card, strip the title bar, and return it.
        /// </summary>
        private static FrameworkElement TransplantSettingsBody(ProfileSettingsWindow source)
        {
            var outer = source.Content as Grid;
            source.Content = null;
            if (outer == null) return MakeErrorBlock();

            // The card Border is the first child (column 0, row 0)
            Border card = null;
            foreach (UIElement child in outer.Children)
            {
                if (child is Border b && b.Child is DockPanel)
                {
                    card = b;
                    break;
                }
            }
            if (card == null) return MakeErrorBlock();

            outer.Children.Remove(card);

            var dock = card.Child as DockPanel;
            if (dock != null && dock.Children.Count > 0)
            {
                // Remove the title bar (first DockPanel.Top child)
                dock.Children.RemoveAt(0);
            }

            card.CornerRadius    = new CornerRadius(0);
            card.BorderThickness = new Thickness(0);
            card.Background      = Brushes.Transparent;

            return card;
        }

        // =====================================================================
        // Content transplant helper
        // =====================================================================

        /// <summary>
        /// Extracts the scrollable body from a standard-pattern window:
        ///   Content = Border(card) → Grid(root) → [header(row 0), scroll(row 1)]
        /// Strips the header and card styling, returning the body content.
        /// </summary>
        private static FrameworkElement TransplantWindowBody(Window source)
        {
            var card = source.Content as Border;
            source.Content = null;
            if (card == null) return MakeErrorBlock();

            var root = card.Child as Grid;
            if (root == null) return card;

            // Remove the header (first child, row 0)
            if (root.Children.Count >= 2 && root.RowDefinitions.Count >= 2)
            {
                root.Children.RemoveAt(0);
                root.RowDefinitions.RemoveAt(0);

                // Fix remaining children's row indices
                for (int i = 0; i < root.Children.Count; i++)
                    Grid.SetRow(root.Children[i], i);
            }

            card.CornerRadius    = new CornerRadius(0);
            card.BorderThickness = new Thickness(0);
            card.Background      = Brushes.Transparent;

            return card;
        }

        // =====================================================================
        // Placeholder / error helpers
        // =====================================================================

        private static FrameworkElement BuildEmptyPage(string icon, string title, string message)
        {
            var stack = new StackPanel
            {
                VerticalAlignment   = VerticalAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin              = new Thickness(40),
            };

            stack.Children.Add(new TextBlock
            {
                Text                = icon,
                FontSize            = 40,
                Foreground          = FgHint,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin              = new Thickness(0, 0, 0, 12),
            });

            stack.Children.Add(new TextBlock
            {
                Text                = title,
                FontSize            = 16,
                FontWeight          = FontWeights.SemiBold,
                Foreground          = FgPrimary,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin              = new Thickness(0, 0, 0, 8),
            });

            stack.Children.Add(new TextBlock
            {
                Text                = message,
                FontSize            = 12,
                Foreground          = FgSecondary,
                TextWrapping        = TextWrapping.Wrap,
                TextAlignment       = TextAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Center,
                MaxWidth            = 300,
            });

            return stack;
        }

        private static TextBlock MakeErrorBlock()
        {
            return new TextBlock
            {
                Text       = "Error loading page content.",
                Foreground = FgSecondary,
                FontSize   = 12,
                Margin     = new Thickness(20),
            };
        }
    }
}
