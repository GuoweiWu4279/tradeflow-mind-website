#region Using declarations
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Effects;
using System.Windows.Shapes;
using System.Windows.Shell;
using System.Windows.Threading;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
#endregion

// This namespace holds Add ons in this folder and is required. Do not change it.
namespace NinjaTrader.NinjaScript.AddOns
{
    public class TradeMonitor : NinjaTrader.NinjaScript.AddOnBase
    {
        private const string ProductVersion = "1.0.0";

        // ── Update notification (populated by CheckForUpdateAsync at startup) ─
        private string _updateVersion = null;  // null = no update / check pending
        private string _updateNotes   = null;

        // =====================================================================
        // License manager
        // =====================================================================

        private readonly LicenseManager _licenseManager = new LicenseManager();
        // =====================================================================
        // Core engine components
        // =====================================================================

        private StrategyProfile  _profile;
        private TradeBaseline    _baseline;
        private PsiEngine        _engine;

        // =====================================================================
        // UI
        // =====================================================================

        private PsiOverlayWindow      _overlayWindow;
        private TradeMonitorHub       _hubWindow;
        private NTMenuItem            _openHudMenuItem;
        private NTMenuItem            _openDashMenuItem;

        // =====================================================================
        // Account subscriptions
        // Accessed from both state-change thread and timer thread → needs lock.
        // =====================================================================

        private readonly object        _accountsLock       = new object();
        private readonly List<Account> _subscribedAccounts = new List<Account>();

        // =====================================================================
        // Position entry-time tracking (for holdSeconds calculation)
        // Key: "AccountName::InstrumentName"
        // ConcurrentDictionary handles concurrent reads from the timer thread.
        // =====================================================================

        private readonly ConcurrentDictionary<string, DateTime> _positionEntryTimes
            = new ConcurrentDictionary<string, DateTime>();
        private readonly ConcurrentDictionary<string, double> _positionEntryPrices
            = new ConcurrentDictionary<string, double>();
        private readonly ConcurrentDictionary<string, MarketPosition> _positionDirections
            = new ConcurrentDictionary<string, MarketPosition>();

        // Cumulative open-position quantity per posKey.
        // Updated on every entry/scale-in fill so D3 sees the true combined exposure
        // even when two fills arrive in the same second (NT8 Position event fires before
        // Execution event, so fill.Account.Positions is already updated, but this dict
        // gives us a reliable fallback and handles scale-ins correctly).
        private readonly ConcurrentDictionary<string, double> _positionQuantities
            = new ConcurrentDictionary<string, double>();

        // Maximum Adverse Excursion (MAE) per posKey.
        // Tracks the lowest unrealised PnL observed during a position's life.
        // Updated on every timer tick (BuildPositionSnapshots) and cleared when
        // the position fully closes.  Passed into PositionSnapshot so CalcD5 can
        // penalise a position that was deeply underwater even after it recovers
        // to breakeven/profit — the psychological impact of that period remains.
        private readonly ConcurrentDictionary<string, double> _positionMinPnl
            = new ConcurrentDictionary<string, double>();

        // Partial-close PnL accumulation: ATM strategies split exits into multiple
        // bracket fills (e.g. 3 stops × 1 lot each for a 3-lot position).  Each fill
        // alone has incorrect PnL and should not count as a separate "trade".
        // We accumulate PnL and closing qty across partial closes, then record a
        // single round-trip trade when the position goes fully flat.
        private readonly ConcurrentDictionary<string, double> _pendingPartialPnl
            = new ConcurrentDictionary<string, double>();
        private readonly ConcurrentDictionary<string, double> _pendingPartialQty
            = new ConcurrentDictionary<string, double>();

        // Fill deduplication for copy-trading (Replikanto / signal-copy) setups.
        // When multiple DIFFERENT accounts receive the same signal within 250 ms,
        // only the first account's fill contributes to PSI.
        // Fills from the SAME account are NEVER deduplicated — this allows partial
        // fills of one order AND multiple simultaneous ATM-strategy fills (e.g. two
        // ATM strategies on the same account both hitting Target1 at the same time).
        // Key: "InstrumentName|Direction|Qty"  Value: (first account name, fill ticks)
        private readonly ConcurrentDictionary<string, (string AccountName, long Ticks)> _fillDedup
            = new ConcurrentDictionary<string, (string, long)>(StringComparer.Ordinal);
        // 250 ms: wide enough to catch Replikanto copies (≤ 150 ms apart).
        private const long DedupWindowTicks = 2_500_000L; // 250 ms

        // =====================================================================
        // D5 polling timer (30-second interval)
        // =====================================================================

        private System.Timers.Timer _positionTimer;

        // =====================================================================
        // Session-date tracking (detect new trading day on first fill)
        // =====================================================================

        private DateTime _lastSessionDate = DateTime.MinValue;

        // =====================================================================
        // Playback rewind detection
        // Tracks the most recent fill.Time so we can detect when Playback is
        // reset/rewound to an earlier point (fill.Time < _lastFillTime - tolerance).
        // On detection, all stale position state is cleared and the PSI engine
        // is restarted so the new Playback run begins with a clean slate.
        // =====================================================================

        private DateTime _lastFillTime = DateTime.MinValue;
        private DateTime _lastFillWallTime = DateTime.MinValue;
        private const int PlaybackRewindToleranceMinutes = 2;

        // =====================================================================
        // ATM partial-close grace period
        // After a partial close the broker briefly cancels/resubmits the stop
        // order.  During this window the position appears "naked".  We record
        // the wall-clock (UTC) time of the last partial close and suppress the
        // naked check for PartialCloseGraceSec seconds.
        // =====================================================================

        private DateTime _lastPartialCloseWallTime = DateTime.MinValue;
        private const double PartialCloseGraceSec = 5.0;

        // =====================================================================
        // Replay-pause detection via position-state fingerprint
        // During Market Replay, Globals.Now may not freeze reliably on pause.
        // Instead, we hash the unrealized PnL of all snapshots each poll.
        // If the hash is identical on consecutive polls AND we are in replay/sim
        // mode, the market is frozen → skip PollPositions to prevent EWMA drift
        // and repeated hard deductions while the trader cannot act.
        // =====================================================================

        private long _lastPollSnapshotHash;
        private int  _consecutiveUnchangedPolls;

        // =====================================================================
        // DESYNC grace period
        // When the user drags the Market Replay timeline, NinjaTrader shows
        // a historical position that the user did NOT create.  These positions
        // have no ATM stops (no user orders).  After a DESYNC repair we
        // suppress naked-position detection for DesyncGraceSec so these
        // reconciled positions don't crash PSI.
        // =====================================================================

        private DateTime _lastDesyncRepairWallTime = DateTime.MinValue;
        private const double DesyncGraceSec = 60.0;

        // =====================================================================
        // Monitoring on/off state  (toggled from the HUD pill button)
        // =====================================================================

        private bool _monitoringEnabled = true;

        // =====================================================================
        // First-run flag — set in Configure when profile.xml does not exist yet.
        // Cleared after the settings hub is opened once in OnWindowCreated.
        // =====================================================================

        private bool _isFirstRun;

        // =====================================================================
        // Baseline recording suspension  (SIM / PLAYBACK / TEST mode)
        // When suspended, PSI still computes in real-time (user sees their
        // score) but _baseline stats are NOT updated, preventing simulation
        // or playback data from contaminating the live trading baseline.
        // =====================================================================

        private bool   _baselineRecordingSuspended;
        private string _baselineSuspendReason;   // "SIM", "PLAYBACK", "TEST", or null

        // =====================================================================
        // Session data accumulator
        // =====================================================================

        private SessionData _currentSession = new SessionData();

        // =====================================================================
        // Session history store  ("My History" feature)
        // =====================================================================

        private SessionHistoryStore _historyStore;

        // =====================================================================
        // Alert state  (prevents repeated alerts during the same PSI drop)
        // =====================================================================

        private PsiZone  _prevAlertZone  = PsiZone.Stable;
        private DateTime _lastCritAlert  = DateTime.MinValue;
        private DateTime _lastCautAlert  = DateTime.MinValue;

        // =====================================================================
        // Lifecycle
        // =====================================================================

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = "Real-time Psychological Stability Index (PSI) monitor for day traders.";
                Name        = "TradeMonitor";
            }

            // -----------------------------------------------------------------
            else if (State == State.Configure)
            {
                // Resolve data directory using NT8's authoritative data root.
                // This handles OneDrive Document-folder redirection and non-default
                // NT8 installation locations — both break the hard-coded MyDocuments path.
                string dataDir = System.IO.Path.Combine(
                    NinjaTrader.Core.Globals.UserDataDir,
                    "bin", "Custom", "AddOns", "TradeMonitorData");
                StrategyProfile.SetDataDir(dataDir);
                TradeBaseline.SetDataDir(dataDir);
                SessionHistoryStore.SetDataDir(dataDir);
                LicenseManager.SetDataDir(dataDir);

                // Bind license to the NT8 installation fingerprint (same approach
                // as other commercial NT8 vendors such as Replikanto).  This means
                // reinstalling Windows will NOT invalidate the user's activation —
                // the license is tied to the NT8 install, not the underlying OS.
                try
                {
                    string ntFingerprint = NinjaTrader.Core.Globals.GenerateLicenseCode();
                    LicenseManager.SetMachineId(ntFingerprint);
                }
                catch { /* falls back to Windows MachineGuid inside LicenseManager */ }

                // Kick off license validation asynchronously — never blocks NT8 startup.
                _ = _licenseManager.InitialiseAsync();

                // Check for available updates in the background.
                // Runs once per NT8 session; result surfaced via HUD badge and Dashboard.
                _ = CheckForUpdateAsync();

                // Detect first run before loading (file doesn't exist yet).
                _isFirstRun = !System.IO.File.Exists(StrategyProfile.ProfilePath);

                // Log version for support / bug reports.
                var ntVer = typeof(NinjaTrader.Core.Globals).Assembly.GetName().Version;
                Log($"[TradeMonitor] PSI v{ProductVersion} initializing (NinjaTrader {ntVer})", LogLevel.Information);

                // Load persisted profile, baseline, and session history.
                _profile      = StrategyProfile.LoadFromFile(LogWarning);
                _baseline     = TradeBaseline.LoadFromFile(LogWarning);
                _historyStore = SessionHistoryStore.LoadFromFile(LogWarning);
                _engine       = new PsiEngine(_profile, _baseline,
                                              PsiEngineConfig.FromProfile(_profile));

                // Start the session using whatever the last recorded final PSI was.
                _engine.StartNewSession(_baseline.LastSessionFinalPsi);

                // Subscribe only to accounts that are currently connected.
                // This excludes failed/expired prop-firm accounts whose connection
                // is Disconnected but still appear in Account.All.
                lock (_accountsLock)
                {
                    foreach (Account account in Account.All)
                    {
                        if (!_profile.ShouldMonitor(account.Name)) continue;
                        if (!IsAccountActive(account)) continue;

                        account.ExecutionUpdate += OnExecutionUpdate;
                        account.OrderUpdate     += OnOrderUpdate;
                        account.PositionUpdate  += OnPositionUpdate;
                        _subscribedAccounts.Add(account);
                    }
                }

                // D5 position-hold monitor: poll every 30 seconds on a background thread.
                _positionTimer           = new System.Timers.Timer(30000);
                _positionTimer.AutoReset = true;
                _positionTimer.Elapsed  += OnPositionTimerElapsed;
                _positionTimer.Start();

                // Detect sim/playback from subscribed accounts at startup so
                // the badge is correct even before the first fill arrives.
                RefreshBaselineSuspendStatus();

                // Warn if the baseline appears contaminated by past Playback/Sim data
                // (N >> 0 but SessionCount == 0 means data arrived before proper session
                // tracking or sim-detection existed).
                int totalBaselineN = _baseline.MuSize.N + _baseline.MuLoss.N;
                if (_baseline.SessionCount == 0 && totalBaselineN > 10)
                {
                    Log("[TradeMonitor] WARNING: Your baseline contains " + totalBaselineN +
                        " data points but SessionCount=0. This likely means Playback/Simulation " +
                        "data leaked into your baseline before the auto-detection feature was added. " +
                        "Open Control Center > New > TradeMonitor Profile to review your data, " +
                        "and use the Reset Baseline button if needed.",
                        LogLevel.Warning);
                }

                // HUD is opened explicitly by user via Control Center -> New.
            }

            // -----------------------------------------------------------------
            else if (State == State.Terminated)
            {
                // Stop the timer first to prevent callbacks after teardown.
                if (_positionTimer != null)
                {
                    _positionTimer.Stop();
                    _positionTimer.Elapsed -= OnPositionTimerElapsed;
                    _positionTimer.Dispose();
                    _positionTimer = null;
                }

                // Unsubscribe all accounts.
                lock (_accountsLock)
                {
                    foreach (Account account in _subscribedAccounts)
                    {
                        account.ExecutionUpdate -= OnExecutionUpdate;
                        account.OrderUpdate     -= OnOrderUpdate;
                        account.PositionUpdate  -= OnPositionUpdate;
                    }
                    _subscribedAccounts.Clear();
                }

                // Persist the baseline so history survives restarts.
                _baseline?.SaveToFile(LogWarning);

                // Save the current (in-progress) session to history if any trades
                // occurred.  This handles the "NT8 closed mid-session" case so no
                // data is silently lost when the user shuts down before a new
                // session would naturally have triggered the archive.
                if (_currentSession.HasRecordedTrades() && _historyStore != null)
                {
                    var now = NinjaTrader.Core.Globals.Now;
                    _currentSession.Flush(now);
                    _historyStore.Append(_currentSession.ToHistoryEntry(), LogWarning);
                }

                if (_openHudMenuItem != null)
                {
                    _openHudMenuItem.Click -= OnOpenHudMenuItemClick;
                    _openHudMenuItem = null;
                }
                if (_openDashMenuItem != null)
                {
                    _openDashMenuItem.Click -= OnOpenDashMenuItemClick;
                    _openDashMenuItem = null;
                }

                // Close all open windows on the UI thread.
                if (Application.Current == null) return;
                Application.Current.Dispatcher.InvokeAsync(() =>
                {
                    if (_overlayWindow != null)
                    {
                        _overlayWindow.Close();
                        _overlayWindow = null;
                    }
                    if (_hubWindow != null)
                    {
                        _hubWindow.Close();
                        _hubWindow = null;
                    }
                });
            }
        }

        protected override void OnWindowCreated(Window window)
        {
            base.OnWindowCreated(window);

            ControlCenter cc = window as ControlCenter;
            if (cc == null) return;

            MenuItem newMenu = cc.FindFirst("ControlCenterMenuItemNew") as MenuItem;
            if (newMenu == null) return;

            // Clean stale duplicated menu items (can happen after script reloads).
            for (int i = newMenu.Items.Count - 1; i >= 0; i--)
            {
                MenuItem existing = newMenu.Items[i] as MenuItem;
                if (existing == null) continue;
                string hdr = existing.Header as string ?? "";
                if (hdr.StartsWith("TradeMonitor"))
                    newMenu.Items.RemoveAt(i);
            }

            if (_openHudMenuItem != null)
            {
                _openHudMenuItem.Click -= OnOpenHudMenuItemClick;
                _openHudMenuItem = null;
            }
            if (_openDashMenuItem != null)
            {
                _openDashMenuItem.Click -= OnOpenDashMenuItemClick;
                _openDashMenuItem = null;
            }

            _openHudMenuItem = new NTMenuItem
            {
                Header = "TradeMonitor PSI",
                Style  = Application.Current.TryFindResource("MainMenuItem") as Style
            };
            _openHudMenuItem.Click += OnOpenHudMenuItemClick;
            newMenu.Items.Add(_openHudMenuItem);

            _openDashMenuItem = new NTMenuItem
            {
                Header = "TradeMonitor Dashboard",
                Style  = Application.Current.TryFindResource("MainMenuItem") as Style
            };
            _openDashMenuItem.Click += OnOpenDashMenuItemClick;
            newMenu.Items.Add(_openDashMenuItem);

            // First run: open the Dashboard to the Settings page automatically
            // so the user configures their profile before PSI begins scoring.
            if (_isFirstRun)
            {
                _isFirstRun = false;
                var timer = new System.Windows.Threading.DispatcherTimer
                {
                    Interval = TimeSpan.FromMilliseconds(900)
                };
                timer.Tick += (s, _e) =>
                {
                    ((System.Windows.Threading.DispatcherTimer)s).Stop();
                    ShowOrActivateHub(HubPage.Settings);
                };
                timer.Start();
            }
        }

        protected override void OnWindowDestroyed(Window window)
        {
            base.OnWindowDestroyed(window);

            ControlCenter cc = window as ControlCenter;
            if (cc == null) return;

            MenuItem newMenu = cc.FindFirst("ControlCenterMenuItemNew") as MenuItem;
            if (newMenu != null)
            {
                for (int i = newMenu.Items.Count - 1; i >= 0; i--)
                {
                    MenuItem existing = newMenu.Items[i] as MenuItem;
                    if (existing == null) continue;
                    string hdr = existing.Header as string ?? "";
                    if (hdr.StartsWith("TradeMonitor"))
                        newMenu.Items.RemoveAt(i);
                }
            }

            if (_openHudMenuItem != null)
            {
                _openHudMenuItem.Click -= OnOpenHudMenuItemClick;
                _openHudMenuItem = null;
            }
            if (_openDashMenuItem != null)
            {
                _openDashMenuItem.Click -= OnOpenDashMenuItemClick;
                _openDashMenuItem = null;
            }
        }

        // =====================================================================
        // Execution event handler  (NT8 account thread — NOT the UI thread)
        // =====================================================================

        // ── Copy-trading deduplication ────────────────────────────────────────
        // Returns true ONLY when a fill from a DIFFERENT account has the same
        // instrument/direction/qty within 250 ms (Replikanto copy-trade pattern).
        // Fills from the SAME account are always allowed through, even if they
        // share the same parameters — e.g. two ATM strategies on Playback101 both
        // hitting Target1 simultaneously, or partial fills of a single order.
        private bool IsCopyTradingDuplicate(string accountName, string instrName, MarketPosition dir, double qty, DateTime t)
        {
            string key      = instrName + "|" + dir + "|" + ((int)qty).ToString();
            long   nowTicks = t.Ticks;
            (string AccountName, long Ticks) prev;
            if (_fillDedup.TryGetValue(key, out prev) &&
                (nowTicks - prev.Ticks) < DedupWindowTicks &&
                prev.AccountName != accountName)
            {
                return true; // Different account within window = copy-trade duplicate
            }
            _fillDedup[key] = (accountName, nowTicks);
            return false;
        }

        private void OnExecutionUpdate(object sender, ExecutionEventArgs e)
        {
            if (e?.Execution == null)  return;
            if (!_monitoringEnabled)   return;

            Execution fill = e.Execution;
            if (fill.Instrument?.MasterInstrument == null) return;

            string instrName   = fill.Instrument.MasterInstrument.Name;
            string accountName = fill.Account?.Name ?? "Unknown";
            string posKey      = PositionKey(accountName, instrName);

            // ── Baseline recording suspension ────────────────────────────────
            // Priority: SIM/PLAYBACK auto-detect > manual TestMode > live.
            Account fillAccount = sender as Account;
            string suspendReason = DetectSimPlaybackForAccount(fillAccount);
            if (suspendReason == null && _profile != null && _profile.IsTestModeActive)
                suspendReason = "TEST";

            bool   wasSuspended = _baselineRecordingSuspended;
            string oldReason    = _baselineSuspendReason;
            _baselineRecordingSuspended = suspendReason != null;
            _baselineSuspendReason      = suspendReason;

            if (_baselineRecordingSuspended != wasSuspended || suspendReason != oldReason)
            {
                string logMsg = _baselineRecordingSuspended
                    ? $"[TradeMonitor] Baseline recording SUSPENDED — {suspendReason} ({accountName})."
                    : "[TradeMonitor] Baseline recording RESUMED — live account detected.";
                Log(logMsg, LogLevel.Information);

                string hudBadge = GetHudBadgeText();
                Application.Current?.Dispatcher.InvokeAsync(
                    () => _overlayWindow?.UpdateBaselineStatus(hudBadge));
            }

            // A real execution clears the DESYNC grace — the user is actively
            // trading, so naked-position detection should be fully armed.
            _lastDesyncRepairWallTime = DateTime.MinValue;

            // ── Copy-trading deduplication ─────────────────────────────────────
            // Skip fills from Replikanto follower accounts on DIFFERENT accounts.
            // Same-account fills (partial fills, multiple ATM strategies) always pass.
            if (IsCopyTradingDuplicate(accountName, instrName, fill.MarketPosition, fill.Quantity, fill.Time))
                return;

            // ── Playback rewind / account reset detection ──────────────────────
            // When NinjaTrader Playback is reset or rewound, new fills arrive with
            // timestamps earlier than the last known fill.Time.  The position-tracking
            // dicts and PSI engine still hold state from the previous run, causing
            // completely wrong isClosingFill detection and PSI values.
            // Detection: fill.Time is more than N minutes before _lastFillTime.
            // Action: clear all stale position state and restart the PSI engine.
            if (_lastFillTime != DateTime.MinValue &&
                fill.Time < _lastFillTime.AddMinutes(-PlaybackRewindToleranceMinutes))
            {
                Log("[TradeMonitor] Playback rewind detected (fill " +
                    fill.Time.ToString("HH:mm:ss") + " < last " +
                    _lastFillTime.ToString("HH:mm:ss") + ") — resetting session state.",
                    LogLevel.Warning);

                // Clear all stale position tracking.
                _positionDirections.Clear();
                _positionEntryPrices.Clear();
                _positionEntryTimes.Clear();
                _positionQuantities.Clear();
                _positionMinPnl.Clear();
                _pendingPartialPnl.Clear();
                _pendingPartialQty.Clear();
                _fillDedup.Clear();

                // Reset replay-pause fingerprint so the new run isn't suppressed
                // by a stale hash from the previous run.
                _lastPollSnapshotHash     = 0;
                _consecutiveUnchangedPolls = 0;
                _lastPartialCloseWallTime = DateTime.MinValue;
                _lastDesyncRepairWallTime = DateTime.MinValue;

                // Force re-detection of session date on the next fill.
                _lastSessionDate = DateTime.MinValue;

                // Restart PSI engine and baseline for the new Playback run.
                double currentPsi = _engine.CurrentPsi;
                _engine.StartNewSession(currentPsi);
                if (!_baselineRecordingSuspended)
                    _baseline.StartNewSession(currentPsi, LogWarning);
                _currentSession = new SessionData
                {
                    Date         = DateTime.MinValue,
                    PrevFinalPsi = currentPsi,
                };
            }
            _lastFillTime     = fill.Time;
            _lastFillWallTime = DateTime.UtcNow;

            // ── Session-boundary detection ─────────────────────────────────────
            // Anchor to StrategyProfile.SessionStart instead of raw midnight:
            // fills between 00:00 and SessionStart belong to the previous session.
            DateTime sessionAnchorDate = GetSessionAnchorDate(fill.Time);
            if (sessionAnchorDate != _lastSessionDate)
            {
                if (_lastSessionDate != DateTime.MinValue)
                {
                    // ── Archive the session that just ended ────────────────────
                    _currentSession.Flush(fill.Time);
                    var archived = _currentSession;

                    // Persist to the rolling 365-day history file.
                    _historyStore?.Append(archived.ToHistoryEntry(), LogWarning);

                    // Start a fresh session, carrying forward the prev-session ref.
                    // Use LastFillPsi (not FinalPsi) so the comparison reflects the
                    // trader's psychological state when they STOPPED TRADING, not the
                    // partially recovered value that accumulates during post-trade idle.
                    _currentSession = new SessionData
                    {
                        Date         = sessionAnchorDate,
                        PrevFinalPsi = archived.LastFillPsi,
                        PrevAlerts   = archived.AlertsFired,
                    };
                    _prevAlertZone = PsiZone.Stable; // allow fresh alerts next session

                    // Auto-open the Hub to the Session page on session end.
                    Application.Current?.Dispatcher.InvokeAsync(() =>
                    {
                        if (archived.PsiHistory.Count > 0)
                            ShowOrActivateHub(HubPage.Session);
                    });

                    // Reset the PSI engine / baseline for the new session.
                    // Use ApplyOvernightDecay with the actual elapsed hours so each C_i
                    // dimension's debt decays proportionally to the real overnight gap.
                    // (Weekend = ~60 h → more recovery than a standard 16 h overnight.)
                    double prevPsi = _engine.CurrentPsi;
                    if (!_baselineRecordingSuspended)
                        _baseline.StartNewSession(prevPsi, LogWarning);
                    double overnightHours = _lastFillTime != DateTime.MinValue
                        ? Math.Max(0.0, (fill.Time - _lastFillTime).TotalHours)
                        : _engine.Config.OvernightEstimatedHours;
                    _engine.ApplyOvernightDecay(overnightHours);
                }
                else
                {
                    // First fill ever — set the session date on the accumulator.
                    _currentSession.SetSessionDate(sessionAnchorDate);
                }
                _lastSessionDate = sessionAnchorDate;
            }

            // ── Determine whether this fill opens or closes a position ─────────
            // IMPORTANT: NT8's Execution.MarketPosition is the ORDER DIRECTION
            // (Long = buy order, Short = sell order) — it is NEVER Flat.
            // A closing fill is detected by comparing the fill direction against
            // our internally-tracked open position direction:
            //   tracked Long  + Sell fill → closing the long
            //   tracked Short + Buy  fill → closing the short
            // Any fill on an instrument with no tracked position is an entry.
            _positionDirections.TryGetValue(posKey, out MarketPosition trackedDir);

            // ── Stale-state guard: opening order conflicts with tracked direction ──────
            // A SellShort fill can only OPEN a new Short — it cannot close an existing
            // Long.  Symmetrically, a Buy fill can only open a new Long, not close a
            // Short.  When our tracked direction contradicts the order's opening action,
            // the tracked state is stale (e.g. a Playback reset that advanced the date
            // so the rewind detector didn't fire, or a reconnect that skipped the close).
            //
            // Reversal guard: if fill.Quantity > trackedQty the *excess* opens the new
            // opposite position — that is a legitimate reversal handled by isReversal, so
            // we do NOT clear in that case.
            if (trackedDir != MarketPosition.Flat && fill.Order != null)
            {
                // NT8 SuperDOM / ATM submits Short entries as Action='Sell' (not SellShort),
                // and Long entries as Action='Buy' (not BuyToCover, which closes Shorts).
                // A 'Sell' fill that RESULTS in a Short position while no quantity is
                // tracked can only mean we have a ghost Long direction — a real Long close
                // would have tracked quantity.  Add this case alongside SellShort so Fix A
                // fires for both order action conventions.
                bool isConflictingOpen =
                    (trackedDir == MarketPosition.Long  && fill.Order.OrderAction == OrderAction.SellShort) ||
                    (trackedDir == MarketPosition.Short && fill.Order.OrderAction == OrderAction.Buy) ||
                    // ATM/SuperDOM Short entries use Action='Sell' (not SellShort):
                    (trackedDir == MarketPosition.Long  &&
                     fill.Order.OrderAction      == OrderAction.Sell &&
                     fill.MarketPosition         == MarketPosition.Short &&
                     !_positionQuantities.ContainsKey(posKey)) ||
                    // ATM/SuperDOM Long entries may use BuyToCover in some edge cases:
                    (trackedDir == MarketPosition.Short &&
                     fill.Order.OrderAction      == OrderAction.BuyToCover &&
                     fill.MarketPosition         == MarketPosition.Long &&
                     !_positionQuantities.ContainsKey(posKey));

                if (isConflictingOpen)
                {
                    double staleQty;
                    _positionQuantities.TryGetValue(posKey, out staleQty);
                    bool likelyReversal = staleQty > 0 && fill.Quantity > staleQty;

                    if (!likelyReversal)
                    {
                        Log(string.Format(
                            "[TradeMonitor] Stale direction cleared {0}: tracked={1} but received conflicting open order ({2} qty={3}) — resetting stale state.",
                            posKey, trackedDir, fill.Order.OrderAction, fill.Quantity),
                            LogLevel.Warning);

                        _positionDirections.TryRemove(posKey, out _);
                        _positionQuantities.TryRemove(posKey, out _);
                        _positionEntryTimes.TryRemove(posKey, out _);
                        _positionEntryPrices.TryRemove(posKey, out _);
                        _positionMinPnl.TryRemove(posKey, out _);
                        _pendingPartialPnl.TryRemove(posKey, out _);
                        _pendingPartialQty.TryRemove(posKey, out _);
                        trackedDir = MarketPosition.Flat;

                        // Reset only position-tracking state-machine flags for the new session.
                        // Fix A's job is to clear a ghost position — not to wipe behavioural debt.
                        // C_i debts (D3 oversize, D1 revenge, etc.) are psychological facts that
                        // survive an account reset; calling StartNewSession here would erase them
                        // and cause the unnatural PSI spike (71 → 95) seen in the 10-PM log.
                        _engine.ResetBehavioralFlags();
                        _lastSessionDate           = DateTime.MinValue; // re-detect session date on next fill
                        _lastPollSnapshotHash      = 0;                 // don't suppress timer polls in new session
                        _consecutiveUnchangedPolls = 0;
                        _lastPartialCloseWallTime  = DateTime.MinValue; // don't suppress naked-position checks
                        _lastDesyncRepairWallTime  = DateTime.MinValue; // don't suppress DESYNC repairs
                    }
                }
            }

            // ── NT8 Position Reconciliation ──────────────────────────────────
            // After a Playback rewind, "cleanup" close orders from the previous
            // session fire while our trackedDir = Flat.  Without reconciliation
            // these are treated as new entries, poisoning all subsequent tracking.
            // Fix: if trackedDir = Flat but NT8 shows an open position in the
            // direction being sold/covered, borrow NT8's position info.
            // NT8 fires OnExecutionUpdate BEFORE OnPositionUpdate, so at this
            // moment account.Positions still reflects the PRE-fill state.
            if (trackedDir == MarketPosition.Flat && fill.Order?.Account != null)
            {
                bool isClosingDirection =
                    fill.MarketPosition == MarketPosition.Short ||
                    fill.MarketPosition == MarketPosition.Long;
                if (isClosingDirection)
                {
                    try
                    {
                        foreach (Position ntPos in fill.Order.Account.Positions)
                        {
                            if (ntPos.Instrument?.MasterInstrument !=
                                fill.Order.Instrument?.MasterInstrument) continue;
                            if (ntPos.MarketPosition == MarketPosition.Flat) continue;

                            bool matchesClose =
                                (ntPos.MarketPosition == MarketPosition.Long  && fill.MarketPosition == MarketPosition.Short) ||
                                (ntPos.MarketPosition == MarketPosition.Short && fill.MarketPosition == MarketPosition.Long);

                            if (matchesClose)
                            {
                            Log(string.Format(
                                "[TradeMonitor] NT8 reconcile: trackedDir=Flat but NT8 has {0} {1} {2} — treating fill as close.",
                                ntPos.MarketPosition, ntPos.Quantity, instrName),
                                LogLevel.Warning);
                            trackedDir = ntPos.MarketPosition;
                            _positionDirections[posKey] = trackedDir;
                            Log(string.Format("[TradeMonitor] DIRSET {0}={1} [site=NT8reconcile fill={2}]",
                                posKey, trackedDir, fill.Time.ToString("HH:mm:ss.fff")), LogLevel.Information);
                                _positionQuantities[posKey] = ntPos.Quantity;
                                if (!_positionEntryPrices.ContainsKey(posKey))
                                    _positionEntryPrices[posKey] = ntPos.AveragePrice;
                                // Use fill.Time as entry time estimate (same Playback clock).
                                // This gives holdSeconds=0 for this fill which is acceptable —
                                // using Globals.Now (wall clock) would give negative holdSeconds
                                // in Playback mode because fill.Time is a historical timestamp.
                                if (!_positionEntryTimes.ContainsKey(posKey))
                                    _positionEntryTimes[posKey] = fill.Time;
                                break;
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        LogMonitorException("NT8 reconcile (position scan)", ex);
                    }
                }
            }

            bool isClosingFill = trackedDir != MarketPosition.Flat && (
                (trackedDir == MarketPosition.Long  && fill.MarketPosition == MarketPosition.Short) ||
                (trackedDir == MarketPosition.Short && fill.MarketPosition == MarketPosition.Long));

            // Determine full vs. partial close (partial leaves a residual position).
            // A "reversal" is when fill.Quantity > trackedQty: the excess opens a new
            // position in the opposite direction (e.g. ATM Exit sells 3 while Long 1 →
            // closes 1 Long AND opens 2 Short).  We must track the new position so that
            // the subsequent Buy-to-cover is correctly identified as an exit, not an entry.
            bool   isFullClose  = false;
            bool   isReversal   = false;   // fill.Quantity > trackedQty
            double closingQty   = fill.Quantity; // portion that actually closes the position
            if (isClosingFill)
            {
                double trackedQty;
                if (_positionQuantities.TryGetValue(posKey, out trackedQty))
                {
                    double remaining = trackedQty - fill.Quantity;
                    isFullClose = remaining <= 0.01;
                    isReversal  = remaining < -0.01; // sold/bought MORE than we had
                    if (isReversal)
                        closingQty = trackedQty; // only the tracked portion is a close
                    if (isFullClose)
                        _positionQuantities.TryRemove(posKey, out _);
                    else
                        _positionQuantities[posKey] = remaining;

                    Log(string.Format(
                        "[TradeMonitor] CLOSE {0}: trackedQty={1:F0} fillQty={2:F0} remaining={3:F0} isFullClose={4} isReversal={5}",
                        posKey, trackedQty, fill.Quantity, remaining, isFullClose, isReversal),
                        LogLevel.Information);
                }
                else
                {
                    // Qty key is absent — likely a DESYNC repair that fixed the direction
                    // but left _positionQuantities empty (positionUntracked=false path).
                    // Before declaring a full close (which would clear direction tracking
                    // and corrupt subsequent fills), attempt to recover the remaining qty
                    // from NT8's current position.
                    //
                    // For close fills NT8 fires PositionUpdate BEFORE ExecutionUpdate, so
                    // account.Positions already reflects the post-fill (remaining) qty here.
                    bool recoveredQty = false;
                    if (fill.Order?.Account != null)
                    {
                        try
                        {
                            foreach (Position ntPos in fill.Order.Account.Positions)
                            {
                                if (ntPos.Instrument?.MasterInstrument != fill.Instrument?.MasterInstrument) continue;
                                if (ntPos.MarketPosition == MarketPosition.Flat) continue;

                                double remaining = ntPos.Quantity; // already post-fill
                                _positionQuantities[posKey] = remaining;
                                isFullClose   = remaining <= 0.01;
                                recoveredQty  = true;

                                Log(string.Format(
                                    "[TradeMonitor] CLOSE-FALLBACK {0}: qty key was absent, recovered from NT8 remaining={1:F0} isFullClose={2}",
                                    posKey, remaining, isFullClose),
                                    LogLevel.Warning);
                                break;
                            }
                        }
                        catch { /* NT8 Position API unavailable in some edge cases */ }
                    }
                    if (!recoveredQty)
                    {
                        isFullClose = true; // NT8 confirms flat or unavailable → full close
                        Log(string.Format(
                            "[TradeMonitor] CLOSE-FALLBACK {0}: qty key absent AND NT8 flat — treating as full close.",
                            posKey),
                            LogLevel.Warning);
                    }
                }
            }

            // ── Hold time ─────────────────────────────────────────────────────
            double holdSeconds = 0.0;
            if (isClosingFill)
            {
                DateTime entryTime;
                if (isFullClose)
                {
                    if (_positionEntryTimes.TryRemove(posKey, out entryTime))
                        holdSeconds = Math.Max(0, (fill.Time - entryTime).TotalSeconds);
                }
                else
                {
                    // Partial close: read entry time without removing it.
                    if (_positionEntryTimes.TryGetValue(posKey, out entryTime))
                        holdSeconds = Math.Max(0, (fill.Time - entryTime).TotalSeconds);
                }
            }
            else
            {
                // Entry or scale-in.
                // If trackedDir == Flat this is a brand-new position → always stamp entry time.
                // If trackedDir matches fill direction it's a scale-in → keep original entry time.
                if (trackedDir == MarketPosition.Flat)
                    _positionEntryTimes[posKey] = fill.Time;   // fresh entry (also covers stale Playback reset)
                else
                    _positionEntryTimes.TryAdd(posKey, fill.Time); // scale-in: preserve original time

                // NT8 usually fires OnPositionUpdate before OnExecutionUpdate, so
                // fill.Account.Positions often already reflects the post-fill state.
                // However, this order is NOT guaranteed (especially for single large-lot
                // fills or rapid partial fills), so a posFound=false fallback is required.
                bool posFound = false;
                try
                {
                    foreach (Position pos in fill.Account.Positions)
                    {
                        if (pos.Instrument == fill.Instrument &&
                            pos.MarketPosition != MarketPosition.Flat)
                        {
                            _positionEntryPrices[posKey] = pos.AveragePrice;
                            _positionDirections[posKey]  = pos.MarketPosition;
                            Log(string.Format("[TradeMonitor] DIRSET {0}={1} [site=posFound qty={2} fill={3}]",
                                posKey, pos.MarketPosition, pos.Quantity, fill.Time.ToString("HH:mm:ss.fff")), LogLevel.Information);
                            // Accumulate fill quantity rather than trusting pos.Quantity.
                            // NT8 fires OnExecutionUpdate BEFORE OnPositionUpdate for each
                            // partial fill of the same order, so pos.Quantity at the time
                            // of fill N reflects the position after fill N-1 (stale by 1
                            // fill).  Direct assignment would therefore under-count qty for
                            // multi-lot orders that NT8 splits into sequential 1-lot fills,
                            // causing later partial exits to appear as full closes and
                            // recording ghost trades (Trades: 2 for a single round-trip).
                            _positionQuantities.AddOrUpdate(posKey, fill.Quantity,
                                                            (k, old) => old + fill.Quantity);
                            posFound = true;
                            break;
                        }
                    }
                }
                catch (Exception ex)
                {
                    LogMonitorException("Position sync after entry fill", ex);
                }

                if (!posFound)
                {
                    // Fallback if position hasn't updated yet: accumulate manually.
                    // NT8 sometimes fires OnExecutionUpdate before OnPositionUpdate
                    // (opposite of the comment above), so pos.AveragePrice is not
                    // yet available.  Use fill.Price as the entry-price seed via
                    // TryAdd so we don't overwrite a correct average that was already
                    // stored by an earlier posFound=true pass for the same position.
                    _positionDirections[posKey] = fill.MarketPosition;
                    Log(string.Format("[TradeMonitor] DIRSET {0}={1} [site=fallback(no-pos) fillAction={2} fill={3}]",
                        posKey, fill.MarketPosition, fill.Order?.OrderAction, fill.Time.ToString("HH:mm:ss.fff")), LogLevel.Information);
                    _positionQuantities.AddOrUpdate(posKey, fill.Quantity,
                                                    (k, old) => old + fill.Quantity);
                    _positionEntryPrices.TryAdd(posKey, fill.Price);
                }
            }

            // ── Reversal: set up tracking for the new opposite position ──────────
            // When fill.Quantity > trackedQty (e.g. ATM fires "Exit sell 3" while Long 1),
            // the excess lots open a new Short/Long position.  Register it now so that
            // the subsequent Buy-to-cover (or Sell-to-exit) is correctly seen as an exit.
            if (isClosingFill && isFullClose && isReversal)
            {
                double newQty = fill.Quantity - closingQty;          // excess = new position size
                MarketPosition newDir = fill.MarketPosition;         // fill direction = new position direction
                _positionDirections[posKey]  = newDir;
                Log(string.Format("[TradeMonitor] DIRSET {0}={1} [site=reversal excess={2} fill={3}]",
                    posKey, newDir, newQty, fill.Time.ToString("HH:mm:ss.fff")), LogLevel.Information);
                _positionQuantities[posKey]  = newQty;
                _positionEntryPrices[posKey] = fill.Price;
                _positionEntryTimes[posKey]  = fill.Time;            // entry time for the reversed leg
            }

            // ── Fill direction (for PsiEngine D1 reversal detection) ──────────
            // +1 = Long, -1 = Short, 0 = unknown.
            int fillDirection = 0;
            if (!isClosingFill)
            {
                if      (fill.MarketPosition == MarketPosition.Long)  fillDirection =  1;
                else if (fill.MarketPosition == MarketPosition.Short) fillDirection = -1;
            }
            else
            {
                // Use trackedDir (direction of what was closed) not fill.MarketPosition.
                if      (trackedDir == MarketPosition.Long)  fillDirection =  1;
                else if (trackedDir == MarketPosition.Short) fillDirection = -1;
            }

            // ── PnL and outcome ───────────────────────────────────────────────
            // For reversals, only the closing portion (closingQty) generates realised P&L;
            // the excess lots that open the new position have no P&L yet.
            double pnl   = 0.0;
            double size  = fill.Quantity; // full fill size (used for D3/D6 exposure checks)
            bool   isRealizedFill = isClosingFill;

            if (isRealizedFill &&
                _positionEntryPrices.TryGetValue(posKey, out double entryPrice) &&
                trackedDir != MarketPosition.Flat)
            {
                double pointValue = fill.Instrument.MasterInstrument.PointValue;
                if (pointValue <= 0) pointValue = 1.0;

                if (trackedDir == MarketPosition.Long)
                    pnl = (fill.Price - entryPrice) * closingQty * pointValue;
                else if (trackedDir == MarketPosition.Short)
                    pnl = (entryPrice - fill.Price) * closingQty * pointValue;
            }

            bool isWin = pnl > 0;

            // ── Current net position (for D2 full-close reset) ────────────────
            // Entry/scale-in fills: pass cumulative open size so D3 fires on the total.
            // Full close: pass 0 — signals PsiEngine to reset D2 stop-tracking.
            // Partial close: pass the REMAINING qty so PsiEngine knows the position
            //   is not yet flat (D2 history must be preserved for the residual).
            //   D3/D6 do NOT charge on closing fills regardless of currentNetPosition
            //   because hasRealizedOutcome=true, which PsiEngine uses to set sizeForD=0.
            double currentNetPosition = 0.0;
            if (!isClosingFill)
            {
                _positionQuantities.TryGetValue(posKey, out currentNetPosition);
                if (currentNetPosition <= 0) currentNetPosition = size; // fallback
            }
            else if (!isFullClose)
            {
                // Partial close: _positionQuantities was already updated to remaining qty above.
                _positionQuantities.TryGetValue(posKey, out currentNetPosition);
            }

            // ── Round-trip PnL accumulation ───────────────────────────────────
            // ATM strategies split exits into multiple bracket fills (e.g. 3
            // stops × 1 lot).  We accumulate PnL and qty across partial closes
            // and record a single "trade" when the position goes fully flat.
            double roundTripPnl = pnl;
            double roundTripQty = closingQty;

            if (isRealizedFill && !isFullClose)
            {
                _lastPartialCloseWallTime = DateTime.UtcNow;
                _pendingPartialPnl.AddOrUpdate(posKey, pnl, (k, old) => old + pnl);
                _pendingPartialQty.AddOrUpdate(posKey, closingQty, (k, old) => old + closingQty);
            }
            else if (isRealizedFill && isFullClose)
            {
                if (_pendingPartialPnl.TryRemove(posKey, out double pendingPnl))
                    roundTripPnl += pendingPnl;
                if (_pendingPartialQty.TryRemove(posKey, out double pendingQty))
                    roundTripQty += pendingQty;
            }

            bool roundTripWin = roundTripPnl > 0;

            // Baseline update: only on full close with accumulated round-trip stats.
            if (isRealizedFill && isFullClose && !_baselineRecordingSuspended)
                _baseline.UpdateOnExecution(roundTripPnl, roundTripQty, holdSeconds, roundTripWin);

            // Violation frequency counters (always incremented for rarity calculations)
            if (!_baselineRecordingSuspended)
            {
                _baseline.TotalTradeEvents++;
                TimeSpan tod = fill.Time.TimeOfDay;
                if (tod < _profile.SessionStart || tod > _profile.SessionEnd)
                    _baseline.SessionWindowViolCount++;
            }

            // ── PSI calculation ───────────────────────────────────────────────
            // Still called on every fill (including partials) for real-time responsiveness.
            double preExecPsi = _engine.CurrentPsi;
            double newPsi = _engine.ProcessExecution(
                pnl, size, fill.Time, isWin, holdSeconds, currentNetPosition, fillDirection);

            // ── Session trade stats + fill records ────────────────────────────
            // A "trade" is one complete round-trip (entry → flat). Partial ATM
            // fills are accumulated above; only the final fill records the trade.
            if (isRealizedFill && isFullClose)
                _currentSession.RecordTrade(fill.Time, roundTripWin, roundTripPnl, holdSeconds, newPsi,
                    _engine.ScoreD1, _engine.ScoreD2, _engine.ScoreD3,
                    _engine.ScoreD4, _engine.ScoreD5, _engine.ScoreD6, _engine.ScoreD7);
            else if (!isClosingFill)
                _currentSession.RecordEntry(fill.Time, newPsi,
                    _engine.ScoreD1, _engine.ScoreD2, _engine.ScoreD3,
                    _engine.ScoreD4, _engine.ScoreD5, _engine.ScoreD6, _engine.ScoreD7);

            // ── HUD update ────────────────────────────────────────────────────
            PushPsiToHud(newPsi, fromFill: true, eventTime: fill.Time);

            // ── Diagnostic log ────────────────────────────────────────────────
            Log(
                string.Format(
                    "[TradeMonitor] {0} | {1} | {2} | qty:{3} | raw D1:{4:F2} D2:{5:F2} D3:{6:F2} D4:{7:F2} D5:{8:F2} D6:{9:F2} D7:{10:F2} | debt D1:{11:F1} D2:{12:F1} D3:{13:F1} D4:{14:F1} D5:{15:F1} D6:{16:F1} D7:{17:F1} | PnL:{18:F2} | hold:{19:F0}s | PSI:{20:F1}→{21:F1}",
                    fill.Time.ToString("HH:mm:ss.fff"),
                    isRealizedFill ? "EXIT " : "ENTRY",
                    instrName,
                    (int)currentNetPosition,
                    _engine.ScoreD1, _engine.ScoreD2, _engine.ScoreD3,
                    _engine.ScoreD4, _engine.ScoreD5, _engine.ScoreD6, _engine.ScoreD7,
                    _engine.DebtD1,  _engine.DebtD2,  _engine.DebtD3,
                    _engine.DebtD4,  _engine.DebtD5,  _engine.DebtD6,  _engine.DebtD7,
                    pnl,
                    holdSeconds,
                    preExecPsi,
                    newPsi),
                LogLevel.Information);

            if (isClosingFill && isFullClose && !isReversal)
            {
                // Clean up only for genuine flat closes (not reversals — those already
                // set up new position tracking in the reversal block above).
                _positionEntryPrices.TryRemove(posKey, out _);
                _positionDirections.TryRemove(posKey, out _);
                _positionMinPnl.TryRemove(posKey, out _);
                // _positionQuantities was already cleaned up in the isFullClose branch above.
            }
        }

        // =====================================================================
        // Order-update event handler  (NT8 account thread)
        // Used to detect D2 (stop-loss manipulation) and D6 (SL range violation).
        // =====================================================================

        private void OnOrderUpdate(object sender, OrderEventArgs e)
        {
            if (e?.Order == null)    return;
            if (!_monitoringEnabled) return;

            Order order = e.Order;

            // Only track actively working stop orders.
            if (order.OrderState != OrderState.Working)  return;
            if (order.StopPrice  <= 0)                   return;
            if (order.OrderType  != OrderType.StopMarket &&
                order.OrderType  != OrderType.StopLimit)  return;
            if (order.Instrument?.MasterInstrument == null) return;

            try
            {
                double tickSize = order.Instrument.MasterInstrument.TickSize;
                if (tickSize <= 0) return;

                // Find the active position to determine the entry price.
                double entryPrice = 0.0;
                foreach (Position pos in order.Account.Positions)
                {
                    if (pos.Instrument == order.Instrument &&
                        pos.MarketPosition != MarketPosition.Flat)
                    {
                        entryPrice = pos.AveragePrice;
                        break;
                    }
                }

                if (entryPrice <= 0) return;

                // SL width in ticks = absolute distance from entry to stop.
                double slTicks = Math.Abs(entryPrice - order.StopPrice) / tickSize;
                if (slTicks <= 0) return;

                // Forward to engine (D2 adverse-move tracking + D6 SL compliance).
                // Use Globals.Now (platform clock) instead of order.Time because in
                // Market Replay, order.Time can return the real wall-clock date while
                // fill.Time returns the playback date.  This mismatch corrupts the
                // EWMA time-base and makes D6 see the wrong time-of-day.
                DateTime orderEventTime = NinjaTrader.Core.Globals.Now;
                _engine.ProcessOrderChange(order.Id.ToString(), slTicks, orderEventTime, order.Quantity);
                PushPsiToHud(_engine.CurrentPsi, eventTime: orderEventTime);
            }
            catch (Exception ex)
            {
                LogMonitorException("OnOrderUpdate (SL tracking)", ex);
            }
        }

        // =====================================================================
        // Position-update event handler  (NT8 account thread)
        // Provides IMMEDIATE detection of positions that go flat without a
        // corresponding ExecutionUpdate — the primary case being an account
        // reset (Playback/Simulation restart) that clears the position without
        // firing a close execution.
        //
        // Race-condition contract:
        //   NT8 fires PositionUpdate BEFORE ExecutionUpdate for the same fill.
        //   Clearing our shadow state here for a NORMAL close would cause the
        //   subsequent ExecutionUpdate to see trackedDir=Flat and treat the
        //   close fill as a new entry — the exact ghost-state bug we are fixing.
        //
        //   We therefore clear ONLY when the flat event cannot be explained by
        //   a normal close fill:
        //     • There are no open close-direction working orders.
        //   If working orders exist, ExecutionUpdate will handle the close fill
        //   and we must not race it.
        //   If pending partial PnL exists but NO working orders remain, that means
        //   the account was reset mid-ATM-sequence and the pending state is orphaned
        //   — we clear it along with all other ghost state.
        // =====================================================================

        private void OnPositionUpdate(object sender, PositionEventArgs e)
        {
            if (e?.Position == null || e.Position.Instrument?.MasterInstrument == null) return;
            if (!_monitoringEnabled) return;

            // Only act when position goes FLAT.
            if (e.Position.MarketPosition != MarketPosition.Flat) return;

            var account = sender as Account;
            if (account == null) return;

            string instrName = e.Position.Instrument.MasterInstrument.Name;
            string posKey    = PositionKey(account.Name, instrName);

            // If we are not tracking this position as open, nothing to do.
            MarketPosition trackedDir;
            if (!_positionDirections.TryGetValue(posKey, out trackedDir)) return;
            if (trackedDir == MarketPosition.Flat) return;

            // Guard: is there a pending round-trip accumulation?
            // (set by partial ATM fills; a normal close sequence would have this)
            bool hasPendingClose = _pendingPartialPnl.ContainsKey(posKey) ||
                                   _pendingPartialQty.ContainsKey(posKey);

            // Guard: did a close-direction fill cause this position-flat event?
            //
            // When a normal close fill happens, NT8 fires PositionUpdate BEFORE
            // ExecutionUpdate.  At the moment PositionUpdate fires, the close order
            // is already in Filled (or PartFilled) state — ExecutionUpdate has NOT
            // yet run, so we must not clear state here (ExecutionUpdate will handle it).
            //
            // When an account is force-reset by NT8 (or the user resets the sim
            // account), the position goes flat WITHOUT any fill.  All close bracket
            // orders remain in Working / Cancel-submitted state — none are Filled.
            //
            // Checking for a Filled close-direction order (not Working) is the correct
            // distinguisher.  Previous code checked for Working orders and returned
            // when they existed — the exact OPPOSITE of what is needed, which caused
            // stale direction state to persist after every account reset.
            bool hasFilledCloseOrder = false;
            try
            {
                foreach (Order order in account.Orders)
                {
                    if (order.Instrument?.MasterInstrument?.Name != instrName) continue;
                    if (order.OrderState != OrderState.Filled &&
                        order.OrderState != OrderState.PartFilled) continue;

                    bool isCovering =
                        (trackedDir == MarketPosition.Long  &&
                         (order.OrderAction == OrderAction.Sell ||
                          order.OrderAction == OrderAction.SellShort)) ||
                        (trackedDir == MarketPosition.Short &&
                         (order.OrderAction == OrderAction.Buy ||
                          order.OrderAction == OrderAction.BuyToCover));

                    if (isCovering) { hasFilledCloseOrder = true; break; }
                }
            }
            catch (Exception ex)
            {
                LogMonitorException("OnPositionUpdate (order scan)", ex);
            }

            // A filled close order means ExecutionUpdate will process the close —
            // do not clear state here, let ExecutionUpdate handle it.
            // No filled close orders means this is a reset / external flat —
            // clear ghost state immediately so the next entry starts clean.
            if (hasFilledCloseOrder) return;

            // No filled close orders — this is a reset or broker forced-flat.  Two sub-cases:
            //   a) hasPendingClose = false → clean external flat (reset, broker forced-flat).
            //      Clear all tracking and restart engine.
            //   b) hasPendingClose = true  → ATM partial-close accumulation was in progress
            //      when the account was reset.  The fills will never arrive, so the
            //      pending state is permanently orphaned.  Clear everything, including
            //      the pending partial entries, so the next real position starts clean.
            // In both cases the correct action is the same: clear ghost state immediately.
            Log(string.Format(
                "[TradeMonitor] PositionUpdate: {0} went flat externally (was {1}{2}) — clearing ghost state immediately.",
                posKey, trackedDir,
                hasPendingClose ? ", pending-partial orphaned" : ""),
                LogLevel.Warning);

            _positionDirections.TryRemove(posKey, out _);
            _positionQuantities.TryRemove(posKey, out _);
            _positionEntryTimes.TryRemove(posKey, out _);
            _positionEntryPrices.TryRemove(posKey, out _);
            _positionMinPnl.TryRemove(posKey, out _);
            _pendingPartialPnl.TryRemove(posKey, out _);
            _pendingPartialQty.TryRemove(posKey, out _);

            // Reset only position-tracking state-machine flags.
            // An external flat (reset / broker forced-flat) clears the position but does NOT
            // erase the trader's accumulated behavioural debt.  Calling StartNewSession here
            // would wipe C_i and falsely boost PSI after a rule violation.
            _engine.ResetBehavioralFlags();
        }

        // =====================================================================
        // D5 position-hold timer  (thread-pool thread, every 30 seconds)
        // =====================================================================

        private void OnPositionTimerElapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            try
            {
                if (!_monitoringEnabled) return;

                // Dynamic account discovery: accounts that were Disconnected at
                // State.Configure (e.g. Playback101 after a recompile) may now be
                // Connected.  Subscribe to any new accounts every 30 seconds so
                // fills are never silently ignored.
                DiscoverNewAccounts();

                // Refresh sim/playback/test detection so account reconnects
                // and TestMode expiry are picked up within 30 seconds.
                string oldReason = _baselineSuspendReason;
                RefreshBaselineSuspendStatus();
                if (_baselineSuspendReason != oldReason)
                {
                    string badge = GetHudBadgeText();
                    Application.Current?.Dispatcher.InvokeAsync(
                        () => _overlayWindow?.UpdateBaselineStatus(badge));
                }

                // ── Hybrid playback clock ────────────────────────────────────
                // During replay/sim, Globals.Now on the timer thread may return
                // real wall-clock time (14:xx PM) while fill.Time is playback
                // time (06:xx AM).  Mixing these domains makes EWMA deltaSec
                // negative, silently suppressing all penalty application.
                //
                // Fix: anchor to the last fill's playback time and add the real
                // wall-clock elapsed since that fill.  This keeps the time domain
                // consistent (always playback) while still allowing the clock to
                // advance between fills — so D5 overstay detection, EWMA decay,
                // and cooldown timers all work correctly.
                //
                // IMPORTANT: the hybrid clock is only active while a position is
                // open.  When flat, Globals.Now (= playback time) is used instead.
                // This means that when Market Replay is paused AND the trader is
                // flat, Globals.Now freezes → PsiEngine sees timeFrozen=true →
                // skipEwma=true → PSI holds steady.  Without this guard the
                // wall-clock portion of the hybrid clock would keep advancing even
                // during a pause, causing PSI to drift while nothing is happening.
                bool isReplayOrSim = _baselineSuspendReason == "PLAYBACK"
                                  || _baselineSuspendReason == "SIM";

                bool hasOpenPosition = _positionDirections.Any(
                    kv => kv.Value != MarketPosition.Flat);

                DateTime pollTime;
                if (isReplayOrSim && _lastFillWallTime != DateTime.MinValue && hasOpenPosition)
                {
                    double elapsedSec = (DateTime.UtcNow - _lastFillWallTime).TotalSeconds;
                    pollTime = _lastFillTime.AddSeconds(elapsedSec);
                }
                else
                {
                    pollTime = NinjaTrader.Core.Globals.Now;
                }

                var snapshots = BuildPositionSnapshots(pollTime);

                // ── Replay-pause detection ───────────────────────────────────
                // Hash the position-state fingerprint: if PnL and quantities
                // are identical across two consecutive polls AND we are in
                // replay/sim, the market is frozen → skip PollPositions.
                long hash = ComputeSnapshotHash(snapshots);
                if (isReplayOrSim && hash == _lastPollSnapshotHash && snapshots.Count > 0)
                {
                    _consecutiveUnchangedPolls++;
                    if (_consecutiveUnchangedPolls >= 2)
                    {
                        _lastPollSnapshotHash = hash;
                        return; // market frozen — hold PSI steady
                    }
                }
                else
                {
                    _consecutiveUnchangedPolls = 0;
                }
                _lastPollSnapshotHash = hash;

                bool nakedDetected;
                double newPsi = _engine.PollPositions(
                    snapshots, pollTime, out nakedDetected);

                // Violation frequency counters for rarity-scaled deductions
                if (!_baselineRecordingSuspended)
                {
                    _baseline.TotalPositionPolls++;
                    if (nakedDetected) _baseline.NakedPositionCount++;
                }

                if (nakedDetected)
                {
                    _currentSession.IncrementNakedPositionDetections();
                    FireNakedPositionAlert();
                }

                PushPsiToHud(newPsi, eventTime: pollTime);
            }
            catch (Exception ex)
            {
                LogMonitorException("OnPositionTimerElapsed", ex);
            }
        }

        // Cooldown state for the naked-position alert (wall-clock; this alert is
        // about live risk and must fire even during playback pauses).
        private DateTime _lastNakedAlert = DateTime.MinValue;

        private void FireNakedPositionAlert()
        {
            // Rate-limit to once per 2 minutes to avoid repeated voice spam
            // while the user is still in the naked position.
            if ((DateTime.Now - _lastNakedAlert).TotalMinutes < 2.0) return;
            _lastNakedAlert = DateTime.Now;

            _currentSession.IncrementAlertsFired();
            TryPlayVoiceAlert("Warning. No stop loss detected. Protect your position now.");
            Application.Current?.Dispatcher.InvokeAsync(() =>
                new AlertToastWindow(
                    "⚠ No stop-loss order found — position is unprotected!",
                    isCritical: true).Show());
        }

        // =====================================================================
        // Helpers
        // =====================================================================

        /// <summary>
        /// Builds a snapshot of all currently open positions across all monitored accounts,
        /// AND performs self-healing position-tracking reconciliation as a side effect.
        ///
        /// Reconciliation rules (run every 5 s, independent of fill events):
        ///   1. Quantity / direction mismatch → fix from NT8 truth; log [DESYNC REPAIRED].
        ///   2. Always sync _positionEntryPrices to pos.AveragePrice so scale-in PnL is
        ///      correct (NT8 recomputes the average on every additional fill).
        ///   3. Ghost tracking (we think open; NT8 says flat) → clear internal state; log.
        ///   4. Unknown open position (NT8 has one we never tracked) → bootstrap from NT8.
        ///
        /// Entry TIME is not available from NT8, so it is never overwritten if already set.
        /// </summary>
        private List<PositionSnapshot> BuildPositionSnapshots(DateTime platformNow = default)
        {
            var snapshots = new List<PositionSnapshot>();
            if (platformNow == default)
                platformNow = NinjaTrader.Core.Globals.Now;

            // Instrument deduplication: Replikanto (and other copy-trading tools)
            // replicate positions across follower accounts.  PSI should measure ONE
            // trader's behavior, so we keep at most one snapshot per instrument.
            // Priority: the first account that owns a position wins.
            var seenInstruments = new System.Collections.Generic.HashSet<string>();

            List<Account> accountsCopy;
            lock (_accountsLock)
                accountsCopy = new List<Account>(_subscribedAccounts);

            // Partial-close grace: after an ATM partial fill the broker may
            // briefly cancel and re-submit the stop order.  During this window,
            // the position appears "naked" even though protection is being
            // reconfigured.  Wall-clock based so it works even when Globals.Now
            // is unreliable during Market Replay.
            bool inPartialCloseGrace =
                _lastPartialCloseWallTime != DateTime.MinValue &&
                (DateTime.UtcNow - _lastPartialCloseWallTime).TotalSeconds < PartialCloseGraceSec;

            bool inDesyncGrace =
                _lastDesyncRepairWallTime != DateTime.MinValue &&
                (DateTime.UtcNow - _lastDesyncRepairWallTime).TotalSeconds < DesyncGraceSec;

            foreach (Account account in accountsCopy)
            {
                try
                {
                    // ── Self-Healing: collect every NT8 position key for this account ──
                    var ntOpenKeys = new System.Collections.Generic.HashSet<string>();

                    foreach (Position pos in account.Positions)
                    {
                        if (pos.Instrument?.MasterInstrument == null) continue;
                        if (pos.MarketPosition == MarketPosition.Flat) continue;

                        string instrName = pos.Instrument.MasterInstrument.Name;
                        string key = PositionKey(account.Name, instrName);
                        ntOpenKeys.Add(key);

                        // ── Rule 1 & 4: direction sync only (NOT quantity) ────────
                        // IMPORTANT: We intentionally do NOT sync _positionQuantities here
                        // when the key already exists.
                        // NT8's Position event fires BEFORE the corresponding Execution event
                        // for the same fill.  If the timer polls between those two events it
                        // would see a reduced NT8 quantity (post-Position-update) while our
                        // tracking still holds the pre-fill value — causing a false desync that
                        // turns a partial close into a full close, wiping entry tracking and
                        // crashing PSI.
                        // Quantity tracking stays fully event-sourced from OnExecutionUpdate,
                        // which is correct and race-condition-free.  We bootstrap qty from NT8
                        // ONLY when the key is completely absent (lost after phantom-exit depletion)
                        // — in that case event-sourced tracking was already broken and NT8 is the
                        // only available source of truth.
                        _positionDirections.TryGetValue(key, out MarketPosition trackedDir);
                        bool dirMismatch       = trackedDir != pos.MarketPosition;
                        bool positionUntracked = dirMismatch && trackedDir == MarketPosition.Flat;

                        if (dirMismatch)
                        {
                            Log(string.Format(
                                "[TradeMonitor] DESYNC REPAIRED {0}: tracked dir={1} NT8 dir={2}.",
                                key, trackedDir, pos.MarketPosition),
                                LogLevel.Warning);

                            _lastDesyncRepairWallTime = DateTime.UtcNow;
                            _positionDirections[key] = pos.MarketPosition;
                            Log(string.Format("[TradeMonitor] DIRSET {0}={1} [site=DESYNC-rule1 prevTracked={2}]",
                                key, pos.MarketPosition, trackedDir), LogLevel.Warning);

                            // Always re-anchor qty from NT8 when the key is absent.
                            // A direction-only DESYNC repair (positionUntracked=false) leaves
                            // _positionQuantities empty when the previous phantom-exit sequence
                            // depleted it to zero and removed the key.  The missing key then
                            // triggers the isFullClose=true fallback on the very next partial
                            // close fill, clearing the direction prematurely and creating ghost state.
                            if (!_positionQuantities.ContainsKey(key))
                                _positionQuantities[key] = pos.Quantity;

                            if (positionUntracked)
                            {
                                if (!_positionEntryPrices.ContainsKey(key))
                                    _positionEntryPrices[key] = pos.AveragePrice;
                                if (!_positionEntryTimes.ContainsKey(key))
                                    _positionEntryTimes[key] = DateTime.MinValue;
                            }
                        }

                        // ── Rule 2: always sync entry price to NT8 AveragePrice ───
                        _positionEntryPrices[key] = pos.AveragePrice;

                        // ── Instrument dedup: skip if another account already owns
                        // a snapshot for this instrument (Replikanto follower) ──────
                        if (!seenInstruments.Add(instrName))
                            continue;

                        // ── Build snapshot ────────────────────────────────────────
                        DateTime entryTime = _positionEntryTimes.TryGetValue(key, out DateTime et)
                            ? et
                            : platformNow;

                        double unrealizedPnl = pos.GetUnrealizedProfitLoss(
                            PerformanceUnit.Currency, 0);

                        bool hasStop = _profile.NoStopLossTrader || inPartialCloseGrace || inDesyncGrace;
                        if (!hasStop)
                        {
                            foreach (Order order in account.Orders)
                            {
                                if (order.Instrument?.MasterInstrument != pos.Instrument.MasterInstrument)
                                    continue;
                                if (order.OrderState != OrderState.Working &&
                                    order.OrderState != OrderState.Accepted) continue;
                                if (order.OrderType != OrderType.StopMarket &&
                                    order.OrderType != OrderType.StopLimit)
                                    continue;

                                bool coveringDirection =
                                    (pos.MarketPosition == MarketPosition.Long  &&
                                     (order.OrderAction == OrderAction.Sell ||
                                      order.OrderAction == OrderAction.SellShort)) ||
                                    (pos.MarketPosition == MarketPosition.Short &&
                                     (order.OrderAction == OrderAction.Buy ||
                                      order.OrderAction == OrderAction.BuyToCover));

                                if (coveringDirection) { hasStop = true; break; }
                            }
                        }

                        snapshots.Add(PositionSnapshot.Create(
                            key, unrealizedPnl, entryTime, platformNow, hasStop,
                            quantity: pos.Quantity,
                            minPnl:  _positionMinPnl.AddOrUpdate(
                                         key,
                                         Math.Min(unrealizedPnl, 0.0),
                                         (k, prev) => Math.Min(prev, unrealizedPnl))));
                    }

                    // ── Rule 3: remove ghost tracking for positions NT8 says are flat ──
                    string accountPrefix = account.Name + "::";
                    foreach (string trackedKey in new System.Collections.Generic.List<string>(
                                 _positionDirections.Keys))
                    {
                        if (!trackedKey.StartsWith(accountPrefix)) continue;
                        if (ntOpenKeys.Contains(trackedKey)) continue;

                        Log(string.Format(
                            "[TradeMonitor] DESYNC REPAIRED {0}: tracked as open but NT8 is flat — clearing ghost.",
                            trackedKey),
                            LogLevel.Warning);

                        _positionDirections.TryRemove(trackedKey, out _);
                        _positionQuantities.TryRemove(trackedKey, out _);
                        _positionEntryTimes.TryRemove(trackedKey, out _);
                        _positionEntryPrices.TryRemove(trackedKey, out _);
                        _positionMinPnl.TryRemove(trackedKey, out _);
                        _pendingPartialPnl.TryRemove(trackedKey, out _);
                        _pendingPartialQty.TryRemove(trackedKey, out _);
                    }
                }
                catch (Exception ex)
                {
                    LogMonitorException("BuildPositionSnapshots account=" + account.Name, ex);
                }
            }

            return snapshots;
        }

        private static string PositionKey(string accountName, string instrumentName)
            => accountName + "::" + instrumentName;

        /// <summary>
        /// Simple hash of position states (PnL, qty, hasStop).  Identical hashes
        /// on consecutive polls indicate the market is frozen (replay paused).
        /// </summary>
        private static long ComputeSnapshotHash(List<PositionSnapshot> snapshots)
        {
            unchecked
            {
                long h = 17;
                foreach (var s in snapshots)
                {
                    h = h * 31 + s.UnrealizedPnl.GetHashCode();
                    h = h * 31 + s.Quantity.GetHashCode();
                    h = h * 31 + (s.HasStopOrder ? 1 : 0);
                }
                return h;
            }
        }

        /// <summary>
        /// Maps an event timestamp to a session anchor date using the profile's
        /// declared SessionStart.  This avoids false session resets at midnight
        /// when a trade is closed overnight before the next intended session starts.
        /// </summary>
        private DateTime GetSessionAnchorDate(DateTime eventTime)
        {
            if (_profile == null) return eventTime.Date;
            return eventTime.TimeOfDay < _profile.SessionStart
                ? eventTime.Date.AddDays(-1)
                : eventTime.Date;
        }

        /// <summary>
        /// Records PSI to the session accumulator, checks alert thresholds,
        /// then forwards the value to the HUD window on the UI thread.
        /// Called from the NT8 event thread.
        /// </summary>
        /// <param name="fromFill">True when triggered by an execution fill (not timer/order).</param>
        /// <param name="eventTime">
        /// The platform/playback time of the triggering event.  Used to stamp the
        /// PSI history record so the timeline chart shows playback time rather than
        /// wall-clock time.  Pass default(DateTime) to fall back to Globals.Now
        /// (live-trading path where the two are identical).
        /// </param>
        private void PushPsiToHud(double psi, bool fromFill = false,
                                  DateTime eventTime = default)
        {
            // ── License gate ──────────────────────────────────────────────────────
            // When the trial has expired or the license is invalid/revoked, block
            // PSI output so the product cannot be used without a valid subscription.
            // Trial_Active, Licensed, and Offline_Grace all pass through normally.
            if (!_licenseManager.IsFunctional)
            {
                Application.Current?.Dispatcher.InvokeAsync(() =>
                    _overlayWindow?.UpdateBaselineStatus(GetHudBadgeText()));
                return;
            }

            // ── Session history (called on NT8 event thread — no UI access here)
            // Use the event's own timestamp so the chart timeline reflects
            // playback/platform time, not the wall-clock minute when the timer fired.
            DateTime recordTime = (eventTime == default)
                ? NinjaTrader.Core.Globals.Now
                : eventTime;
            _currentSession.RecordPsi(recordTime, psi, fromFill);

            // ── Dimension debt values (read once; used by alerts, peak tracking, and HUD)
            // HUD bars show EWMA PSI-debt per dimension (unit: PSI points, 0-100).
            // Session recording (RecordTrade/RecordEntry) uses ScoreD1-D7
            // (instantaneous 0-1 signals) — those calls are not changed here.
            double d1 = _engine != null ? _engine.DebtD1 : 0;
            double d2 = _engine != null ? _engine.DebtD2 : 0;
            double d3 = _engine != null ? _engine.DebtD3 : 0;
            double d4 = _engine != null ? _engine.DebtD4 : 0;
            double d5 = _engine != null ? _engine.DebtD5 : 0;
            double d6 = _engine != null ? _engine.DebtD6 : 0;
            double d7 = _engine != null ? _engine.DebtD7 : 0;

            // ── Session peak debt tracking for Composure score ────────────────
            // D2, D3, D5 are the three structural rule dimensions.  D3 fires at
            // entry time (not close), D2/D5 are timer-driven.  All three need peak
            // EWMA debt tracked here so the Composure formula can use them.
            _currentSession.UpdatePeakDebts(d2, d3, d5);

            // ── Alerts
            if (_monitoringEnabled)
                CheckAndFireAlerts(psi, d1, d2, d3, d4, d5, d6, d7);

            // ── HUD display
            bool overExposed = _engine != null && _engine.IsOverExposed;
            double carryDebt = _engine != null ? _engine.CarryDebt : 0;
            _currentSession.CopyHudStats(out int totalTrades, out int winTrades, out int alertsFired);
            double[] debts = { d1, d2, d3, d4, d5, d6, d7 };
            Application.Current?.Dispatcher.InvokeAsync(
                () =>
                {
                    if (_overlayWindow != null)
                    {
                        _overlayWindow.UpdatePsi(psi, fromFill);
                        _overlayWindow.UpdateOverExposed(overExposed);
                        _overlayWindow.UpdateDScores(d1, d2, d3, d4, d5, d6, d7);
                        _overlayWindow.UpdateSessionStats(totalTrades, winTrades, alertsFired);
                        _overlayWindow.UpdateCarryDebt(carryDebt);
                        _overlayWindow.UpdatePeakDimLabel(debts);
                    }
                });
        }

        private void OnOpenHudMenuItemClick(object sender, RoutedEventArgs e)
        {
            ShowOrActivateHud();
        }

        private void OnOpenDashMenuItemClick(object sender, RoutedEventArgs e)
        {
            ShowOrActivateHub();
        }

        private void ShowOrActivateHub(HubPage page = HubPage.Session)
        {
            if (Application.Current == null) return;
            Application.Current.Dispatcher.InvokeAsync(() =>
            {
                if (_hubWindow == null)
                {
                    var accounts = GetActiveAccountNames();
                    _hubWindow = new TradeMonitorHub(
                        _baseline, _profile, _historyStore,
                        _currentSession, accounts, LogWarning,
                        _licenseManager,
                        updateVersion: _updateVersion,
                        updateNotes:   _updateNotes);
                    _hubWindow.BaselineResetRequested += OnHubBaselineReset;
                    _hubWindow.HistoryClearRequested  += OnHubHistoryClear;
                    _hubWindow.Closed += (s, ev) =>
                    {
                        if (_hubWindow != null)
                        {
                            _hubWindow.BaselineResetRequested -= OnHubBaselineReset;
                            _hubWindow.HistoryClearRequested  -= OnHubHistoryClear;
                        }
                        _hubWindow = null;
                    };
                    _hubWindow.Show();
                    _hubWindow.NavigateTo(page);
                }
                else
                {
                    if (!_hubWindow.IsVisible)
                        _hubWindow.Show();
                    if (_hubWindow.WindowState == WindowState.Minimized)
                        _hubWindow.WindowState = WindowState.Normal;
                    _hubWindow.Activate();
                    _hubWindow.NavigateTo(page);
                }
            });
        }

        private void OnHubBaselineReset()
        {
            _baseline = new TradeBaseline();
            _baseline.SaveToFile(LogWarning);
            _engine = new PsiEngine(_profile, _baseline,
                                   PsiEngineConfig.FromProfile(_profile));
            _engine.StartNewSession(100.0);

            Log("[TradeMonitor] Baseline RESET by user — all historical data cleared.",
                LogLevel.Warning);

            _overlayWindow?.UpdateBaselineStatus(GetHudBadgeText());
            _hubWindow?.UpdateDataRefs(_baseline, _profile);
        }

        private void OnHubHistoryClear()
        {
            _historyStore = new SessionHistoryStore();
            _historyStore.SaveToFile(LogWarning);

            Log("[TradeMonitor] Session history CLEARED by user.", LogLevel.Warning);
        }

        private List<string> GetActiveAccountNames()
        {
            var names = new List<string>();
            lock (_accountsLock)
            {
                foreach (var acct in _subscribedAccounts)
                {
                    if (!string.IsNullOrEmpty(acct.Name))
                        names.Add(acct.Name);
                }
            }
            if (names.Count == 0)
            {
                try
                {
                    foreach (Account acct in Account.All)
                    {
                        if (string.IsNullOrEmpty(acct.Name)) continue;
                        if (!IsAccountActive(acct)) continue;
                        names.Add(acct.Name);
                    }
                }
                catch (Exception ex)
                {
                    LogMonitorException("GetActiveAccountNames (Account.All scan)", ex);
                }
            }
            return names;
        }

        private void ShowOrActivateHud()
        {
            if (Application.Current == null) return;

            Application.Current.Dispatcher.InvokeAsync(() =>
            {
                if (_overlayWindow == null)
                {
                    _overlayWindow = new PsiOverlayWindow(_monitoringEnabled);
                    _overlayWindow.Closed                  += OnHudClosed;
                    _overlayWindow.DashboardRequested      += OnHudDashboardRequested;
                    _overlayWindow.MonitoringToggled       += OnHudMonitoringToggled;
                    _overlayWindow.MonitoringStopRequested += OnHudMonitoringStopRequested;
                    _overlayWindow.TestModeToggleRequested += OnHudTestModeToggle;
                    _overlayWindow.Show();
                }
                else
                {
                    if (!_overlayWindow.IsVisible)
                        _overlayWindow.Show();
                    if (_overlayWindow.WindowState == WindowState.Minimized)
                        _overlayWindow.WindowState = WindowState.Normal;
                    // Note: deliberately not calling Activate() — the HUD must never
                    // steal focus from SuperDOM or other trading windows.
                }

                if (_monitoringEnabled)
                    _overlayWindow.UpdatePsi(_engine != null ? _engine.CurrentPsi : 100.0);

                // Refresh from subscribed accounts (catches reconnects since startup).
                RefreshBaselineSuspendStatus();
                _overlayWindow.UpdateBaselineStatus(GetHudBadgeText());
            });
        }

        private void OnHudClosed(object sender, EventArgs e)
        {
            if (_overlayWindow != null)
            {
                _overlayWindow.Closed                  -= OnHudClosed;
                _overlayWindow.DashboardRequested      -= OnHudDashboardRequested;
                _overlayWindow.MonitoringToggled       -= OnHudMonitoringToggled;
                _overlayWindow.MonitoringStopRequested -= OnHudMonitoringStopRequested;
                _overlayWindow.TestModeToggleRequested -= OnHudTestModeToggle;
            }
            _overlayWindow = null;
        }

        private void OnHudDashboardRequested()
        {
            ShowOrActivateHub(HubPage.Session);
        }

        private void OnHudTestModeToggle()
        {
            if (_profile == null) return;

            if (_profile.IsTestModeActive)
                _profile.DeactivateTestMode();
            else
                _profile.ActivateTestMode();

            _profile.SaveToFile(LogWarning);
            RefreshBaselineSuspendStatus();

            if (_overlayWindow != null)
                _overlayWindow.UpdateBaselineStatus(GetHudBadgeText());
        }

        /// <summary>
        /// Scans Account.All for accounts that should be monitored but haven't
        /// been subscribed yet (e.g. Playback101 was Disconnected when
        /// State.Configure ran, but has since reconnected).
        /// Called every 30 seconds from the position timer.
        /// </summary>
        private void DiscoverNewAccounts()
        {
            try
            {
                lock (_accountsLock)
                {
                    foreach (Account account in Account.All)
                    {
                        if (_subscribedAccounts.Contains(account)) continue;
                        if (_profile == null || !_profile.ShouldMonitor(account.Name)) continue;
                        if (!IsAccountActive(account)) continue;

                        account.ExecutionUpdate += OnExecutionUpdate;
                        account.OrderUpdate     += OnOrderUpdate;
                        account.PositionUpdate  += OnPositionUpdate;
                        _subscribedAccounts.Add(account);

                        Log("[TradeMonitor] Late-discovered account: " + account.Name +
                            " — now subscribed for PSI monitoring.",
                            LogLevel.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                LogMonitorException("DiscoverNewAccounts", ex);
            }
        }

        /// <summary>
        /// Returns true if the account has an active (connected or connecting) link.
        /// Failed, expired, or disconnected prop-firm accounts return false.
        /// </summary>
        private bool IsAccountActive(Account acct)
        {
            try
            {
                if (acct?.Connection == null) return false;
                var status = acct.Connection.Status;
                return status == ConnectionStatus.Connected ||
                       status == ConnectionStatus.Connecting;
            }
            catch (Exception ex)
            {
                LogMonitorException("IsAccountActive(" + (acct?.Name ?? "?") + ")", ex);
                return false;
            }
        }

        // ── Simulation / Playback detection ──────────────────────────────────

        /// <summary>
        /// Returns "SIM" for simulation accounts, "PLAYBACK" for playback
        /// accounts, or null for live accounts.  Uses a two-tier check:
        ///   1. Connection mode (Mode.Simulation) — catches all Sim101-style accounts.
        ///   2. Account name prefix — catches Playback101 and edge cases where the
        ///      connection object is unavailable.
        /// </summary>
        private string DetectSimPlaybackForAccount(Account account)
        {
            try
            {
                string name = account?.Name ?? "";

                if (name.StartsWith("Playback", StringComparison.OrdinalIgnoreCase))
                    return "PLAYBACK";

                if (account?.Connection?.Options?.Mode == Mode.Simulation)
                    return "SIM";

                if (name.StartsWith("Sim", StringComparison.OrdinalIgnoreCase))
                    return "SIM";
            }
            catch (Exception ex)
            {
                LogMonitorException("DetectSimPlaybackForAccount(" + (account?.Name ?? "?") + ")", ex);
            }
            return null;
        }

        /// <summary>
        /// Re-evaluates baseline suspension by scanning all subscribed accounts
        /// and the TestMode flag.  Called at startup, on HUD open, and from the
        /// 30-second position timer so account reconnects are caught promptly.
        /// </summary>
        private void RefreshBaselineSuspendStatus()
        {
            string reason = null;
            lock (_accountsLock)
            {
                foreach (var acct in _subscribedAccounts)
                {
                    reason = DetectSimPlaybackForAccount(acct);
                    if (reason != null) break;
                }
            }

            if (reason == null && _profile != null && _profile.IsTestModeActive)
                reason = "TEST";

            _baselineRecordingSuspended = reason != null;
            _baselineSuspendReason      = reason;
        }

        /// <summary>
        /// Returns the badge string to show on the HUD: the suspend reason
        /// if recording is paused, "LEARNING" if the baseline is immature, or null.
        /// </summary>
        private string GetHudBadgeText()
        {
            // License status overrides all other badge messages.
            var ls = _licenseManager?.Status ?? LicenseStatus.Trial_Active;
            if (ls == LicenseStatus.Trial_Active)
            {
                int d = _licenseManager?.TrialDaysRemaining ?? LicenseManager.TrialDays;
                return $"TRIAL — {d}d left";
            }
            if (ls == LicenseStatus.Trial_Expired) return "TRIAL EXPIRED";
            if (ls == LicenseStatus.Expired)       return "LICENSE EXPIRED";
            if (ls == LicenseStatus.Invalid)       return "INVALID KEY";
            if (ls == LicenseStatus.Offline_Grace) return "OFFLINE";

            if (_baselineSuspendReason != null) return _baselineSuspendReason;
            if (_baseline != null && _baseline.SessionCount < 5) return "LEARNING";

            // Update available — lowest priority badge, shown only when the system
            // is otherwise healthy so it doesn't compete with important warnings.
            if (_updateVersion != null) return $"⬆ UPDATE {_updateVersion}";

            return null;
        }

        // ── Version check ─────────────────────────────────────────────────────

        /// <summary>
        /// Fetches the hosted version.json and compares with ProductVersion.
        /// Silently ignored on any network error — never blocks or crashes NT8.
        /// Sets _updateVersion and _updateNotes when a newer version is found.
        /// </summary>
        private async System.Threading.Tasks.Task CheckForUpdateAsync()
        {
            try
            {
                using (var http = new System.Net.Http.HttpClient
                       { Timeout = System.TimeSpan.FromSeconds(8) })
                {
                    string json = await http.GetStringAsync(LicenseManager.VersionCheckUrl);

                    string latest = ExtractJsonField(json, "version");
                    string notes  = ExtractJsonField(json, "notes");

                    if (!string.IsNullOrEmpty(latest) && IsNewerVersion(latest, ProductVersion))
                    {
                        _updateVersion = latest;
                        _updateNotes   = notes ?? "";
                        // Refresh the HUD badge to show the update notification.
                        Application.Current?.Dispatcher.InvokeAsync(() =>
                            _overlayWindow?.UpdateBaselineStatus(GetHudBadgeText()));
                    }
                }
            }
            catch { /* network unavailable — silently ignored */ }
        }

        /// <summary>Compares semantic version strings "major.minor.patch".</summary>
        private static bool IsNewerVersion(string candidate, string current)
        {
            try
            {
                int[] Parse(string v)
                {
                    var parts = v.Split('.');
                    return new int[]
                    {
                        parts.Length > 0 ? int.Parse(parts[0]) : 0,
                        parts.Length > 1 ? int.Parse(parts[1]) : 0,
                        parts.Length > 2 ? int.Parse(parts[2]) : 0,
                    };
                }
                int[] a = Parse(candidate), b = Parse(current);
                for (int i = 0; i < 3; i++)
                {
                    if (a[i] > b[i]) return true;
                    if (a[i] < b[i]) return false;
                }
                return false;
            }
            catch { return false; }
        }

        /// <summary>Minimal JSON string field extractor (no external dependencies).</summary>
        private static string ExtractJsonField(string json, string field)
        {
            if (string.IsNullOrEmpty(json)) return null;
            string key = $"\"{field}\":";
            int pos = json.IndexOf(key, StringComparison.OrdinalIgnoreCase);
            if (pos < 0) return null;
            int start = pos + key.Length;
            while (start < json.Length && (json[start] == ' ' || json[start] == '\t')) start++;
            if (start >= json.Length || json[start] != '"') return null;
            start++;
            int end = json.IndexOf('"', start);
            return end < 0 ? null : json.Substring(start, end - start);
        }

        // ── Monitoring enable / disable ───────────────────────────────────────

        /// <summary>
        /// Enables or disables all PSI data processing.  Called from the HUD
        /// pill-toggle and from the ✕ close button on the HUD window.
        /// </summary>
        private void SetMonitoring(bool enabled)
        {
            _monitoringEnabled = enabled;
            if (enabled)
                _positionTimer?.Start();
            else
                _positionTimer?.Stop();

            // Sync the HUD pill visual (window may already be closed — guard).
            Application.Current?.Dispatcher.InvokeAsync(
                () => _overlayWindow?.SetMonitoringState(enabled));
        }

        private void OnHudMonitoringToggled(bool enabled)
        {
            SetMonitoring(enabled);
        }

        private void OnHudMonitoringStopRequested()
        {
            SetMonitoring(false);
            // The HUD window closes itself after firing this event.
        }

        /// <summary>
        /// NT8 Log() wrapper used as a callback for profile/baseline persistence errors.
        /// </summary>
        private void LogWarning(string message)
        {
            Log(message, LogLevel.Warning);
        }

        /// <summary>
        /// Logs swallowed exceptions from defensive catch blocks so diagnostics
        /// appear in the NinjaScript Output window instead of failing silently.
        /// </summary>
        private void LogMonitorException(string context, Exception ex)
        {
            if (ex == null) return;
            Log("[TradeMonitor] " + context + ": " + ex.GetType().Name + " — " + ex.Message,
                LogLevel.Warning);
        }

        // ── Alert helpers ─────────────────────────────────────────────────────

        /// <summary>
        /// Compares the current PSI zone against the last alerted zone.
        /// Fires a voice + toast alert on downward transitions.
        /// Cooldowns prevent spam: Critical ≥3 min, Caution ≥5 min.
        /// The latch resets to Stable when PSI recovers, allowing fresh alerts
        /// on the next drop.
        /// </summary>
        private void CheckAndFireAlerts(double psi,
                                        double d1, double d2, double d3,
                                        double d4, double d5, double d6, double d7)
        {
            PsiZone zone = SessionData.ZoneOf(psi);

            // Reset latch when PSI returns to Stable so the next drop can alert again.
            if (zone == PsiZone.Stable)
            {
                _prevAlertZone = PsiZone.Stable;
                return;
            }

            // Identify the dominant dimension (highest EWMA debt) for the alert text.
            // Using EWMA debt (not instantaneous raw) gives the sustained driver, not
            // a momentary spike — more useful for the trader to act on.
            string[] dimLabels = { "Revenge Entry", "Stop Manip", "Oversize",
                                   "Hold Bias", "Overstay", "Rule Violation", "Overtrading" };
            double[] debts = { d1, d2, d3, d4, d5, d6, d7 };
            int maxIdx = 0;
            for (int i = 1; i < 7; i++) if (debts[i] > debts[maxIdx]) maxIdx = i;
            string culprit = debts[maxIdx] > 1.0
                ? string.Format(" [{0}]", dimLabels[maxIdx])
                : "";

            // Use platform time for cooldowns so Playback/Simulation respects replay speed.
            DateTime now = NinjaTrader.Core.Globals.Now;

            // CRITICAL transition
            if (zone == PsiZone.Critical &&
                _prevAlertZone != PsiZone.Critical &&
                (now - _lastCritAlert).TotalMinutes >= 3.0)
            {
                _lastCritAlert = now;
                _prevAlertZone = PsiZone.Critical;
                _currentSession.IncrementAlertsFired();
                TryPlayVoiceAlert("P S I critical. Stop trading and take a break now.");
                Application.Current?.Dispatcher.InvokeAsync(
                    () => new AlertToastWindow(
                        string.Format("PSI {0} \u2014 CRITICAL: stop trading{1}", (int)psi, culprit),
                        isCritical: true).Show());
                return;
            }

            // CAUTION transition (from Stable only; don't re-alert if already in Caution)
            if (zone == PsiZone.Caution &&
                _prevAlertZone == PsiZone.Stable &&
                (now - _lastCautAlert).TotalMinutes >= 5.0)
            {
                _lastCautAlert = now;
                _prevAlertZone = PsiZone.Caution;
                TryPlayVoiceAlert("Caution. P S I dropping. Check your behavior.");
                Application.Current?.Dispatcher.InvokeAsync(
                    () => new AlertToastWindow(
                        string.Format("PSI {0} \u2014 CAUTION: violations detected{1}", (int)psi, culprit),
                        isCritical: false).Show());
            }
        }

        /// <summary>
        /// Speaks text via System.Speech.Synthesis (loaded dynamically to avoid
        /// hard assembly dependency).  Falls back to a system exclamation beep.
        /// Runs on a background thread so the NT8 event thread is not blocked.
        /// </summary>
        // Prevents multiple TTS instances from overlapping (causes garbled/incomprehensible audio).
        private static volatile bool _voiceAlertPlaying = false;

        private void TryPlayVoiceAlert(string text)
        {
            // If a voice alert is already playing, don't queue another one on top of it.
            // Overlapping synthesis produces garbled audio that is impossible to understand.
            if (_voiceAlertPlaying) { PlayBeep(); return; }
            _voiceAlertPlaying = true;

            System.Threading.Tasks.Task.Run(() =>
            {
                try
                {
                    var asm = System.Reflection.Assembly.Load(
                        "System.Speech, Version=4.0.0.0, Culture=neutral, " +
                        "PublicKeyToken=31bf3856ad364e35");
                    var t = asm?.GetType("System.Speech.Synthesis.SpeechSynthesizer");
                    if (t == null) { PlayBeep(); return; }
                    using (var synth = (IDisposable)Activator.CreateInstance(t))
                    {
                        t.GetProperty("Volume")?.SetValue(synth, 100);
                        t.GetProperty("Rate")?.SetValue(synth, -2);
                        t.GetMethod("Speak", new[] { typeof(string) })
                         ?.Invoke(synth, new object[] { text });
                    }
                }
                catch (Exception ex)
                {
                    LogMonitorException("Voice alert (System.Speech)", ex);
                    PlayBeep();
                }
                finally { _voiceAlertPlaying = false; }
            });
        }

        private static void PlayBeep()
        {
            try { System.Media.SystemSounds.Exclamation.Play(); } catch { }
        }

    }

    // =========================================================================
    // PSI HUD overlay window  —  two-panel dashboard, Apple dark, animated
    // =========================================================================

    internal sealed class PsiOverlayWindow : Window
    {
        // ── Win32: prevent HUD from stealing focus ────────────────────────────
        // Clicking buttons on the HUD must never de-focus SuperDOM.
        [System.Runtime.InteropServices.DllImport("user32.dll")]
        private static extern int GetWindowLong(IntPtr hwnd, int nIndex);
        [System.Runtime.InteropServices.DllImport("user32.dll")]
        private static extern int SetWindowLong(IntPtr hwnd, int nIndex, int dwNewLong);

        protected override void OnSourceInitialized(EventArgs e)
        {
            base.OnSourceInitialized(e);
            var hwnd = new System.Windows.Interop.WindowInteropHelper(this).Handle;
            SetWindowLong(hwnd, -20 /*GWL_EXSTYLE*/,
                GetWindowLong(hwnd, -20) | 0x08000000 /*WS_EX_NOACTIVATE*/);
            System.Windows.Interop.HwndSource.FromHwnd(hwnd)?.AddHook(NoActivateHook);
        }

        private static IntPtr NoActivateHook(IntPtr hwnd, int msg, IntPtr wParam,
                                              IntPtr lParam, ref bool handled)
        {
            if (msg == 0x0021 /*WM_MOUSEACTIVATE*/)
            {
                handled = true;
                return new IntPtr(3 /*MA_NOACTIVATE*/);
            }
            return IntPtr.Zero;
        }

        // ── Public events ────────────────────────────────────────────────────
        public event Action        DashboardRequested;
        public event Action<bool>  MonitoringToggled;
        public event Action        MonitoringStopRequested;
        public event Action        TestModeToggleRequested;

        // ── Animation state ──────────────────────────────────────────────────
        private double           _displayedPsi = 100.0;
        private double           _targetPsi    = 100.0;
        private double           _pulseIntensity = 0.0; // 1→0 flash on sharp PSI drop
        private bool             _isPaused;
        private readonly DispatcherTimer _animTimer;

        // ── Arc tip "live sensor" dot ─────────────────────────────────────────
        // White dot at the arc's moving end with a color halo (DropShadow ShadowDepth=0).
        // Opacity pulses so it reads as a live "needle tip" indicator.
        private readonly Ellipse           _arcTipDot;
        private readonly DropShadowEffect  _arcTipGlow;  // halo color tracks PSI color
        private double                     _tipPhase = 0.0;
        private double                     _tipRate  = 0.070; // rad/frame ≈ 3.0 s at 30 fps

        // ── Radar pulse ring (smoky breath) ───────────────────────────────────
        // A thick blurred ring emits from the gauge center and expands outward,
        // fading like smoke.  BlurEffect makes it diffuse/smoky (not a sharp line).
        // Speed tracks PSI zone: slow/calm at STABLE, fast at CRITICAL.
        private readonly Ellipse          _pulseRing;
        private readonly SolidColorBrush  _pulseRingBrush;
        private double                    _ringPhase = 0.5; // start mid-cycle (ring hidden)
        private double                    _ringRate  = 1.0 / (4.0 * 30.0); // fraction/frame

        // ── Circular gauge (zero-allocation per-frame updates) ────────────────
        private readonly Path[]           _zoneTracks = new Path[4];   // segmented zone arcs
        private readonly Path             _gaugeProgress;
        private readonly SolidColorBrush  _progressStroke;
        private readonly DropShadowEffect _progressGlow;
        private readonly ArcSegment       _progressArc;
        private readonly PathFigure       _progressFigure;

        private const double GaugeCx       = 75.0;
        private const double GaugeCy       = 75.0;
        private const double GaugeR        = 56.0;
        private const double GaugeStroke   = 12.0;
        private const double GaugeStartDeg = 135.0;
        private const double GaugeSweepDeg = 270.0;

        // ── Center text ──────────────────────────────────────────────────────
        private readonly Label            _valueLabel;
        private readonly Label            _statusLabel;
        private readonly SolidColorBrush  _valueFgBrush;
        private readonly SolidColorBrush  _statusFgBrush;
        private readonly DropShadowEffect _statusGlow;     // mirrors gauge glow colour

        // ── Oversize alarm banner ────────────────────────────────────────────
        private readonly Border           _oversizeBanner;
        private bool                      _overExposed = false;
        private static readonly Color     ColOversize = Color.FromRgb(255, 69, 58);

        // ── Header controls ──────────────────────────────────────────────────
        private readonly Border           _monitorPill;
        private readonly Ellipse          _pillDot;
        private readonly Label            _panelToggleBtn;

        // ── Baseline status badge (SIM / PLAYBACK / TEST / LEARNING / REC) ──
        private readonly Border           _baselineBadge;
        private readonly TextBlock        _baselineBadgeText;
        private bool                      _badgeIsAutoDetected;

        // ── PSI Timeline chart ───────────────────────────────────────────────
        private struct PsiPoint { public DateTime T; public double V; }
        private readonly Queue<PsiPoint>  _psiHistory = new Queue<PsiPoint>();
        private const int                 TimelineMaxPts = 300;
        private readonly Canvas           _timelineCanvas;
        private readonly Polyline         _timelineLine;
        private readonly Rectangle        _zoneBandStable;
        private readonly Rectangle        _zoneBandCaution;
        private readonly Rectangle        _zoneBandCritical;
        private readonly System.Windows.Shapes.Line _gridLine80;
        private readonly System.Windows.Shapes.Line _gridLine50;
        private readonly System.Windows.Shapes.Line _nowLine;    // "now" cursor at right edge
        private int                       _heartbeatCounter = 0;
        private const int                 HeartbeatInterval = 60; // redraw every ~2 s at 30 fps
        private readonly TextBlock        _timeLblStart;
        private readonly TextBlock        _timeLblMid;
        private readonly TextBlock        _timeLblEnd;

        // ── D-Score bars ─────────────────────────────────────────────────────
        private static readonly string[] DimNames =
            { "Revenge", "SL Move", "Size", "Hold Bias", "Overstay", "Rules", "Overtrade" };
        // Prescriptive tooltips: tell the trader what the signal means and what to do.
        private static readonly string[] DimTooltips =
        {
            "Revenge Entry — entering after a loss to recover.\nAction: wait at least one full candle before re-entering.",
            "SL Manipulation — moving stop loss further from entry.\nAction: honour your initial stop. Do not widen risk.",
            "Oversize — position larger than your declared max.\nAction: reduce size to your plan immediately.",
            "Hold Bias — holding losses proportionally longer than wins.\nAction: exit losses as quickly as you exit winners.",
            "Overstay — position held past your safety hold limit.\nAction: set a timer alert; exit if no clear thesis remains.",
            "Rule Violation — open position without a stop loss.\nAction: place stop immediately or flatten.",
            "Overtrading — entry pace exceeds your declared frequency.\nAction: step back; wait for your next planned setup.",
        };
        private readonly Border[]          _dBarFills   = new Border[7];
        private readonly Label[]           _dBarValues  = new Label[7];
        private readonly SolidColorBrush[] _dBarBrushes = new SolidColorBrush[7];
        private readonly Grid[]            _dBarTracks  = new Grid[7];
        private readonly Ellipse[]         _dBarDots    = new Ellipse[7]; // knob at fill edge
        private readonly double[]          _curD        = new double[7];
        private readonly double[]          _dBarTargets = new double[7]; // animation targets

        // ── Session stats ────────────────────────────────────────────────────
        private readonly Label _statTrades;
        private readonly Label _statWinRate;
        private readonly Label _statAlerts;
        private readonly Label _statDuration;
        private DateTime       _sessionStartTime = DateTime.MinValue;

        // ── Carry-debt indicator ──────────────────────────────────────────────
        // Appears below the STABLE/CAUTION/WARNING label when previous-session
        // debt is non-negligible (≥ 3 PSI points).  Lets the trader distinguish
        // "PSI recovering because I traded calmly" from "PSI recovering because
        // yesterday's debt is dissolving."
        private readonly Label _carryDebtLabel;

        // ── Collapsed-HUD peak dimension indicator ────────────────────────────
        // When the right panel is collapsed, the D-score bars are hidden.
        // This label shows the highest-active dimension name so the trader knows
        // what is driving the current PSI drop even without opening the panel.
        // Only visible when collapsed and at least one dimension has debt > 1 PSI pt.
        private readonly Label _peakDimLabel;

        // ── Layout / expand-collapse ─────────────────────────────────────────
        private readonly Grid             _rightPanel;
        private readonly Border           _separator;
        private readonly ColumnDefinition _rightCol;
        private bool   _expanded      = true;
        private double _expandedWidth = ExpandedW;
        private const double LeftPanelW = 200.0;
        private const double ExpandedW  = 560.0;
        private const double CollapsedW = 220.0;

        // ── Apple-style palette ──────────────────────────────────────────────
        private static readonly Color ColStable   = Color.FromRgb( 48, 209,  88);
        private static readonly Color ColCaution  = Color.FromRgb(255, 214,  10);  // yellow
        private static readonly Color ColWarning  = Color.FromRgb(255, 149,   0);  // orange
        private static readonly Color ColCritical = Color.FromRgb(255,  69,  58);  // red

        // ── Zone thresholds — delegate to SessionData (single source of truth) ─
        // STABLE  ≥ 88 (green):   trading within declared limits
        // CAUTION ≥ 72 (yellow):  minor violations — pay attention
        // WARNING ≥ 55 (orange):  significant violations — consider stopping
        // CRITICAL < 55 (red):    stop trading
        private const double ZoneStable   = SessionData.ZoneStableThreshold;   // 88
        private const double ZoneCaution  = 72.0;  // visual-only midpoint (no logical zone)
        private const double ZoneWarning  = SessionData.ZoneCriticalThreshold; // 55
        private static readonly Color ColPaused   = Color.FromRgb( 72,  72,  74);
        private static readonly Brush BgCard       = new SolidColorBrush(Color.FromArgb(253, 22, 22, 24));
        private static readonly Brush BgHeader     = new SolidColorBrush(Color.FromArgb(38, 255, 255, 255));
        private static readonly Brush PillOnBrush  = new SolidColorBrush(Color.FromRgb( 48, 209,  88));
        private static readonly Brush PillOffBrush = new SolidColorBrush(Color.FromRgb( 72,  72,  74));
        private static readonly Brush FgMuted      = new SolidColorBrush(Color.FromRgb(136, 136, 136));
        private static readonly Brush FgDim        = new SolidColorBrush(Color.FromRgb(100, 100, 100));
        private static readonly Brush FgBright     = new SolidColorBrush(Color.FromRgb(220, 220, 224));

        // ═════════════════════════════════════════════════════════════════════
        // Constructor
        // ═════════════════════════════════════════════════════════════════════

        public PsiOverlayWindow(bool monitoringEnabled = true)
        {
            WindowStyle        = WindowStyle.None;
            AllowsTransparency = false;
            Background         = BgCard;
            Topmost            = false;   // normal z-order — goes behind other apps when they're focused
            ShowActivated      = false;   // never steal focus from SuperDOM / hotkeys
            ResizeMode         = ResizeMode.CanResize;
            ShowInTaskbar      = true;
            Title              = "PSI Monitor";
            Width              = ExpandedW;
            Height             = 380;
            MinWidth           = CollapsedW;
            MinHeight          = 300;

            Left = SystemParameters.WorkArea.Right - Width - 20;
            Top  = SystemParameters.WorkArea.Top   + 20;

            WindowChrome.SetWindowChrome(this, new WindowChrome
            {
                CaptionHeight         = 30,
                ResizeBorderThickness = new Thickness(5),
                CornerRadius          = new CornerRadius(0),
                GlassFrameThickness   = new Thickness(0),
                UseAeroCaptionButtons = false,
            });

            _isPaused = !monitoringEnabled;
            Color initCol    = _isPaused ? ColPaused : ColStable;
            _progressStroke  = new SolidColorBrush(initCol);
            _valueFgBrush    = new SolidColorBrush(initCol);
            _statusFgBrush   = new SolidColorBrush(initCol);
            _statusGlow      = new DropShadowEffect
            {
                Color         = initCol,
                BlurRadius    = 6.0,
                ShadowDepth   = 0.0,
                Opacity       = 0.60,
                Direction     = 0,
                RenderingBias = RenderingBias.Performance,
            };

            // ── Root grid ────────────────────────────────────────────────────
            var root = new Grid();
            root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(30) });
            root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });

            // ── HEADER ───────────────────────────────────────────────────────
            var headerBg = new Border { Background = BgHeader };
            var hCols = new Grid();
            hCols.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            for (int ci = 0; ci < 5; ci++)
                hCols.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            var titleLbl = new Label
            {
                Content           = "PSI MONITOR",
                FontSize          = 9,
                FontFamily        = new FontFamily("Segoe UI"),
                FontWeight        = FontWeights.SemiBold,
                Foreground        = new SolidColorBrush(Color.FromRgb(134, 134, 139)),
                VerticalAlignment = VerticalAlignment.Center,
                Padding           = new Thickness(10, 0, 0, 0),
            };

            _baselineBadgeText = new TextBlock
            {
                Text              = "",
                FontSize          = 8,
                FontFamily        = new FontFamily("Segoe UI"),
                FontWeight        = FontWeights.Bold,
                Foreground        = Brushes.Black,
                VerticalAlignment = VerticalAlignment.Center,
                Margin            = new Thickness(2, 0, 2, 0),
            };
            _baselineBadge = new Border
            {
                Background        = new SolidColorBrush(Color.FromRgb(255, 179, 64)),
                CornerRadius      = new CornerRadius(3),
                Padding           = new Thickness(4, 1, 4, 1),
                VerticalAlignment = VerticalAlignment.Center,
                Margin            = new Thickness(4, 0, 0, 0),
                Child             = _baselineBadgeText,
                Cursor            = Cursors.Hand,
                Visibility        = Visibility.Visible,
            };
            _baselineBadge.MouseLeftButtonDown += (_, e) =>
            {
                e.Handled = true;
                if (!_badgeIsAutoDetected) TestModeToggleRequested?.Invoke();
            };

            var titlePanel = new StackPanel
            {
                Orientation       = Orientation.Horizontal,
                VerticalAlignment = VerticalAlignment.Center,
            };
            titlePanel.Children.Add(titleLbl);
            titlePanel.Children.Add(_baselineBadge);

            _panelToggleBtn = MakeHdrBtn("\u25C0", "Collapse panel");
            _panelToggleBtn.MouseLeftButtonDown += (_, e) => { e.Handled = true; TogglePanel(); };

            var dashBtn = MakeHdrBtn("\u2630", "Open dashboard");
            dashBtn.MouseLeftButtonDown += (_, e) => { e.Handled = true; DashboardRequested?.Invoke(); };

            _pillDot = new Ellipse
            {
                Width = 12, Height = 12,
                Fill  = Brushes.White,
                VerticalAlignment = VerticalAlignment.Center,
            };
            _monitorPill = new Border
            {
                Width = 32, Height = 16,
                CornerRadius      = new CornerRadius(8),
                Child             = _pillDot,
                Cursor            = Cursors.Hand,
                VerticalAlignment = VerticalAlignment.Center,
                Margin            = new Thickness(4, 0, 4, 0),
            };
            _monitorPill.MouseLeftButtonDown += OnPillClicked;
            UpdatePillVisuals();

            var minBtn = MakeHdrBtn("\u2500", "Minimize  (monitoring continues)");
            var clsBtn = MakeHdrBtn("\u2715", "Stop monitoring and close");
            minBtn.MouseLeftButtonDown += (_, e) => { e.Handled = true; WindowState = WindowState.Minimized; };
            clsBtn.MouseLeftButtonDown += (_, e) =>
            {
                e.Handled = true;
                MonitoringStopRequested?.Invoke();
                Close();
            };

            Grid.SetColumn(titlePanel,      0); hCols.Children.Add(titlePanel);
            Grid.SetColumn(_panelToggleBtn, 1); hCols.Children.Add(_panelToggleBtn);
            Grid.SetColumn(dashBtn,         2); hCols.Children.Add(dashBtn);
            Grid.SetColumn(_monitorPill,    3); hCols.Children.Add(_monitorPill);
            Grid.SetColumn(minBtn,          4); hCols.Children.Add(minBtn);
            Grid.SetColumn(clsBtn,          5); hCols.Children.Add(clsBtn);
            headerBg.Child = hCols;

            foreach (UIElement el in new UIElement[]
                { _panelToggleBtn, dashBtn, _monitorPill, minBtn, clsBtn })
                WindowChrome.SetIsHitTestVisibleInChrome(el, true);

            titlePanel.Cursor = Cursors.SizeAll;
            titlePanel.MouseLeftButtonDown += (_, e) =>
            {
                if (e.LeftButton == System.Windows.Input.MouseButtonState.Pressed)
                    DragMove();
            };
            headerBg.MouseLeftButtonDown += (_, e) =>
            {
                if (!e.Handled &&
                    e.LeftButton == System.Windows.Input.MouseButtonState.Pressed)
                    DragMove();
            };

            Grid.SetRow(headerBg, 0);
            root.Children.Add(headerBg);

            // ── BODY (two-column layout) ─────────────────────────────────────
            var body = new Grid();
            body.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(LeftPanelW) });
            _rightCol = new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) };
            body.ColumnDefinitions.Add(_rightCol);
            Grid.SetRow(body, 1);
            root.Children.Add(body);

            // ═════════════════════════════════════════════════════════════════
            // LEFT PANEL — Gauge + Oversize Banner + Session Stats
            // ═════════════════════════════════════════════════════════════════

            var leftPanel = new Grid();
            leftPanel.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
            leftPanel.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            leftPanel.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            Grid.SetColumn(leftPanel, 0);
            body.Children.Add(leftPanel);

            // ── Circular gauge ───────────────────────────────────────────────
            // Zone track: 4 colored arcs at low opacity (CRITICAL→WARNING→CAUTION→STABLE)
            Color[] zoneColors = { ColCritical, ColWarning, ColCaution, ColStable };
            double[] zoneBounds = { 0, SessionData.ZoneCriticalThreshold, ZoneCaution,
                                    SessionData.ZoneStableThreshold, 100 };
            for (int zi = 0; zi < 4; zi++)
                _zoneTracks[zi] = BuildZoneArc(zoneBounds[zi], zoneBounds[zi + 1], zoneColors[zi]);

            _progressGlow = new DropShadowEffect
            {
                Color         = initCol,
                BlurRadius    = 10.0,
                ShadowDepth   = 0.0,
                Opacity       = 0.60,
                Direction     = 0,
                RenderingBias = RenderingBias.Performance,
            };

            double sRad  = GaugeStartDeg * Math.PI / 180.0;
            var    sPt   = new Point(GaugeCx + GaugeR * Math.Cos(sRad),
                                     GaugeCy + GaugeR * Math.Sin(sRad));
            _progressArc    = new ArcSegment { Size = new Size(GaugeR, GaugeR),
                                               SweepDirection = SweepDirection.Clockwise };
            _progressFigure = new PathFigure { StartPoint = sPt, IsClosed = false };
            _progressFigure.Segments.Add(_progressArc);
            var progressGeo = new PathGeometry();
            progressGeo.Figures.Add(_progressFigure);

            _gaugeProgress = new Path
            {
                Stroke             = _progressStroke,
                StrokeThickness    = GaugeStroke,
                StrokeStartLineCap = PenLineCap.Round,
                StrokeEndLineCap   = PenLineCap.Round,
                Fill               = Brushes.Transparent,
                Data               = progressGeo,
                Effect             = _progressGlow,
            };
            SetProgressArc(100.0);

            // Arc tip dot — hollow ring (dark fill + white stroke + color glow).
            // Sits centered on the arc track like a gauge needle indicator.
            _arcTipGlow = new DropShadowEffect
            {
                Color         = initCol,
                BlurRadius    = 7.0,
                ShadowDepth   = 0.0,
                Opacity       = 0.55,
                Direction     = 0,
                RenderingBias = RenderingBias.Performance,
            };
            _arcTipDot = new Ellipse
            {
                Width            = 13,
                Height           = 13,
                Fill             = Brushes.Transparent,          // hollow center
                Stroke           = new SolidColorBrush(Color.FromArgb(220, 10, 10, 12)),
                StrokeThickness  = 1.5,
                Effect           = _arcTipGlow,
                IsHitTestVisible = false,
                Opacity          = 0.85,
            };

            // Smoky pulse ring — wide blurred stroke that radiates from center.
            // BlurEffect makes it look like diffuse glowing smoke, not a hard line.
            _pulseRingBrush = new SolidColorBrush(initCol);
            _pulseRing = new Ellipse
            {
                Width            = 2 * GaugeR,
                Height           = 2 * GaugeR,
                Stroke           = _pulseRingBrush,
                StrokeThickness  = 9.0,
                Fill             = Brushes.Transparent,
                IsHitTestVisible = false,
                Opacity          = 0.0,
                Effect           = new BlurEffect
                {
                    Radius        = 12.0,
                    RenderingBias = RenderingBias.Performance,
                },
            };
            Canvas.SetLeft(_pulseRing, GaugeCx - GaugeR);
            Canvas.SetTop (_pulseRing, GaugeCy - GaugeR);

            var gaugeCanvas = new Canvas { Width = 150, Height = 150 };
            foreach (var zt in _zoneTracks) gaugeCanvas.Children.Add(zt);
            gaugeCanvas.Children.Add(_pulseRing);   // behind the arc
            gaugeCanvas.Children.Add(_gaugeProgress);
            gaugeCanvas.Children.Add(_arcTipDot);

            _valueLabel = new Label
            {
                Content                    = _isPaused ? "\u2014" : "100",
                FontSize                   = 26,
                FontFamily                 = new FontFamily("Segoe UI"),
                FontWeight                 = FontWeights.Bold,
                Foreground                 = _valueFgBrush,
                HorizontalAlignment        = HorizontalAlignment.Center,
                HorizontalContentAlignment = HorizontalAlignment.Center,
                Padding                    = new Thickness(0),
            };
            _statusLabel = new Label
            {
                Content                    = _isPaused ? "PAUSED" : "STABLE",
                FontSize                   = 10,
                FontFamily                 = new FontFamily("Segoe UI"),
                FontWeight                 = FontWeights.Bold,
                Foreground                 = _statusFgBrush,
                HorizontalAlignment        = HorizontalAlignment.Center,
                HorizontalContentAlignment = HorizontalAlignment.Center,
                Padding                    = new Thickness(0),
                Effect                     = _statusGlow,
            };

            var textStack = new StackPanel
            {
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment   = VerticalAlignment.Center,
                Margin              = new Thickness(0, -6, 0, 0),
            };
            textStack.Children.Add(_valueLabel);
            textStack.Children.Add(_statusLabel);

            // Carry-debt indicator: shows when previous-session debt is still
            // dissolving (≥ 3 pts).  Font is intentionally small and warm-dim so
            // it does not compete with the primary PSI number.
            _carryDebtLabel = new Label
            {
                Content                    = "",
                FontSize                   = 7,
                FontFamily                 = new FontFamily("Segoe UI"),
                Foreground                 = new SolidColorBrush(Color.FromArgb(200, 255, 200, 100)),
                HorizontalAlignment        = HorizontalAlignment.Center,
                HorizontalContentAlignment = HorizontalAlignment.Center,
                Padding                    = new Thickness(0, 1, 0, 0),
                Visibility                 = Visibility.Collapsed,
            };
            textStack.Children.Add(_carryDebtLabel);

            // Peak-dimension indicator: visible only when collapsed and a signal is active.
            _peakDimLabel = new Label
            {
                Content                    = "",
                FontSize                   = 7,
                FontFamily                 = new FontFamily("Segoe UI"),
                Foreground                 = new SolidColorBrush(Color.FromArgb(200, 255, 149, 0)),
                HorizontalAlignment        = HorizontalAlignment.Center,
                HorizontalContentAlignment = HorizontalAlignment.Center,
                Padding                    = new Thickness(0, 1, 0, 0),
                Visibility                 = Visibility.Collapsed,
            };
            textStack.Children.Add(_peakDimLabel);

            var gaugeHost = new Grid { Width = 150, Height = 150 };
            gaugeHost.Children.Add(gaugeCanvas);
            gaugeHost.Children.Add(textStack);

            var gaugeViewBox = new Viewbox
            {
                Child               = gaugeHost,
                Stretch             = System.Windows.Media.Stretch.Uniform,
                Margin              = new Thickness(8),
                HorizontalAlignment = HorizontalAlignment.Stretch,
                VerticalAlignment   = VerticalAlignment.Stretch,
            };
            Grid.SetRow(gaugeViewBox, 0);
            leftPanel.Children.Add(gaugeViewBox);

            // ── Oversize alarm banner ────────────────────────────────────────
            var oversizeLabel = new Label
            {
                Content                    = "\u26A0  OVERSIZE ALARM",
                FontSize                   = 8.5,
                FontFamily                 = new FontFamily("Segoe UI"),
                FontWeight                 = FontWeights.Bold,
                Foreground                 = new SolidColorBrush(Colors.White),
                HorizontalAlignment        = HorizontalAlignment.Stretch,
                HorizontalContentAlignment = HorizontalAlignment.Center,
                Padding                    = new Thickness(0, 3, 0, 3),
            };
            _oversizeBanner = new Border
            {
                Background = new SolidColorBrush(ColOversize),
                Visibility = Visibility.Collapsed,
                Child      = oversizeLabel,
            };
            Grid.SetRow(_oversizeBanner, 1);
            leftPanel.Children.Add(_oversizeBanner);

            // ── Session stats ────────────────────────────────────────────────
            var statsStack = new StackPanel { Margin = new Thickness(14, 4, 8, 8) };
            statsStack.Children.Add(new Label
            {
                Content    = "SESSION",
                FontSize   = 8,
                FontFamily = new FontFamily("Segoe UI"),
                FontWeight = FontWeights.SemiBold,
                Foreground = FgDim,
                Padding    = new Thickness(0, 0, 0, 2),
            });
            statsStack.Children.Add(new Border
            {
                Height     = 1,
                Background = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255)),
                Margin     = new Thickness(0, 0, 0, 4),
            });

            string[] statKeys = { "Trades", "Win Rate", "Alerts", "Duration" };
            _statTrades   = MakeStatValue("\u2014");
            _statWinRate  = MakeStatValue("\u2014");
            _statAlerts   = MakeStatValue("0");
            _statDuration = MakeStatValue("\u2014");
            Label[] statVals = { _statTrades, _statWinRate, _statAlerts, _statDuration };

            for (int si = 0; si < 4; si++)
            {
                var sRow = new Grid();
                sRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
                sRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
                var kLbl = new Label
                {
                    Content    = statKeys[si],
                    FontSize   = 10,
                    FontFamily = new FontFamily("Segoe UI"),
                    Foreground = FgMuted,
                    Padding    = new Thickness(0, 1, 0, 1),
                };
                Grid.SetColumn(kLbl, 0);         sRow.Children.Add(kLbl);
                Grid.SetColumn(statVals[si], 1); sRow.Children.Add(statVals[si]);
                statsStack.Children.Add(sRow);
            }

            Grid.SetRow(statsStack, 2);
            leftPanel.Children.Add(statsStack);

            // ═════════════════════════════════════════════════════════════════
            // RIGHT PANEL — Timeline Chart + D-Score Bars
            // ═════════════════════════════════════════════════════════════════

            _separator = new Border
            {
                Width               = 1,
                Background          = new SolidColorBrush(Color.FromArgb(25, 255, 255, 255)),
                HorizontalAlignment = HorizontalAlignment.Left,
            };
            Grid.SetColumn(_separator, 1);
            body.Children.Add(_separator);

            _rightPanel = new Grid { Margin = new Thickness(1, 0, 0, 0) };
            _rightPanel.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
            _rightPanel.RowDefinitions.Add(new RowDefinition { Height = new GridLength(140) });
            Grid.SetColumn(_rightPanel, 1);
            body.Children.Add(_rightPanel);

            // ── Timeline chart ───────────────────────────────────────────────
            var tlSection = new Grid { Margin = new Thickness(8, 6, 8, 2) };
            tlSection.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            tlSection.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
            tlSection.RowDefinitions.Add(new RowDefinition { Height = new GridLength(14) });

            tlSection.Children.Add(new Label
            {
                Content    = "PSI TIMELINE",
                FontSize   = 8,
                FontFamily = new FontFamily("Segoe UI"),
                FontWeight = FontWeights.SemiBold,
                Foreground = FgDim,
                Padding    = new Thickness(2, 0, 0, 2),
            });

            _timelineCanvas = new Canvas
            {
                Background   = new SolidColorBrush(Color.FromArgb(12, 255, 255, 255)),
                ClipToBounds = true,
            };

            _zoneBandStable   = new Rectangle { Fill = new SolidColorBrush(Color.FromArgb(20,  48, 209,  88)) };
            _zoneBandCaution  = new Rectangle { Fill = new SolidColorBrush(Color.FromArgb(15, 255, 179,  64)) };
            _zoneBandCritical = new Rectangle { Fill = new SolidColorBrush(Color.FromArgb(15, 255,  69,  58)) };
            _timelineCanvas.Children.Add(_zoneBandCritical);
            _timelineCanvas.Children.Add(_zoneBandCaution);
            _timelineCanvas.Children.Add(_zoneBandStable);

            _gridLine80 = new System.Windows.Shapes.Line
            {
                Stroke          = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255)),
                StrokeThickness = 0.5,
                StrokeDashArray = new DoubleCollection { 4, 3 },
            };
            _gridLine50 = new System.Windows.Shapes.Line
            {
                Stroke          = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255)),
                StrokeThickness = 0.5,
                StrokeDashArray = new DoubleCollection { 4, 3 },
            };
            _timelineCanvas.Children.Add(_gridLine80);
            _timelineCanvas.Children.Add(_gridLine50);

            _timelineLine = new Polyline
            {
                Stroke             = new SolidColorBrush(Color.FromRgb(200, 200, 204)),
                StrokeThickness    = 1.5,
                StrokeLineJoin     = PenLineJoin.Round,
                StrokeStartLineCap = PenLineCap.Round,
                StrokeEndLineCap   = PenLineCap.Round,
            };
            _timelineCanvas.Children.Add(_timelineLine);

            // "Now" cursor — subtle dashed vertical line always pinned to right edge.
            _nowLine = new System.Windows.Shapes.Line
            {
                Stroke           = new SolidColorBrush(Color.FromArgb(90, 255, 255, 255)),
                StrokeThickness  = 1.0,
                StrokeDashArray  = new DoubleCollection { 3, 3 },
                IsHitTestVisible = false,
                Visibility       = Visibility.Collapsed,
            };
            _timelineCanvas.Children.Add(_nowLine);

            _timelineCanvas.SizeChanged += (_, __) => RedrawTimeline();

            Grid.SetRow(_timelineCanvas, 1);
            tlSection.Children.Add(_timelineCanvas);

            var timeAxisGrid = new Grid();
            timeAxisGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            timeAxisGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            timeAxisGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            _timeLblStart = new TextBlock { FontSize = 8, Foreground = FgDim,
                FontFamily = new FontFamily("Segoe UI"), Margin = new Thickness(2, 0, 0, 0) };
            _timeLblMid = new TextBlock { FontSize = 8, Foreground = FgDim,
                FontFamily = new FontFamily("Segoe UI"), HorizontalAlignment = HorizontalAlignment.Center };
            _timeLblEnd = new TextBlock { FontSize = 8, Foreground = FgDim,
                FontFamily = new FontFamily("Segoe UI"), Margin = new Thickness(0, 0, 2, 0) };

            Grid.SetColumn(_timeLblStart, 0); timeAxisGrid.Children.Add(_timeLblStart);
            Grid.SetColumn(_timeLblMid,   1); timeAxisGrid.Children.Add(_timeLblMid);
            Grid.SetColumn(_timeLblEnd,   2); timeAxisGrid.Children.Add(_timeLblEnd);

            Grid.SetRow(timeAxisGrid, 2);
            tlSection.Children.Add(timeAxisGrid);

            Grid.SetRow(tlSection, 0);
            _rightPanel.Children.Add(tlSection);

            // ── D-Score bars ─────────────────────────────────────────────────
            var dSection = new StackPanel { Margin = new Thickness(8, 0, 8, 6) };
            dSection.Children.Add(new Label
            {
                Content    = "BEHAVIORAL SIGNALS",
                FontSize   = 8,
                FontFamily = new FontFamily("Segoe UI"),
                FontWeight = FontWeights.SemiBold,
                Foreground = FgDim,
                Padding    = new Thickness(2, 0, 0, 4),
            });

            for (int di = 0; di < 7; di++)
            {
                _dBarBrushes[di] = new SolidColorBrush(ColStable);

                var barRow = new Grid
                {
                    Margin  = new Thickness(0, 1, 0, 1),
                    ToolTip = DimTooltips[di],
                };
                barRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(58) });
                barRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
                barRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(36) });

                var dimLbl = new Label
                {
                    Content           = DimNames[di],
                    FontSize          = 9,
                    FontFamily        = new FontFamily("Segoe UI"),
                    Foreground        = FgMuted,
                    Padding           = new Thickness(0),
                    VerticalAlignment = VerticalAlignment.Center,
                };

                var track = new Grid { Margin = new Thickness(4, 0, 4, 0) };
                _dBarTracks[di] = track;

                track.Children.Add(new Border
                {
                    Height            = 8,
                    CornerRadius      = new CornerRadius(4),
                    Background        = new SolidColorBrush(Color.FromArgb(25, 255, 255, 255)),
                    VerticalAlignment = VerticalAlignment.Center,
                });

                var fill = new Border
                {
                    Height              = 8,
                    CornerRadius        = new CornerRadius(4),
                    Background          = _dBarBrushes[di],
                    HorizontalAlignment = HorizontalAlignment.Left,
                    VerticalAlignment   = VerticalAlignment.Center,
                    Width               = 0,
                };
                _dBarFills[di] = fill;
                track.Children.Add(fill);

                // Knob dot — white circle that sits at the right edge of the fill,
                // like a scrubber handle.  Hidden when the bar is empty.
                var dot = new Ellipse
                {
                    Width               = 10,
                    Height              = 10,
                    Fill                = new SolidColorBrush(Color.FromArgb(220, 255, 255, 255)),
                    HorizontalAlignment = HorizontalAlignment.Left,
                    VerticalAlignment   = VerticalAlignment.Center,
                    IsHitTestVisible    = false,
                    Visibility          = Visibility.Collapsed,
                };
                _dBarDots[di] = dot;
                track.Children.Add(dot);

                var valLbl = new Label
                {
                    Content                    = "0.00",
                    FontSize                   = 9,
                    FontFamily                 = new FontFamily("Segoe UI"),
                    Foreground                 = FgMuted,
                    Padding                    = new Thickness(0),
                    HorizontalContentAlignment = HorizontalAlignment.Right,
                    VerticalAlignment          = VerticalAlignment.Center,
                };
                _dBarValues[di] = valLbl;

                Grid.SetColumn(dimLbl,  0); barRow.Children.Add(dimLbl);
                Grid.SetColumn(track,   1); barRow.Children.Add(track);
                Grid.SetColumn(valLbl,  2); barRow.Children.Add(valLbl);

                dSection.Children.Add(barRow);
            }

            var dBorder = new Border { Child = dSection };
            Grid.SetRow(dBorder, 1);
            _rightPanel.Children.Add(dBorder);

            _rightPanel.SizeChanged += (_, __) => RedrawDScoreBars();

            Content = root;

            // ── Animation timer (30 fps) ─────────────────────────────────────
            _animTimer       = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(33) };
            _animTimer.Tick += OnAnimTick;
            _animTimer.Start();
            Closed += (_, __) => { _animTimer.Stop(); SaveLayout(); };
            Loaded += (_, __) => LoadLayout();
        }

        // ── Arc geometry helpers ─────────────────────────────────────────────

        /// <summary>
        /// Builds a coloured background arc spanning the PSI range [startPsi, endPsi]
        /// at low opacity.  Used to render the four zone bands on the gauge track.
        /// </summary>
        private static Path BuildZoneArc(double startPsi, double endPsi, Color zoneColor)
        {
            double startSweep = GaugeSweepDeg * startPsi / 100.0;
            double endSweep   = GaugeSweepDeg * endPsi   / 100.0;
            double arcSweep   = endSweep - startSweep;
            if (arcSweep < 0.1) arcSweep = 0.1;

            double sRad = (GaugeStartDeg + startSweep) * Math.PI / 180.0;
            double eRad = (GaugeStartDeg + endSweep - 0.01) * Math.PI / 180.0;

            var sPt = new Point(GaugeCx + GaugeR * Math.Cos(sRad), GaugeCy + GaugeR * Math.Sin(sRad));
            var ePt = new Point(GaugeCx + GaugeR * Math.Cos(eRad), GaugeCy + GaugeR * Math.Sin(eRad));
            var seg = new ArcSegment
            {
                Point           = ePt,
                Size            = new Size(GaugeR, GaugeR),
                IsLargeArc      = arcSweep > 180.0,
                SweepDirection  = SweepDirection.Clockwise,
            };
            var fig = new PathFigure { StartPoint = sPt, IsClosed = false };
            fig.Segments.Add(seg);
            var geo = new PathGeometry();
            geo.Figures.Add(fig);

            return new Path
            {
                Stroke             = new SolidColorBrush(Color.FromArgb(0x22, zoneColor.R, zoneColor.G, zoneColor.B)),
                StrokeThickness    = GaugeStroke,
                StrokeStartLineCap = PenLineCap.Flat,
                StrokeEndLineCap   = PenLineCap.Flat,
                Fill               = Brushes.Transparent,
                Data               = geo,
            };
        }

        private void SetProgressArc(double psi)
        {
            double sweep = GaugeSweepDeg * Math.Max(0.0, Math.Min(100.0, psi)) / 100.0;
            if (sweep < 0.5)
            {
                _gaugeProgress.Visibility = Visibility.Collapsed;
                if (_arcTipDot != null) _arcTipDot.Visibility = Visibility.Collapsed;
                return;
            }
            _gaugeProgress.Visibility = Visibility.Visible;
            double eRad = (GaugeStartDeg + sweep) * Math.PI / 180.0;
            double tipX = GaugeCx + GaugeR * Math.Cos(eRad);
            double tipY = GaugeCy + GaugeR * Math.Sin(eRad);
            _progressArc.Point      = new Point(tipX, tipY);
            _progressArc.IsLargeArc = sweep > 180.0;

            if (_arcTipDot != null)
            {
                Canvas.SetLeft(_arcTipDot, tipX - 6.5);
                Canvas.SetTop (_arcTipDot, tipY - 6.5);
                _arcTipDot.Visibility = Visibility.Visible;
            }
        }

        // ── Public API ───────────────────────────────────────────────────────

        public void UpdatePsi(double value, bool isFromFill = false)
        {
            value = Math.Max(0, Math.Min(100, value));
            if (!Dispatcher.CheckAccess())
            {
                Dispatcher.InvokeAsync(() => UpdatePsi(value, isFromFill));
                return;
            }
            if (_isPaused) return;
            // Only start the session clock on the first real fill (entry or exit).
            // Timer-driven PSI updates (PollPositions every 30 s) must not start
            // the clock — the user hasn't started trading yet and Duration should
            // show "--" until the first actual fill arrives.
            if (_sessionStartTime == DateTime.MinValue && isFromFill)
                _sessionStartTime = DateTime.Now;
            if (value < _targetPsi - 5.0)
                _pulseIntensity = 1.0;
            _targetPsi = value;
            AddToHistory(DateTime.Now, value);
        }

        public void UpdateOverExposed(bool overExposed)
        {
            if (!Dispatcher.CheckAccess())
            {
                Dispatcher.InvokeAsync(() => UpdateOverExposed(overExposed));
                return;
            }
            if (_overExposed == overExposed) return;
            _overExposed = overExposed;
            _oversizeBanner.Visibility = overExposed ? Visibility.Visible : Visibility.Collapsed;
            if (overExposed && !_isPaused)
            {
                _statusLabel.Content  = "OVERSIZE";
                _statusFgBrush.Color  = ColOversize;
            }
            else if (!_isPaused)
            {
                ApplyDisplay(_displayedPsi);
            }
        }

        public void UpdateDScores(double d1, double d2, double d3,
                                   double d4, double d5, double d6, double d7)
        {
            if (!Dispatcher.CheckAccess())
            {
                Dispatcher.InvokeAsync(() => UpdateDScores(d1, d2, d3, d4, d5, d6, d7));
                return;
            }
            // Values are EWMA PSI-debt in PSI points (0-100).
            _dBarTargets[0] = d1; _dBarTargets[1] = d2; _dBarTargets[2] = d3;
            _dBarTargets[3] = d4; _dBarTargets[4] = d5; _dBarTargets[5] = d6;
            _dBarTargets[6] = d7;
        }

        public void UpdateSessionStats(int totalTrades, int winTrades, int alertsFired)
        {
            if (!Dispatcher.CheckAccess())
            {
                Dispatcher.InvokeAsync(() => UpdateSessionStats(totalTrades, winTrades, alertsFired));
                return;
            }
            _statTrades.Content  = totalTrades > 0 ? totalTrades.ToString() : "\u2014";
            _statWinRate.Content = totalTrades > 0
                ? ((int)(100.0 * winTrades / totalTrades)).ToString() + "%"
                : "\u2014";
            _statAlerts.Content = alertsFired.ToString();

            if (_sessionStartTime != DateTime.MinValue)
            {
                var dur = DateTime.Now - _sessionStartTime;
                _statDuration.Content = dur.TotalHours >= 1.0
                    ? string.Format("{0}h{1:D2}m", (int)dur.TotalHours, dur.Minutes)
                    : string.Format("{0}m", Math.Max(1, (int)dur.TotalMinutes));
            }
            else
            {
                _statDuration.Content = "\u2014";
            }
        }

        /// <summary>
        /// Shows or hides the carry-debt indicator below the STABLE/CAUTION label.
        /// Only visible when the previous session's debt is still non-negligible
        /// (≥ 3 PSI points), letting the trader distinguish behavioral recovery
        /// from passive overnight-debt dissolution.
        /// </summary>
        public void UpdateCarryDebt(double carryDebt)
        {
            if (!Dispatcher.CheckAccess())
            {
                Dispatcher.InvokeAsync(() => UpdateCarryDebt(carryDebt));
                return;
            }
            if (carryDebt >= 3.0)
            {
                _carryDebtLabel.Content    = string.Format("\u2191{0:F0}pt yest", carryDebt);
                _carryDebtLabel.Visibility = Visibility.Visible;
            }
            else
            {
                _carryDebtLabel.Visibility = Visibility.Collapsed;
            }
        }

        /// <summary>
        /// Shows the name of the highest-active behavioral dimension below the
        /// PSI value when the right panel is collapsed.  Hidden when expanded
        /// (the full D-score bars are visible) or when all debts are negligible.
        /// Threshold: 1 PSI point — any visible bar should show a label hint.
        /// </summary>
        public void UpdatePeakDimLabel(double[] debts)
        {
            if (!Dispatcher.CheckAccess())
            {
                Dispatcher.InvokeAsync(() => UpdatePeakDimLabel(debts));
                return;
            }
            if (_expanded)
            {
                _peakDimLabel.Visibility = Visibility.Collapsed;
                return;
            }
            int maxIdx = 0;
            for (int i = 1; i < 7; i++)
                if (debts[i] > debts[maxIdx]) maxIdx = i;
            if (debts[maxIdx] >= 1.0)
            {
                _peakDimLabel.Content    = string.Format("\u25b2 {0}", DimNames[maxIdx]);
                _peakDimLabel.Visibility = Visibility.Visible;
            }
            else
            {
                _peakDimLabel.Visibility = Visibility.Collapsed;
            }
        }

        /// <summary>
        /// Updates the header badge to reflect baseline recording status.
        /// Pass the suspend reason ("SIM", "PLAYBACK", "TEST") or null for live.
        /// When live and baseline is still immature, pass "LEARNING" from the caller.
        /// </summary>
        public void UpdateBaselineStatus(string reason)
        {
            if (!Dispatcher.CheckAccess())
            {
                Dispatcher.InvokeAsync(() => UpdateBaselineStatus(reason));
                return;
            }

            _baselineBadge.Visibility = Visibility.Visible;

            Color bg, fg;
            string text;
            bool autoDetected;

            switch (reason)
            {
                case "SIM":
                    bg = Color.FromRgb(255, 214, 10);
                    fg = Color.FromRgb(30, 30, 30);
                    text = "SIM"; autoDetected = true;
                    break;
                case "PLAYBACK":
                    bg = Color.FromRgb(10, 132, 255);
                    fg = Color.FromRgb(255, 255, 255);
                    text = "PLAYBACK"; autoDetected = true;
                    break;
                case "TEST":
                    bg = Color.FromRgb(255, 159, 10);
                    fg = Color.FromRgb(30, 30, 30);
                    text = "TEST"; autoDetected = false;
                    break;
                case "LEARNING":
                    bg = Color.FromRgb(100, 100, 105);
                    fg = Color.FromRgb(200, 200, 200);
                    text = "LEARNING"; autoDetected = false;
                    break;
                default:
                    bg = Color.FromRgb(48, 209, 88);
                    fg = Color.FromRgb(20, 20, 20);
                    text = "REC"; autoDetected = false;
                    break;
            }

            _badgeIsAutoDetected        = autoDetected;
            _baselineBadgeText.Text     = text;
            _baselineBadge.Background   = new SolidColorBrush(bg);
            _baselineBadgeText.Foreground = new SolidColorBrush(fg);
            _baselineBadge.Cursor       = autoDetected ? Cursors.Arrow : Cursors.Hand;
            _baselineBadge.ToolTip      = autoDetected
                ? "Auto-detected — recording paused"
                : (text == "TEST"
                    ? "Click to resume recording"
                    : "Click to pause baseline recording (Test Mode)");
        }

        // ── Timeline helpers ─────────────────────────────────────────────────

        private void AddToHistory(DateTime time, double psi)
        {
            while (_psiHistory.Count >= TimelineMaxPts) _psiHistory.Dequeue();
            _psiHistory.Enqueue(new PsiPoint { T = time, V = psi });
            if (_expanded) RedrawTimeline();
        }

        private void RedrawTimeline()
        {
            if (_timelineCanvas == null || _timelineLine == null) return;
            double w = _timelineCanvas.ActualWidth;
            double h = _timelineCanvas.ActualHeight;
            if (w < 10 || h < 10) return;

            double y80 = (1.0 - ZoneStable  / 100.0) * h;
            double y50 = (1.0 - ZoneWarning / 100.0) * h;

            Canvas.SetLeft(_zoneBandStable,   0); Canvas.SetTop(_zoneBandStable,   0);
            _zoneBandStable.Width   = w; _zoneBandStable.Height   = y80;
            Canvas.SetLeft(_zoneBandCaution,  0); Canvas.SetTop(_zoneBandCaution,  y80);
            _zoneBandCaution.Width  = w; _zoneBandCaution.Height  = y50 - y80;
            Canvas.SetLeft(_zoneBandCritical, 0); Canvas.SetTop(_zoneBandCritical, y50);
            _zoneBandCritical.Width = w; _zoneBandCritical.Height = h - y50;
            _gridLine80.X1 = 0; _gridLine80.X2 = w; _gridLine80.Y1 = y80; _gridLine80.Y2 = y80;
            _gridLine50.X1 = 0; _gridLine50.X2 = w; _gridLine50.Y1 = y50; _gridLine50.Y2 = y50;

            var arr = _psiHistory.ToArray();
            int n   = arr.Length;

            // ── Time-mapped X axis (right edge = now, everything scrolls left) ──
            // Span: at least 60 s, or from session start to now.
            DateTime tNow   = DateTime.Now;
            DateTime tStart = _sessionStartTime != DateTime.MinValue
                ? _sessionStartTime
                : (n > 0 ? arr[0].T : tNow - TimeSpan.FromSeconds(60));
            double spanSec  = Math.Max(60.0, (tNow - tStart).TotalSeconds);

            if (n < 1)
            {
                _timelineLine.Points = new PointCollection();
                _nowLine.Visibility  = Visibility.Collapsed;
                return;
            }

            var pts = new PointCollection(n + 1);
            for (int i = 0; i < n; i++)
            {
                double x = (arr[i].T - tStart).TotalSeconds / spanSec * w;
                double y = (1.0 - arr[i].V / 100.0) * h;
                pts.Add(new Point(Math.Max(0.0, x), y));
            }
            // Extend flat line to the right edge (= "now"), so the chart always
            // touches the right margin even when PSI hasn't changed.
            pts.Add(new Point(w, (1.0 - arr[n - 1].V / 100.0) * h));
            _timelineLine.Points = pts;

            // "Now" cursor line — pinned to right edge.
            _nowLine.X1 = w - 0.5; _nowLine.X2 = w - 0.5;
            _nowLine.Y1 = 0;       _nowLine.Y2 = h;
            _nowLine.Visibility = Visibility.Visible;

            // Time labels — hide duplicates when session span is too short for distinct marks.
            string lblStart = tStart.ToString("HH:mm");
            string lblMid   = (tStart + TimeSpan.FromSeconds(spanSec / 2)).ToString("HH:mm");
            string lblEnd   = tNow.ToString("HH:mm");

            _timeLblEnd.Text = lblEnd;
            _timeLblStart.Text       = lblStart;
            _timeLblStart.Visibility = lblStart == lblEnd
                ? Visibility.Hidden : Visibility.Visible;
            _timeLblMid.Text         = lblMid;
            _timeLblMid.Visibility   = lblMid == lblEnd || lblMid == lblStart
                ? Visibility.Hidden : Visibility.Visible;
        }

        // ── D-Score bar helpers ──────────────────────────────────────────────

        private void RedrawDScoreBars()
        {
            for (int i = 0; i < 7; i++)
            {
                // _curD[i] is in PSI-point units (0–100).
                double debt   = Math.Max(0.0, Math.Min(100.0, _curD[i]));
                double trackW = _dBarTracks[i].ActualWidth;

                // Bar fill: fraction of the 100-pt PSI scale.
                double fillW = 0;
                if (trackW > 1)
                {
                    fillW = (debt / 100.0) * trackW;
                    _dBarFills[i].Width = fillW;
                }

                // Label: show the PSI-point deficit (negative = cost to PSI).
                _dBarValues[i].Content = debt < 0.05 ? "0"
                    : string.Format("-{0:F1}", debt);

                // Color: same PsiColor function as the gauge, mapping the
                // equivalent PSI value if this dimension alone were the cause.
                // debt=0 → PsiColor(100)=green; debt=30 → PsiColor(70)=yellow;
                // debt=50 → PsiColor(50)=orange-red.
                _dBarBrushes[i].Color = PsiColor(100.0 - debt);

                // Knob dot — pinned to the right edge of the fill.
                if (debt < 0.05 || trackW < 1)
                {
                    _dBarDots[i].Visibility = Visibility.Collapsed;
                }
                else
                {
                    _dBarDots[i].Margin     = new Thickness(fillW - 5.0, 0, 0, 0);
                    _dBarDots[i].Visibility = Visibility.Visible;
                }
            }
        }

        // ── Panel toggle ─────────────────────────────────────────────────────

        private void TogglePanel()
        {
            _expanded = !_expanded;
            _rightPanel.Visibility = _expanded ? Visibility.Visible : Visibility.Collapsed;
            _separator.Visibility  = _expanded ? Visibility.Visible : Visibility.Collapsed;

            if (_expanded)
            {
                _rightCol.Width = new GridLength(1, GridUnitType.Star);
                Width    = _expandedWidth;
                MinWidth = 420;
                _panelToggleBtn.Content  = "\u25C0";
                _panelToggleBtn.ToolTip  = "Collapse panel";
                _peakDimLabel.Visibility = Visibility.Collapsed; // D-bars now visible
                RedrawTimeline();
                RedrawDScoreBars();
            }
            else
            {
                _expandedWidth = Width;
                _rightCol.Width = new GridLength(0);
                Width    = CollapsedW;
                MinWidth = CollapsedW;
                _panelToggleBtn.Content = "\u25B6";
                _panelToggleBtn.ToolTip = "Expand panel";
            }
        }

        // ── Monitoring state ─────────────────────────────────────────────────

        public void SetMonitoringState(bool isOn)
        {
            if (!Dispatcher.CheckAccess())
            {
                Dispatcher.InvokeAsync(() => SetMonitoringState(isOn));
                return;
            }
            _isPaused = !isOn;
            UpdatePillVisuals();
            if (_isPaused)
                ApplyPausedDisplay();
            else
                ApplyDisplay(_displayedPsi);
        }

        private void OnPillClicked(object sender, MouseButtonEventArgs e)
        {
            e.Handled = true;
            _isPaused = !_isPaused;
            UpdatePillVisuals();
            if (_isPaused)
                ApplyPausedDisplay();
            else
                ApplyDisplay(_displayedPsi);
            MonitoringToggled?.Invoke(!_isPaused);
        }

        private void UpdatePillVisuals()
        {
            bool isOn                      = !_isPaused;
            _monitorPill.Background        = isOn ? PillOnBrush : PillOffBrush;
            _pillDot.HorizontalAlignment   = isOn ? HorizontalAlignment.Right : HorizontalAlignment.Left;
            _pillDot.Margin                = isOn ? new Thickness(0, 0, 2, 0) : new Thickness(2, 0, 0, 0);
            _monitorPill.ToolTip           = isOn
                ? "Monitoring ON \u2014 click to pause"
                : "Monitoring PAUSED \u2014 click to resume";
        }

        // ── Layout persistence ────────────────────────────────────────────────

        private static string LayoutFilePath => System.IO.Path.Combine(
            NinjaTrader.Core.Globals.UserDataDir,
            "AddOns", "PsiMonitorLayout.dat");

        private void SaveLayout()
        {
            try
            {
                System.IO.Directory.CreateDirectory(
                    System.IO.Path.GetDirectoryName(LayoutFilePath));
                // Field 6 (expandedWidth): saves the intended expanded-panel width so it
                // survives a close-while-collapsed → reopen cycle without corruption.
                System.IO.File.WriteAllText(LayoutFilePath,
                    string.Format(
                        System.Globalization.CultureInfo.InvariantCulture,
                        "{0} {1} {2} {3} {4} {5}",
                        (int)Left, (int)Top, (int)Width, (int)Height, _expanded,
                        (int)_expandedWidth));
            }
            catch { /* non-critical — silent fail */ }
        }

        private void LoadLayout()
        {
            try
            {
                if (!System.IO.File.Exists(LayoutFilePath)) return;
                var parts = System.IO.File.ReadAllText(LayoutFilePath)
                    .Trim().Split(' ');
                if (parts.Length < 5) return;

                var ci = System.Globalization.CultureInfo.InvariantCulture;
                double left     = double.Parse(parts[0], ci);
                double top      = double.Parse(parts[1], ci);
                double width    = double.Parse(parts[2], ci);
                double height   = double.Parse(parts[3], ci);
                bool   expanded = bool.Parse(parts[4]);

                // Field 6: expanded-panel width (added later; fall back to ExpandedW
                // for layouts saved by an older build that omits this field).
                double savedExpandedW = parts.Length >= 6
                    ? double.Parse(parts[5], ci)
                    : ExpandedW;

                // Clamp so the window is visible on the virtual screen (spans all monitors).
                // Using VirtualScreen instead of WorkArea prevents a HUD saved on a secondary
                // monitor from being snapped to the primary monitor after a display change.
                double vsLeft   = SystemParameters.VirtualScreenLeft;
                double vsTop    = SystemParameters.VirtualScreenTop;
                double vsRight  = vsLeft + SystemParameters.VirtualScreenWidth;
                double vsBottom = vsTop  + SystemParameters.VirtualScreenHeight;
                left          = Math.Max(vsLeft,    Math.Min(left,          vsRight  - 80));
                top           = Math.Max(vsTop,     Math.Min(top,           vsBottom - 40));
                width         = Math.Max(CollapsedW, Math.Min(width,        SystemParameters.VirtualScreenWidth));
                height        = Math.Max(200,        Math.Min(height,       SystemParameters.VirtualScreenHeight));
                savedExpandedW = Math.Max(ExpandedW, Math.Min(savedExpandedW, SystemParameters.VirtualScreenWidth));

                Left   = left;
                Top    = top;
                Height = height;

                // Restore _expandedWidth BEFORE touching Width or calling TogglePanel.
                // Without this, TogglePanel's "_expandedWidth = Width" capture would
                // record CollapsedW (220) as the expanded width when loading a collapsed
                // layout, causing every subsequent expand to produce a 220 px window.
                _expandedWidth = savedExpandedW;

                if (expanded != _expanded)
                {
                    // Put Width at the correct expanded value so TogglePanel's
                    // "_expandedWidth = Width" read returns the right number,
                    // then let TogglePanel set Width to CollapsedW itself.
                    Width = _expandedWidth;
                    TogglePanel();
                }
                else
                {
                    Width = expanded ? savedExpandedW : CollapsedW;
                }
            }
            catch { /* non-critical — silent fail */ }
        }

        // ── Animation ────────────────────────────────────────────────────────

        private void OnAnimTick(object sender, EventArgs e)
        {
            if (_isPaused) return;

            // Smooth PSI number toward target.
            double diff = _targetPsi - _displayedPsi;
            if (Math.Abs(diff) < 0.05)
                _displayedPsi = _targetPsi;
            else
                _displayedPsi += diff * (diff < 0 ? 0.12 : 0.06);

            // Decay violation pulse (τ ≈ 8 frames ≈ 265ms).
            if (_pulseIntensity > 0.005)
                _pulseIntensity *= 0.88;
            else
                _pulseIntensity = 0.0;

            // ── Arc tip dot pulse (A) ─────────────────────────────────────────
            // Opacity only — no blur, no geometry shift → zero eye strain.
            // Rate tracks PSI zone: slow=calm, faster=stressed.
            double targetTipRate = _displayedPsi >= ZoneStable  ? 0.070   // ~3.0 s
                                 : _displayedPsi >= ZoneCaution ? 0.084   // ~2.5 s
                                 : _displayedPsi >= ZoneWarning ? 0.105   // ~2.0 s
                                 : 0.126;                                  // ~1.7 s
            _tipRate  = _tipRate  + (targetTipRate - _tipRate) * 0.01;
            _tipPhase = (_tipPhase + _tipRate) % (2.0 * Math.PI);
            _arcTipDot.Opacity = 0.72 + ((Math.Sin(_tipPhase) + 1.0) * 0.5) * 0.23; // 0.72..0.95

            // ── Radar pulse ring ──────────────────────────────────────────────
            // _ringPhase ∈ [0..1).  First 35% = ring expands and fades.
            // Remaining 65% = silence (ring hidden) — gives a heartbeat-pause rhythm.
            // Cycle rate tracks PSI zone: 4 s at STABLE → 1.5 s at CRITICAL.
            double targetRingRate = _displayedPsi >= ZoneStable  ? 1.0 / (4.0 * 30.0)
                                  : _displayedPsi >= ZoneCaution ? 1.0 / (3.0 * 30.0)
                                  : _displayedPsi >= ZoneWarning ? 1.0 / (2.2 * 30.0)
                                  : 1.0 / (1.5 * 30.0);
            _ringRate  = _ringRate + (targetRingRate - _ringRate) * 0.01;
            _ringPhase = (_ringPhase + _ringRate) % 1.0;

            const double ActiveFraction = 0.38;    // 38% of cycle = ring visible
            const double RingStartR     = 8.0;     // ring emits from the PSI number area
            const double RingEndR       = GaugeR + 30.0; // expands well past the arc edge
            if (_ringPhase < ActiveFraction)
            {
                double t = _ringPhase / ActiveFraction;          // 0 → 1 within active phase
                double r = RingStartR + t * (RingEndR - RingStartR);
                _pulseRing.Width   = 2.0 * r;
                _pulseRing.Height  = 2.0 * r;
                Canvas.SetLeft(_pulseRing, GaugeCx - r);
                Canvas.SetTop (_pulseRing, GaugeCy - r);
                _pulseRing.Opacity = (1.0 - t) * 0.70;          // 0.70 → 0  (blur eats some opacity)
            }
            else
            {
                _pulseRing.Opacity = 0.0;
            }

            // ── Timeline heartbeat (B) ────────────────────────────────────────
            // Periodically redraw so the time axis and "now" line advance even
            // when PSI hasn't changed (right edge = now, always).
            if (_expanded)
            {
                _heartbeatCounter++;
                if (_heartbeatCounter >= HeartbeatInterval)
                {
                    _heartbeatCounter = 0;
                    RedrawTimeline();
                }
            }

            // Lerp D-score bars toward their targets (τ ≈ 6 frames ≈ 200ms).
            // Targets are now in PSI-point units (0–100); threshold scaled accordingly.
            bool anyBarChanged = false;
            for (int i = 0; i < 7; i++)
            {
                double bd = _dBarTargets[i] - _curD[i];
                if (Math.Abs(bd) < 0.2)
                    _curD[i] = _dBarTargets[i];
                else
                {
                    _curD[i] += bd * 0.15;
                    anyBarChanged = true;
                }
            }
            if (anyBarChanged || _pulseIntensity > 0.0)
                RedrawDScoreBars();

            ApplyDisplay(_displayedPsi);
        }

        private void ApplyDisplay(double psi)
        {
            Color  c = PsiColor(psi);
            string status;
            Color  statusColor;
            if (_overExposed)
            {
                status      = "OVERSIZE";
                statusColor = ColOversize;
            }
            else
            {
                status      = psi >= ZoneStable  ? "STABLE"
                            : psi >= ZoneCaution ? "CAUTION"
                            : psi >= ZoneWarning ? "WARNING"
                            : "CRITICAL";
                statusColor = c;
            }

            // Show one decimal place while animating fast; integer when settled.
            _valueLabel.Content = Math.Abs(_targetPsi - _displayedPsi) > 3.0
                ? _displayedPsi.ToString("F1")
                : ((int)Math.Round(_displayedPsi)).ToString();

            _valueFgBrush.Color   = c;
            _statusLabel.Content  = status;
            _statusFgBrush.Color  = statusColor;
            _progressStroke.Color = c;
            _progressGlow.Color   = c;
            _arcTipGlow.Color     = c;   // dot halo tracks arc color
            _pulseRingBrush.Color = c;   // ring tracks arc color

            // Dynamic glow: intensity scales with PSI severity + violation pulse.
            double baseBlur, baseOpacity;
            if      (psi >= ZoneStable)  { baseBlur = 10; baseOpacity = 0.60; }
            else if (psi >= ZoneCaution) { baseBlur = 14; baseOpacity = 0.75; }
            else if (psi >= ZoneWarning) { baseBlur = 20; baseOpacity = 0.90; }
            else                         { baseBlur = 26; baseOpacity = 1.00; }

            _progressGlow.BlurRadius = baseBlur   + _pulseIntensity * 14.0;
            _progressGlow.Opacity    = Math.Min(1.0, baseOpacity + _pulseIntensity * 0.25);
            _statusGlow.Color        = c;
            _statusGlow.BlurRadius   = baseBlur * 0.55;
            _statusGlow.Opacity      = Math.Min(1.0, baseOpacity + _pulseIntensity * 0.15);

            SetProgressArc(psi);
        }

        private void ApplyPausedDisplay()
        {
            _valueLabel.Content       = "\u2014";
            _valueFgBrush.Color       = ColPaused;
            _statusLabel.Content      = "PAUSED";
            _statusFgBrush.Color      = ColPaused;
            _progressStroke.Color     = ColPaused;
            _progressGlow.Color       = ColPaused;
            SetProgressArc(100);
            _gaugeProgress.Visibility = Visibility.Visible;
        }

        // ── Colour helpers ───────────────────────────────────────────────────

        private static Color PsiColor(double psi)
        {
            // 4-zone gradient matching the label thresholds above.
            // Each zone blends smoothly into the next.
            if (psi >= ZoneStable)  return LerpColor(ColCaution,  ColStable,  (psi - ZoneStable)  / (100.0 - ZoneStable));
            if (psi >= ZoneCaution) return LerpColor(ColWarning,  ColCaution, (psi - ZoneCaution) / (ZoneStable  - ZoneCaution));
            if (psi >= ZoneWarning) return LerpColor(ColCritical, ColWarning, (psi - ZoneWarning) / (ZoneCaution - ZoneWarning));
            return ColCritical;
        }

        private static Color LerpColor(Color a, Color b, double t)
        {
            t = t < 0 ? 0 : t > 1 ? 1 : t;
            return Color.FromRgb(
                (byte)(a.R + (b.R - a.R) * t),
                (byte)(a.G + (b.G - a.G) * t),
                (byte)(a.B + (b.B - a.B) * t));
        }

        // DScoreColor(score) has been removed.  The D-bar brushes now use
        // PsiColor(100 - debt) so that bar color and PSI gauge color share
        // a single, consistent colour function.  No independent colour scale.

        // ── Factory helpers ──────────────────────────────────────────────────

        private static Label MakeHdrBtn(string text, string tip)
        {
            var lbl = new Label
            {
                Content                    = text,
                FontSize                   = 12,
                Width                      = 24,
                Foreground                 = new SolidColorBrush(Color.FromRgb(142, 142, 147)),
                HorizontalContentAlignment = HorizontalAlignment.Center,
                VerticalContentAlignment   = VerticalAlignment.Center,
                Padding                    = new Thickness(0),
                Cursor                     = Cursors.Hand,
                ToolTip                    = tip,
            };
            lbl.MouseEnter += (_, __) => lbl.Foreground = new SolidColorBrush(Color.FromRgb(188, 188, 192));
            lbl.MouseLeave += (_, __) => lbl.Foreground = new SolidColorBrush(Color.FromRgb(142, 142, 147));
            return lbl;
        }

        private static Label MakeStatValue(string initial)
        {
            return new Label
            {
                Content                    = initial,
                FontSize                   = 10,
                FontFamily                 = new FontFamily("Segoe UI"),
                FontWeight                 = FontWeights.SemiBold,
                Foreground                 = FgBright,
                Padding                    = new Thickness(0, 1, 0, 1),
                HorizontalContentAlignment = HorizontalAlignment.Right,
            };
        }
    }

    // =========================================================================
    // Alert toast  —  small transient popup, auto-dismisses after 7 seconds
    // =========================================================================

    internal sealed class AlertToastWindow : Window
    {
        // ── Win32: prevent this window from stealing focus ────────────────────
        // WS_EX_NOACTIVATE ensures the toast never becomes the active window,
        // so SuperDOM hotkeys keep working even when an alert fires.
        [System.Runtime.InteropServices.DllImport("user32.dll")]
        private static extern int GetWindowLong(IntPtr hwnd, int nIndex);
        [System.Runtime.InteropServices.DllImport("user32.dll")]
        private static extern int SetWindowLong(IntPtr hwnd, int nIndex, int dwNewLong);

        protected override void OnSourceInitialized(EventArgs e)
        {
            base.OnSourceInitialized(e);
            var hwnd = new System.Windows.Interop.WindowInteropHelper(this).Handle;
            // Add WS_EX_NOACTIVATE (0x08000000) so Windows never activates this window.
            SetWindowLong(hwnd, -20 /*GWL_EXSTYLE*/,
                GetWindowLong(hwnd, -20) | 0x08000000);
            // Also intercept WM_MOUSEACTIVATE so clicking the toast doesn't activate it.
            System.Windows.Interop.HwndSource.FromHwnd(hwnd)?.AddHook(NoActivateHook);
        }

        private static IntPtr NoActivateHook(IntPtr hwnd, int msg, IntPtr wParam,
                                              IntPtr lParam, ref bool handled)
        {
            if (msg == 0x0021 /*WM_MOUSEACTIVATE*/)
            {
                handled = true;
                return new IntPtr(3 /*MA_NOACTIVATE*/);
            }
            return IntPtr.Zero;
        }

        private readonly DispatcherTimer _timer;

        public AlertToastWindow(string message, bool isCritical)
        {
            WindowStyle        = WindowStyle.None;
            AllowsTransparency = true;
            Background         = Brushes.Transparent;
            Topmost            = true;
            ShowInTaskbar      = false;
            ShowActivated      = false;   // never steal focus from SuperDOM / hotkeys
            ResizeMode         = ResizeMode.NoResize;
            Width              = 270;
            Height             = 72;

            // Position: top-right corner, above HUD (which sits at WorkArea.Top + 20)
            Left = SystemParameters.WorkArea.Right - Width - 20;
            Top  = SystemParameters.WorkArea.Top   + 20;

            Color accent = isCritical
                ? Color.FromRgb(255, 69, 58)
                : Color.FromRgb(255, 214, 0);

            var card = new Border
            {
                CornerRadius    = new CornerRadius(10),
                Background      = new SolidColorBrush(Color.FromArgb(245, 28, 28, 30)),
                BorderBrush     = new SolidColorBrush(Color.FromArgb(160, accent.R, accent.G, accent.B)),
                BorderThickness = new Thickness(1),
                ClipToBounds    = true,
            };

            var root = new Grid();
            root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(26) });
            root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });

            // ── Coloured header strip ──────────────────────────────────────────
            var hdr     = new Border { Background = new SolidColorBrush(Color.FromArgb(200, accent.R, accent.G, accent.B)) };
            var hdrRow  = new Grid();
            hdrRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            hdrRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            var titleLbl = new Label
            {
                Content                  = isCritical ? "⚠  PSI CRITICAL" : "⚡  PSI CAUTION",
                FontSize                 = 10,
                FontFamily               = new FontFamily("Segoe UI"),
                FontWeight               = FontWeights.SemiBold,
                Foreground               = Brushes.White,
                VerticalContentAlignment = VerticalAlignment.Center,
                Padding                  = new Thickness(10, 0, 0, 0),
            };
            var clsBtn = new Label
            {
                Content                    = "✕",
                FontSize                   = 10,
                Width                      = 26,
                Foreground                 = new SolidColorBrush(Color.FromArgb(180, 255, 255, 255)),
                HorizontalContentAlignment = HorizontalAlignment.Center,
                VerticalContentAlignment   = VerticalAlignment.Center,
                Padding                    = new Thickness(0),
                Cursor                     = Cursors.Hand,
            };
            clsBtn.MouseLeftButtonDown += (_, e) => { e.Handled = true; Close(); };
            clsBtn.MouseEnter += (_, __) => clsBtn.Foreground = Brushes.White;
            clsBtn.MouseLeave += (_, __) => clsBtn.Foreground = new SolidColorBrush(Color.FromArgb(180, 255, 255, 255));

            Grid.SetColumn(titleLbl, 0); hdrRow.Children.Add(titleLbl);
            Grid.SetColumn(clsBtn,   1); hdrRow.Children.Add(clsBtn);
            hdr.Child = hdrRow;

            hdrRow.MouseLeftButtonDown += (_, e) => { if (!e.Handled) DragMove(); };
            Grid.SetRow(hdr, 0); root.Children.Add(hdr);

            // ── Message body ───────────────────────────────────────────────────
            var body = new Label
            {
                Content                  = message,
                FontSize                 = 11,
                FontFamily               = new FontFamily("Segoe UI"),
                Foreground               = new SolidColorBrush(Color.FromRgb(245, 245, 247)),
                VerticalContentAlignment = VerticalAlignment.Center,
                Padding                  = new Thickness(12, 0, 12, 0),
            };
            Grid.SetRow(body, 1); root.Children.Add(body);

            card.Child = root;
            Content    = card;

            // Auto-dismiss
            _timer          = new DispatcherTimer { Interval = TimeSpan.FromSeconds(7) };
            _timer.Tick    += (_, __) => { _timer.Stop(); Close(); };
            _timer.Start();
            Closed         += (_, __) => _timer.Stop();
        }
    }
}
