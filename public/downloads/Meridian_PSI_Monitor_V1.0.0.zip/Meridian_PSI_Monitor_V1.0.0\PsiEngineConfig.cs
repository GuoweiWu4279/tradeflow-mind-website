// PsiEngineConfig.cs
//
// Named configuration for every tunable parameter in PsiEngine.
//
// Architecture:
//   Phase 1 extracted all hard-coded literals into named fields.
//   Phase 2 (Level 2 Statistical Math Upgrade) replaced heuristic sigmoid
//   mappings with NormalCdf(z - k) derived from the trader's own baseline.
//   D-score thresholds are now controlled by a single FalsePositiveRate
//   parameter (default 2.5%) instead of per-dimension sigmoid offsets.
//
// Design constraints:
//   - Zero NinjaTrader API dependencies (unit-testable).
//   - Immutable after construction — safe for concurrent reads from PsiEngine.
//   - Default property returns calibrated values for the Balanced preset.

using System;

namespace NinjaTrader.NinjaScript.AddOns
{
    public sealed class PsiEngineConfig
    {
        // =================================================================
        // Session carry-forward  (overnight EWMA decay model)
        //
        // PSI carries forward via the same EWMA decay formula used intra-session,
        // but applied to the overnight gap:
        //
        //   decayFactor = exp(-overnightHours / OvernightRecoveryTauHours)
        //
        // When live C_i values are available (cross-day boundary during a run):
        //   C_i_tomorrow = C_i_today × decayFactor          (ApplyOvernightDecay)
        //   openPSI      = 100 − Σ C_i_tomorrow − carryDebt_tomorrow
        //
        // When only prevFinalPsi is available (startup / Playback restart):
        //   openPSI = 100 − (100 − prevFinalPsi) × decayFactor  (StartNewSession)
        //
        // Example (tau=48h, overnight=16h → decay≈0.72):
        //   prevPSI=0  → openPSI≈28    (severely tilted — limited overnight recovery)
        //   prevPSI=24 → openPSI≈45
        //   prevPSI=71 → openPSI≈79    (oversize debt → NOT wiped to 95 like buckets did)
        //   prevPSI=90 → openPSI≈93
        // =================================================================

        /// <summary>
        /// Time constant (hours) for overnight PSI debt recovery.
        /// 48 h ≈ 2 days of calm behaviour to fully dissolve the worst session's debt.
        /// Conservative preset uses 72 h; Aggressive uses 36 h.
        /// </summary>
        public double OvernightRecoveryTauHours { get; set; } = 48.0;

        /// <summary>
        /// Estimated overnight gap (hours) used when the actual gap is unknown
        /// (e.g. at startup when only the previous session's final PSI is stored).
        /// 16 h represents a typical market-close-to-open gap.
        /// </summary>
        public double OvernightEstimatedHours { get; set; } = 16.0;

        // =================================================================
        // Consecutive-loss tracking
        // =================================================================

        /// <summary>Geometric decay factor applied to the loss-streak counter on each win (0.6 = 40% reduction).</summary>
        public double WinStreakDecayFactor { get; set; } = 0.6;

        /// <summary>Streak is zeroed when it decays below this threshold.</summary>
        public double StreakClearThreshold { get; set; } = 0.05;

        // =================================================================
        // D1: Revenge Entry
        // =================================================================

        /// <summary>Floor for the time delta between fills (prevents div-by-zero).</summary>
        public double D1MinDeltaSeconds { get; set; } = 1.0;

        /// <summary>Guard: if baseline muSize is below this, treat ratio as 1.0 to avoid div-by-zero.</summary>
        public double D1MuSizeZeroGuard { get; set; } = 0.01;

        /// <summary>
        /// Floor multiplier applied when size z-score is at or below baseline (sizeX near zero).
        /// Ensures a same-size revenge re-entry still scores partially even without size escalation.
        /// A value of 0.35 gives ~35% of full score for same-size re-entries.
        /// Set to 0.0 to restore the original strict size-gating behavior.
        /// </summary>
        public double D1MinSizeFactor { get; set; } = 0.35;

        /// <summary>
        /// Saturation ceiling of the consecutive-loss pressure component injected into D1's
        /// lossX factor.  At infinite streak length the component asymptotes to this value.
        /// A value of 0.50 means 3 back-to-back losses can contribute at most 0.44 lossX even
        /// if each individual loss is exactly average (lossZ = 0).
        /// Set to 0.0 to disable streak-based D1 pressure entirely (reverts to pure z-score gating).
        /// </summary>
        public double D1ConsecutiveLossBase { get; set; } = 0.50;

        /// <summary>
        /// Exponential growth rate of the consecutive-loss pressure component.
        /// streakPressure = D1ConsecutiveLossBase × (1 − exp(−gain × consecutiveLosses)).
        /// At gain = 0.70: after 1 loss ≈ 0.25, after 2 ≈ 0.38, after 3 ≈ 0.44.
        /// Higher values saturate faster (sharper first-loss impact).
        /// </summary>
        public double D1ConsecutiveLossGain { get; set; } = 0.70;

        // =================================================================
        // D2: Stop-Loss Manipulation
        // =================================================================

        /// <summary>Tick buffer for classifying a stop-move as "widening" vs rounding noise.</summary>
        public double D2SlTickRoundingBuffer { get; set; } = 0.5;

        /// <summary>
        /// Exponential saturation rate for adverse-move count → D2 base score.
        /// baseScore = 1 - exp(-rate × adverseMoveCount).
        /// </summary>
        public double D2AdverseSaturationRate { get; set; } = 0.8;

        /// <summary>
        /// Multiplier on SlTicksMax: SL width beyond this triggers the boost path in D2.
        /// 1.5 = 50% above the declared max triggers the severe-manipulation signal.
        /// </summary>
        public double D2SlBreachMultiplier { get; set; } = 1.5;

        /// <summary>
        /// When naked-position is cleared but D2 was maxed (1.0), relax D2 to this
        /// value (hysteresis — avoids instant full-clear on a single poll cycle).
        /// </summary>
        public double D2PartialRelaxValue { get; set; } = 0.5;

        // =================================================================
        // D3: Size Outlier
        // =================================================================

        /// <summary>
        /// How much each consecutive loss steepens the effective z-score.
        /// ctx = 1.0 + this × consecutiveLosses.
        /// </summary>
        public double D3ConsecutiveLossGain { get; set; } = 0.4;

        /// <summary>
        /// Base dampening factor for positions within SizeMax (when calm, no losing streak).
        /// 0.10 = D3 is suppressed to 10% of raw when there are no consecutive losses.
        /// </summary>
        public double D3DampenBase { get; set; } = 0.10;

        /// <summary>
        /// Ramp rate: dampening increases by this amount per consecutive loss.
        /// lossFactor = min(1, DampenBase + DampenRampPerLoss × losses).
        /// </summary>
        public double D3DampenRampPerLoss { get; set; } = 0.30;

        /// <summary>
        /// Minimum D3 score guaranteed whenever the position size exceeds the
        /// trader's declared SizeMax profile setting.
        ///
        /// Rationale: CalcD3 uses a statistical z-score against the historical
        /// baseline.  If a trader habitually trades at 3 lots with SizeMax=2,
        /// the baseline adapts to muSize≈3 and z→0, effectively erasing the
        /// D3 penalty even though the profile violation is clear.  This floor
        /// anchors D3 to the trader's explicit profile declaration so that
        /// violating SizeMax always produces a visible, real-time PSI reaction —
        /// regardless of whether the statistical baseline has normalised the
        /// behaviour.  0.40 produces a ~3–5 point PSI drop at first fill.
        /// </summary>
        public double D3ProfileViolationFloor { get; set; } = 0.40;

        /// <summary>
        /// Hard cap on the D3 score when size is at SizeMax (fully within the
        /// trader's declared profile range).  The cap scales linearly from 0.0
        /// at SizeMin to this value at SizeMax.  Consecutive losses modulate
        /// the actual score within this cap but can NEVER push it above it.
        ///
        /// Rationale: trading at your declared maximum is a legal decision and
        /// should show a moderate yellow/amber informational signal, NOT red.
        /// Red (D3 > ~0.6) is reserved exclusively for size > SizeMax violations.
        /// Default 0.35 means the bar shows amber-ish at max size after losses,
        /// but never red.
        /// </summary>
        public double D3WithinProfileCap { get; set; } = 0.35;

        // =================================================================
        // D4: Hold-Time Collapse
        // =================================================================

        /// <summary>Floor for baseline hold-time mean (seconds), prevents div-by-zero.</summary>
        public double D4MinHoldGuardSec { get; set; } = 1.0;

        /// <summary>Epsilon added to log-odds numerator/denominator to prevent log(0).</summary>
        public double D4LogOddsEpsilon { get; set; } = 0.01;

        // =================================================================
        // D5: Position Hold (扛单)
        // =================================================================

        /// <summary>
        /// Background signal factor: when hold time is within p90, D5 = severity × this.
        /// Keeps a faint signal visible without raising a false alarm.
        /// </summary>
        public double D5BackgroundSignalFactor { get; set; } = 0.05;

        /// <summary>Floor for the p90 denominator (seconds) — prevents tiny p90 from amplifying overtime.</summary>
        public double D5P90DenomFloorSec { get; set; } = 60.0;

        /// <summary>
        /// Upper bound on D5 output.  Set to 1.0 (no effective cap) so that
        /// extreme hold durations (3h+ vs 30min) remain fully distinguishable.
        /// The old value of 0.7 was intended to protect long-timeframe traders
        /// from a static threshold, but the NormalCdf formula already handles
        /// this via each trader's personal p90 baseline — the cap is redundant
        /// and suppresses the rightmost tail of the overstay signal.
        /// </summary>
        public double D5MaxCap { get; set; } = 1.0;

        // =================================================================
        // D6: Rule Compliance
        // =================================================================

        /// <summary>
        /// Multiplier on SlTicksMax for Rule 2: SL wider than this × max triggers a violation.
        /// 1.3 = 30% tolerance above declared max.
        /// </summary>
        public double D6SlViolationMultiplier { get; set; } = 1.3;

        /// <summary>
        /// Multiplier on SizeMax for Rule 3: size above this × max triggers a violation.
        /// 1.5 = 50% tolerance above declared max.
        /// </summary>
        public double D6SizeViolationMultiplier { get; set; } = 1.5;

        /// <summary>Total defined rules (denominator for normalising violation count).</summary>
        public int D6TotalRules { get; set; } = 4;

        // =================================================================
        // D7: Overtrading (过度交易)
        //
        // Signal A — Session-internal acceleration:
        //   accelRatio = recentAvgGap / sessionAvgGap
        //   accelZ     = -log(accelRatio) / D7AccelSigma
        //   D7_A       = NormalCdf(accelZ − ZThreshold)
        //   Fires when the trader's recent inter-entry gap is significantly
        //   shorter than their own session average, regardless of P&L.
        //
        // Signal B — Profile frequency baseline (cold-start safe):
        //   expectedGap = 3600 / LambdaVelocity  (from StrategyProfile)
        //   profileZ    = -log(sessionAvgGap / expectedGap) / D7ProfileSigma
        //   D7_B        = NormalCdf(profileZ − ZThreshold) × rampConf(n)
        //   Fires when session pace is significantly faster than the trader's
        //   declared TradesPerSession range.
        //
        // D7_raw = max(D7_A, D7_B)
        //
        // Partial-fill deduplication: only one entry is counted per
        // OversizeImpulseCooldownSec window (reuses existing config).
        // =================================================================

        /// <summary>
        /// Number of the most recent entries to include in the acceleration
        /// window.  A value of 5 means: compare the last 5 inter-entry gaps
        /// against the session average.
        /// </summary>
        public int D7AccelWindowEntries { get; set; } = 5;

        /// <summary>
        /// Minimum inter-entry gap (seconds) used as floor in ratio calculations
        /// to prevent division-by-zero when two entries happen at the same timestamp.
        /// </summary>
        public double D7MinGapFloorSec { get; set; } = 10.0;

        /// <summary>
        /// [No longer used in CalcD7 — retained for backward compatibility with
        /// serialised profiles only.]
        ///
        /// Previously: minimum session entries before Signal A activated.
        /// Now superseded: Signal A activates naturally when D7AccelWindowEntries+1
        /// entries are in the ring buffer; Signal B activates from entry 2 onward
        /// with a confidence ramp to D7AccelWindowEntries+1.  No separate minimum
        /// threshold is needed — the math determines its own minimum.
        /// </summary>
        public int D7MinSessionEntries { get; set; } = 3;

        /// <summary>
        /// Log-scale standard deviation for Signal A (session acceleration).
        /// Smaller = more sensitive.  0.5 means a 5× acceleration produces z ≈ 3.2.
        /// </summary>
        public double D7AccelSigma { get; set; } = 0.5;

        /// <summary>
        /// Log-scale standard deviation for Signal B (profile baseline).
        /// Slightly wider than AccelSigma because the profile is a rougher prior.
        /// </summary>
        public double D7ProfileSigma { get; set; } = 0.7;

        // =================================================================
        // Hard deductions
        // =================================================================

        /// <summary>
        /// PSI points deducted for trading outside the declared session window.
        /// Subject to HardDeductionCooldownSec.
        /// </summary>
        public double SessionWindowDeduction { get; set; } = 20.0;

        /// <summary>
        /// PSI points deducted for holding a naked position (no stop-loss).
        /// Subject to HardDeductionCooldownSec.
        /// </summary>
        public double NakedPositionDeduction { get; set; } = 25.0;

        /// <summary>
        /// Minimum seconds between consecutive hard deductions (session-window and
        /// naked-position share the same cooldown timer to prevent stacking).
        /// </summary>
        public double HardDeductionCooldownSec { get; set; } = 60.0;

        // =================================================================
        // Composite penalty & escalation
        // =================================================================

        /// <summary>Threshold: max dimension ≥ this counts as "extreme" for escalation tracking.</summary>
        public double ExtremeThreshold { get; set; } = 0.70;

        /// <summary>
        /// Additive boost factor: composite += BoostFactor × maxD².
        /// Allows a single extreme dimension to break through its weight ceiling.
        /// </summary>
        public double BoostFactor { get; set; } = 0.20;

        /// <summary>
        /// Per-fill penalty increment during sustained extreme violations.
        /// Applies when ≥ 2 consecutive fills have maxD ≥ ExtremeThreshold.
        /// </summary>
        public double EscalationPerFill { get; set; } = 0.06;

        /// <summary>Cap on escalation fills to prevent unbounded penalty growth.</summary>
        public int MaxEscalationFills { get; set; } = 8;

        // =================================================================
        // EWMA — time constants and guards
        //
        // Drop τ (120 s, ~2-min half-life):
        //   Approximates sympathetic nervous system (adrenaline) response onset.
        //   Ref: Goldstein & McEwen (2002), "Allostasis, Homeostats, and the
        //   Nature of Stress," Annals of the New York Academy of Sciences.
        //
        // Recovery τ (1200 s, ~20-min half-life):
        //   Approximates HPA axis cortisol clearance half-life (60–90 min).
        //   Ref: Sapolsky, Romero & Munck (2000), "How Do Glucocorticoids
        //   Influence Stress Responses?" Endocrine Reviews 21(1):55–89.
        // =================================================================

        /// <summary>Time constant (seconds) when PSI is dropping. ~2-min half-life (adrenaline).</summary>
        public double EwmaDropTau { get; set; } = 120.0;

        /// <summary>Time constant (seconds) for normal PSI recovery. ~20-min half-life (cortisol).</summary>
        public double EwmaNormalRecoveryTau { get; set; } = 1200.0;

        /// <summary>
        /// Recovery τ during the 5-minute cooldown after overexposure clears.
        /// 10× slower than normal — a lucky profitable exit should not erase the tilt memory.
        /// </summary>
        public double EwmaPostOverexposureTau { get; set; } = 12000.0;

        /// <summary>Effectively infinite τ: freezes PSI recovery during active overexposure.</summary>
        public double EwmaFrozenRecoveryTau { get; set; } = 1e9;

        /// <summary>Maximum PSI drop allowed in a single EWMA step (before hard deductions).</summary>
        public double EwmaPerEventDropCap { get; set; } = 25.0;

        /// <summary>Floor for the EWMA time delta (seconds) — prevents alpha from being exactly 0.</summary>
        public double EwmaMinDeltaSec { get; set; } = 0.1;

        /// <summary>
        /// Bail-out guard: if time jumps backward by more than this many seconds,
        /// the clock likely switched between real and playback time. EWMA is skipped entirely.
        /// </summary>
        public double EwmaBackwardGuardSec { get; set; } = 300.0;

        /// <summary>
        /// Bail-out guard: if time jumps forward by more than this many seconds,
        /// the clock likely switched between real and playback time. EWMA is skipped entirely.
        /// Also used by PollPositions to detect "time switched" condition.
        /// </summary>
        public double EwmaForwardGuardSec { get; set; } = 3600.0;

        // =================================================================
        // Poll-time guards (Market Replay pause detection)
        // =================================================================

        /// <summary>
        /// If consecutive PollPositions calls report platform time within this many
        /// seconds of each other, the replay is considered paused (frozen).
        /// </summary>
        public double PollFrozenThresholdSec { get; set; } = 1.0;

        // =================================================================
        // Overexposure
        // =================================================================

        /// <summary>
        /// Duration (minutes) of the post-overexposure recovery throttle.
        /// After the trader reduces size below SizeMax, PSI recovery is slowed
        /// for this many minutes to prevent "quick exit → instant recovery."
        /// </summary>
        public double OverexposureCooldownMinutes { get; set; } = 5.0;

        /// <summary>
        /// Seconds within which consecutive oversize fills are treated as partial
        /// fills of the same order decision, suppressing duplicate impulse
        /// deductions.  A 3-lot order reported by NT8 as three 1-lot fills within
        /// this window fires only one impulse penalty.
        /// </summary>
        public double OversizeImpulseCooldownSec { get; set; } = 3.0;

        // =================================================================
        // Statistical threshold (Level 2 upgrade)
        //
        // FalsePositiveRate alpha controls the z-threshold k = Phi^-1(1-alpha).
        // Every CalcD* method uses k to decide when observed behaviour crosses
        // from "normal" to "flagged."  alpha = 0.025 → k ≈ 1.96 (standard
        // 95% confidence interval boundary).
        //
        // Ref: NIST/SEMATECH e-Handbook of Statistical Methods, Section 6.3.2
        //      (Shewhart control charts).
        // =================================================================

        /// <summary>
        /// Probability of flagging NORMAL behaviour as abnormal.
        /// 0.025 = 2.5%, the standard two-tailed significance level.
        /// </summary>
        public double FalsePositiveRate { get; set; } = 0.025;

        /// <summary>
        /// Derived z-threshold: k = Phi^-1(1 - FalsePositiveRate).
        /// Precomputed once during config construction.  At FPR=0.025, k ≈ 1.96.
        /// </summary>
        public double ZThreshold { get; set; } = 1.96;

        // =================================================================
        // Factory
        // =================================================================

        /// <summary>
        /// Returns a config with all values set to the original hard-coded defaults.
        /// Bit-identical to pre-extraction behaviour.
        /// </summary>
        public static PsiEngineConfig Default => new PsiEngineConfig();

        /// <summary>
        /// Builds a config from the user's <see cref="StrategyProfile"/> settings.
        /// Starts from the chosen <see cref="PsiSensitivity"/> preset, then applies
        /// any user overrides (NakedPositionPenalty, RecoverySpeedMultiplier, etc.).
        /// </summary>
        public static PsiEngineConfig FromProfile(StrategyProfile p)
        {
            if (p == null) return Default;

            var cfg = PresetFor(p.Sensitivity);

            // ── Apply user overrides (value of -1 = "use preset default") ──

            if (p.NakedPositionPenalty >= 0)
                cfg.NakedPositionDeduction = Clamp(p.NakedPositionPenalty, 0, 50);

            if (p.SessionWindowPenalty >= 0)
                cfg.SessionWindowDeduction = Clamp(p.SessionWindowPenalty, 0, 50);

            if (p.RecoverySpeedMultiplier > 0)
            {
                double m = Clamp(p.RecoverySpeedMultiplier, 0.25, 4.0);
                cfg.EwmaNormalRecoveryTau       /= m;
                cfg.EwmaPostOverexposureTau     /= m;
            }

            if (p.FalsePositiveRate > 0)
                cfg.FalsePositiveRate = Clamp(p.FalsePositiveRate, 0.01, 0.10);

            // Derive z-threshold from false-positive rate: k = Phi^-1(1 - alpha)
            cfg.ZThreshold = PsiEngine.NormalCdfInverse(1.0 - cfg.FalsePositiveRate);

            return cfg;
        }

        // =================================================================
        // Presets
        //
        // Balanced  = default calibrated values.  FPR = 2.5% → k = 1.96.
        //
        // Conservative (stricter):
        //   Higher FPR (5%) → lower z-threshold (1.645) → D-scores fire earlier.
        //   Hard deductions raised  → violations sting more.
        //   Drop τ shortened        → PSI falls faster.
        //   Recovery τ lengthened   → PSI recovers slower.
        //   Extreme threshold lower → escalation triggers sooner.
        //   Rationale: for traders who want the system to catch subtle
        //   deviations and enforce strict discipline.
        //
        // Aggressive (more lenient):
        //   Lower FPR (1%) → higher z-threshold (2.326) → D-scores need larger deviations.
        //   Hard deductions reduced → violations are less punishing.
        //   Drop τ lengthened       → PSI falls more gradually.
        //   Recovery τ shortened    → PSI bounces back faster.
        //   Extreme threshold higher → escalation needs clearer extremes.
        //   Rationale: for experienced traders who self-manage well and
        //   want alerts only for genuinely abnormal behaviour.
        // =================================================================

        private static PsiEngineConfig PresetFor(PsiSensitivity level)
        {
            switch (level)
            {
                case PsiSensitivity.Conservative:
                    return new PsiEngineConfig
                    {
                        // Statistical threshold — 5% FPR → k ≈ 1.645
                        FalsePositiveRate          = 0.05,
                        ZThreshold                 = 1.645,

                        // Harder penalties
                        NakedPositionDeduction     = 30.0,
                        SessionWindowDeduction     = 25.0,
                        EwmaPerEventDropCap        = 30.0,

                        // Faster drop, slower recovery
                        EwmaDropTau                = 90.0,
                        EwmaNormalRecoveryTau      = 1800.0,
                        EwmaPostOverexposureTau    = 18000.0,

                        // Escalation triggers sooner
                        ExtremeThreshold           = 0.60,

                        // D6 tighter tolerances
                        D6SlViolationMultiplier    = 1.15,
                        D6SizeViolationMultiplier  = 1.3,

                        // D3 floor raised for stricter oversize enforcement
                        D3ProfileViolationFloor    = 0.55,
                        // Tighter within-profile cap: even at SizeMax, bar stays clearly amber
                        D3WithinProfileCap         = 0.28,

                        // Slower overnight recovery: 3 days to dissolve severe debt
                        OvernightRecoveryTauHours  = 72.0,
                    };

                case PsiSensitivity.Aggressive:
                    return new PsiEngineConfig
                    {
                        // Statistical threshold — 1% FPR → k ≈ 2.326
                        FalsePositiveRate          = 0.01,
                        ZThreshold                 = 2.326,

                        // Softer penalties
                        NakedPositionDeduction     = 18.0,
                        SessionWindowDeduction     = 12.0,
                        EwmaPerEventDropCap        = 20.0,

                        // Slower drop, faster recovery
                        EwmaDropTau                = 180.0,
                        EwmaNormalRecoveryTau      = 600.0,
                        EwmaPostOverexposureTau    = 6000.0,

                        // Escalation needs clearer extremes
                        ExtremeThreshold           = 0.80,

                        // D6 wider tolerances
                        D6SlViolationMultiplier    = 1.5,
                        D6SizeViolationMultiplier  = 1.8,

                        // D3 floor lowered — lenient oversize enforcement
                        D3ProfileViolationFloor    = 0.25,
                        // Wider within-profile cap: at SizeMax the bar may reach yellow
                        D3WithinProfileCap         = 0.42,

                        // Faster overnight recovery: 1.5 days
                        OvernightRecoveryTauHours  = 36.0,
                    };

                default: // Balanced
                    return new PsiEngineConfig();
            }
        }

        private static double Clamp(double v, double min, double max)
        {
            return v < min ? min : v > max ? max : v;
        }
    }
}

